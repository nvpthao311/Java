const PlaylistSongApi =  {
    addSongToPlaylist: (playlistId, songId) => {
       const url = `/playlistSong/playlists/${playlistId}/songs/${songId}`;
       return axiosClient.post(url);
    },

    removeSongFromPlaylist: (playlistId, songId) => {
        const url = `/playlistSong/playlists/${playlistId}/songs/${songId}`;
        return axiosClient.delete(url);
    },

    getSongsByPlaylist:(songId) => {
        const url = `/playlistSong/songs/${songId}`;
        return axiosClient.get(url);
    },

    getPlaylistBySong: (playlistId) => {
        const url = `/playlistSong/playlists/${playlistId}`;
        return axiosClient.get(url);
    },

}
export default PlaylistSongApi;
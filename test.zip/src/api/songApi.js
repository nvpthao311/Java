import axiosClient from "api/axiosClient";

const SongApi = {
    findAll: (params) => {
        const url = '/songs';
        return axiosClient.get(url, {params});
    },

//    findById: (id) => {
//        const url = `/songs/${id}`;
//        return axiosClient.get(url)
//    },
//
//    findByName: (name, params) => {
//        const url = `/songs/name/${name}`;
//        return axiosClient.get(url, {params})
//    }

    create: (data) => {
        const url = '/songs';
        return axiosClient.post(url, data);
    },

    update: (id, data) => {
        const url = `/songs/${id}`;
        return axiosClient.put(url, data);
    },

    remove: (id) => {
        const url = `/songs/${id}`;
        return axiosClient.delete(url);
    },
}
export default SongApi;
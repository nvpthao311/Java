import React, {useEffect, useState} from 'react';
import axios from 'axios';

const SongManager = () =>{
    const [songs, setSongs] = useState([]);
    const [newSong, setNewSong] = useState("");

    useEffect(() => {
        axios.get("/songs").then( (res) => setSongs(res.data));
    }, []);

    const handleAdd = async () => {
        const res = await axios.post("/songs", { title: newSong });
        setSongs([...songs, res.data]);
        setNewSong("");
    };

    const handleDelete = async () => {
        await axios.delete("/songs/${id}")
        setSongs(songs.filter((s) => s.id !== id));
    };

    return (
        <div>
            <h1> Quản lý bài hát</h1>

            <input
                value={newSong}
                onchange={(e) => setNewSong(e.target.value)}
            />
            <button onclick={handleAdd}>+ Thêm</button>

            <ul>
                {songs.map((song) => (
                     <li key={song.id}>{song.id}
                        <button onclick={() => handDelete(song.id)}>X</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default SongManager;
import { createSlice, createAsyncThunk  } from '@reduxjs/toolkit';
import SongApi from 'api/songApi';

//
export const fetchSongs = createAsyncThunk(
    'songs/findAll',
    async (params) => {
        try {
            const response = await SongApi.findAll(params);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);

export const createSong  = createAsyncThunk(
    'songs/create',
    async ( song ) => {
        try {
            const response = await SongApi.create(song);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const updateSong  = createAsyncThunk(
    'songs/update',
    async ( song ) => {
        try {
            const response = await SongApi.update( song.id, song);
            console.log("RESPONSE:" , response);
            return song;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const removeSong  = createAsyncThunk(
    'songs/remove',
    async ( id ) => {
        try {
            const response = await SongApi.remove(id);
            console.log("RESPONSE:" , response);
            return id;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);

//
const song = createSlice({
    name: 'songs',
    initialState: {
        list: [],
        filtered: [],
        searchText: '',
    },
    reducers: {

        deleteSong: (state, action) => {
            const deleteSongId = action.payload;
            state.list = state.list.filter(song => song.id !== deleteSongId);
        },

        editSong: (state, action) => {
            const newSong =  action.payload;
            const songIndex = state.list.findIndex(song => song.id === newSong.id);

            if(songIndex != null){
                state.list[songIndex] = newSong;
            }
        },

        findBySongName: (state, action) => {
            state.searchText = action.payload.toLowerCase()
            state.filtered = state.list.filter((song) =>
                song.name.toLowerCase().includes(state.searchText)
            );
        },
    },

    //
    extraReducers: (builder) => {
        builder
            .addCase(fetchSongs.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchSongs.fulfilled, (state, action) => {
                state.list = action.payload;
                state.loading = false;
            })
            .addCase(createSong.fulfilled, (state, action) => {
                state.list.push(action.payload);
            })
            .addCase(updateSong.fulfilled, (state, action) => {
                const songIndex = state.list.findIndex(p => p.id === action.payload.id);
                state.list[songIndex] = action.payload;
            })
            .addCase(removeSong.fulfilled, (state, action) => {
                state.list = state.list.filter(p => p.id !== action.payload);
            })
    }
})

const { reducer, actions } = song;
export const {addSong, deleteSong, editSong, findBySongName} = actions;
export default reducer;
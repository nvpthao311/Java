import React, {useEffect} from 'react';
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate, Link} from 'react-router-dom';

import { deleteSong, editSong, fetchSongs } from 'features/Song/SongSlice';
import SongList from 'features/Song/components/SongList';
import { findBySongName } from 'features/Song/SongSlice';
import "./MainPage.scss";

function MainPage() {
    const songs = useSelector(state => state.songs.list);
    const filteredSongs = useSelector((state) => state.songs.filtered);
    const searchText = useSelector((state) => state.songs.searchText);

    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    useEffect(() => {
        dispatch(fetchSongs());
    }, []);

    const handleAdd = () => {
        navigate("/music/songs/add");
    }

    const handleSearch = (name) => {
        console.log('Search song:', name);

        const action = findBySongName(name);
        console.log({action});
        dispatch(action);
    }

    const handleEdit = (id) => {
        console.log('Edit song:', id);

        const action = editSong(id);
        console.log({action});
        dispatch(action);
    }

    const handleDelete = (id) => {
        console.log('Deleted song:', id);

        const action = deleteSong(id);
        console.log({action});
        dispatch(action);
    }



    return (
        <div className="container">
            <aside className="container__body_menu">
                <h3>Home > Songs</h3>
                <div class="divider"></div>
                <SongList
                    songs={searchText.length > 0 ? filteredSongs : songs}
                    onAdd ={handleAdd}
                    onEdit ={handleEdit}
                    onDelete ={handleDelete}
                    onSearch ={handleSearch}
                />
            </aside>
        </div>

    );
}

export default MainPage;
import { createSlice, createAsyncThunk  } from '@reduxjs/toolkit';
import PlaylistApi from 'api/playlistApi';

//
export const fetchPlaylists = createAsyncThunk(
    'playlists/findAll',
    async (params) => {
        try {
            const response = await PlaylistApi.findAll(params);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);

export const createPlaylist  = createAsyncThunk(
    'playlists/create',
    async ( playlist ) => {
        try {
            const response = await PlaylistApi.create(playlist);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const updatePlaylist  = createAsyncThunk(
    'playlists/update',
    async ( playlist ) => {
        try {
            const response = await PlaylistApi.update( playlist.id, playlist);
            console.log("RESPONSE:" , response);
            return playlist;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const removePlaylist  = createAsyncThunk(
    'playlists/remove',
    async ( id ) => {
        try {
            const response = await PlaylistApi.remove(id);
            console.log("RESPONSE:" , response);
            return id;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);


//
const nextId=1;
const playlist = createSlice({
    name: 'playlists',
    initialState: {
        list: [],
        filtered:[],
        searchText: '',
        loading: false,
    },
    reducers: {
        findByPlaylistName: (state, action) => {
            state.searchText = action.payload.toLowerCase()
            state.filtered = state.list.filter((song) =>
                song.name.toLowerCase().includes(state.searchText)
            );
        }
    },

    //
    extraReducers: (builder) => {
        builder
            .addCase(fetchPlaylists.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchPlaylists.fulfilled, (state, action) => {
                state.list = action.payload;
                state.loading = false;
            })
            .addCase(createPlaylist.fulfilled, (state, action) => {
                state.list.push(action.payload);
            })
            .addCase(updatePlaylist.fulfilled, (state, action) => {
                const playlistIndex = state.list.findIndex(p => p.id === action.payload.id);
                state.list[playlistIndex] = action.payload;
            })
            .addCase(removePlaylist.fulfilled, (state, action) => {
                state.list = state.list.filter(p => p.id !== action.payload);
            })
    }

})

const { reducer, actions } = playlist;
export const {findByPlaylistName} = actions;
export default playlist.reducer;

import React, { useEffect, useState } from "react";
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate } from 'react-router-dom';

import PlaylistApi from 'api/playlistApi'
import PlaylistList from 'features/Playlist/components/PlaylistList';
import {findByPlaylistName, fetchPlaylists, removePlaylist, updatePlaylist } from 'features/Playlist/PlaylistSlice';

function MainPage() {
    const playlists = useSelector(state => state.playlists.list);
    const filteredPlaylists = useSelector((state) => state.playlists.filtered);
    const searchText = useSelector((state) => state.playlists.searchText);

    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(fetchPlaylists());
    }, []);

    const handleClickPlaylist = () => {
        navigate('/music/songs');
    };

    const handleAdd = () => {
        navigate("/music/playlists/add");
    }

    const handleSearch = (name) => {
        console.log('Search playlists:', name);

        const action = findByPlaylistName(name);
        console.log({action});
        dispatch(action);
    }

    const handleEdit = ( playlist ) => {
        dispatch(updatePlaylist(playlist))
            .unwrap()
            .then(() => {
                console.log("playlist playlist done!");
            })
            .catch((error) => {
                console.error("playlist playlist failed:", error);
            });
    }

    const handleDelete = (id) => {
        dispatch(removePlaylist(id))
            .unwrap()
            .then(() => {
                console.log("Remove playlist done!");
            })
            .catch((error) => {
                console.error("Remove playlist failed:", error);
            });
    }

    return (
        <div className="container">
            <aside className="container__body_menu">
                <h3>Home > Playlists</h3>
                <div class="divider"></div>
                <PlaylistList
                    playlists ={searchText.length > 0 ? filteredPlaylists : playlists}
                    onAdd ={handleAdd}
                    onEdit ={handleEdit}
                    onDelete ={handleDelete}
                    onSearch ={handleSearch}
                />
            </aside>
        </div>

    );
}

export default MainPage;
import React from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate  } from 'react-router-dom';

import { createPlaylist } from 'features/Playlist/PlaylistSlice'
import PlaylistForm from 'features/Playlist/components/PlaylistForm';

function AddPage() {
    const dispatch = useDispatch ();
    const navigate  = useNavigate ();

    const handleSubmit = (playlist) => {
        dispatch(createPlaylist(playlist))
            .unwrap()
            .then(() => {
                navigate("/music/playlists");
            })
            .catch((error) => {
                console.error("Create playlist failed:", error);
            });
    }

    const handleCancel = () => {
        navigate("/music/playlists");
    }

    return (
        <div className="add_page">
            <PlaylistForm
                onSubmit={handleSubmit}
                onCancel={handleCancel}
            />
        </div>
    );
}


export default AddPage;
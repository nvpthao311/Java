import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './page/Login/login';
import Home from './page/Home/home';
import MainLayout from './Layout/MainLayout';
import "./Style.css"

function App() {
  return (
    <Routes>
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/login" element={<Login />} />

        <Route path="/" element={<MainLayout />}>
                <Route path="home" element={<Home />} />
        </Route>
    </Routes>
  );
}

export default App;


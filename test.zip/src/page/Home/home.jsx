import React from "react";
import "./home.css";
import logo from "C:/Users/intern.nvpthao/Documents/code_java/song-manager/src/images/left-arrow.png";


export default function Home() {
  return (

<div className="container">
    <nar className="menu">
        <div>
            <img className="icon" src={logo} alt="left-arrow" />
        </div>
        <h4>Songs</h4>
        <h4>Playlists</h4>
    </nar>

    <aside className="body_menu">

        <div className="body_songs">
            <h3>Home > Songs</h3>
        </div>

        <div className="body_playlists">
            <h3>Home > Playlists</h3>
        </div>

    </aside>
</div>

  );
}
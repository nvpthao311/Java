import React from 'react';
import { Outlet } from 'react-router-dom';
import logo from "C:/Users/intern.nvpthao/Documents/code_java/song-manager/src/images/logo.png";
import backgroundVideo from "C:/Users/intern.nvpthao/Documents/code_java/song-manager/src/images/background.mp4";
import "./MainLayout.css";

export default function MainLayout() {
  return (
    <>
        <video>
                <source src={backgroundVideo} type="video/mp4" />
        </video>

        <div className="overlay">
            <header className="header_footer_home">
                <div className="logo">
                    <img src={logo} alt="logo" />
                    <h2>
                        <span className="danger">MUSIC</span>-MANAGER
                    </h2>
                </div>
            </header>

             <main>
                 <Outlet />
             </main>

             <footer className="header_footer_home" >@2025 ThaoVo</footer>
        </div>
    </>
  );
}

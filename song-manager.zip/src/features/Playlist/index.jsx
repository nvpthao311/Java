import React from 'react';
import { Route, Routes, useMatch } from 'react-router-dom';

import NotFound from 'components/NotFound';
import MainPage from 'features/Playlist/pages/MainPage'

Playlist.propTypes = {};

function Playlist() {
    const match = useMatch('music/playlists');
    console.log({ match });

    return(
        <Routes>
            <Route path="/" element={<MainPage />} />
            <Route path="*" element={<NotFound />} />
        </Routes>
    );
}

export default Playlist;
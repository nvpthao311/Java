import React from "react";
import { useNavigate } from "react-router-dom";

function MainPage() {
    const navigate = useNavigate();
    const handleClickSongs = () => {
        navigate('/music/songs');
    };

    return (
        <div className="container">
            <div className="selections">
                <button onClick={handleClickSongs}>Songs</button>
                <button>Playlists</button>
            </div>

            <aside className="container__body_menu">
                <h3>Home > Playlists</h3>
                <div class="divider"></div>
            </aside>
        </div>

    );
}

export default MainPage;
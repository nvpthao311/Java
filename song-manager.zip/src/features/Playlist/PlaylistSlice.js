import { createSlice } from '@reduxjs/toolkit';

let nextId = 1;

const playlist = createSlice({
    name: 'playlists',
    initialState: [],
    reducers: {
        addPlaylist: (state, action) => {
            const newPlaylist = {
                id: nextId++,
                ...action.payload,
            };
            state.push(newPlaylist);
        },

        deletePlaylist: (state, action) => {
            const deletePlaylistId = action.payload;
            return state = state.filter(playlist => playlist.id !== deletePlaylistId);
        },

        editPlaylist: (state, action) => {
            const newPlaylist =  action.payload;
            const playlistIndex = state.findIndex(playlist => playlist.id === newPlaylist.id);

            if(playlistIndex != null){
                state[playlistIndex] = newPlaylist;
            }
        }

    }
})

const { reducer, actions } = playlist;
export const {addPlaylist, deletePlaylist, editPlaylist} = actions;
export default reducer;
import { createSlice } from '@reduxjs/toolkit';

let nextId = 1;

const song = createSlice({
    name: 'songs',
    initialState: [],
    reducers: {
        addSong: (state, action) => {
            const newSong = {
                id: nextId++,
                ...action.payload,
            };
            state.push(newSong);
        },

        deleteSong: (state, action) => {
            const deleteSongId = action.payload;
            return state = state.filter(song => song.id !== deleteSongId);
        },

        editSong: (state, action) => {
            const newSong =  action.payload;
            const songIndex = state.findIndex(song => song.id === newSong.id);

            if(songIndex != null){
                state[songIndex] = newSong;
            }
        }

    }
})

const { reducer, actions } = song;
export const {addSong, deleteSong, editSong} = actions;
export default reducer;
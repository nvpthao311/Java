import React from 'react';
import {useSelector} from 'react-redux';
import { Link } from 'react-router-dom';
import SongList from 'features/Song/components/SongList';

import "./MainPage.scss";

function MainPage() {
    const songs = useSelector(state => state.songs)

    return (
        <div className="container">
            <div className="selections">
                <button>Songs</button>
                <Link to="/music/playlists"><button>Playlists</button></Link>
            </div>

            <aside className="container__body_menu">
                <h3>Home > Songs</h3>
                <div class="divider"></div>
                <SongList songs ={songs}/>
            </aside>
        </div>

    );
}

export default MainPage;
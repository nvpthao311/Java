import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { FaTrash, FaEdit, FaPlus, FaSearch  } from 'react-icons/fa';
import { Link } from 'react-router-dom';

import './SongList.scss'

function SongList({ songs }) {
    const [selectedSongs, setSelectedSongs] = useState([]);

    const isSelected = (id) => selectedSongs.includes(id);

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allIds = songs.map((song) => song.id);
            setSelectedSongs(allIds);
        } else {
            setSelectedSongs([]);
        }
    };

    const handleSelectSong = (id) => {
        setSelectedSongs((prevSelected) =>
            prevSelected.includes(id)
            ? prevSelected.filter((songId) => songId !== id)
            : [...prevSelected, id]
        );
    };

    const handleEdit = (songId) => {
        console.log('Edit song:', songId);

    };

    const handleDelete = (songId) => {
        const confirmDelete = window.confirm('Bạn có chắc chắn muốn xóa bài hát này không?');
        if (confirmDelete) {
            console.log('Deleted song:', songId);
            // TODO: gọi API hoặc cập nhật songs bên ngoài.
        }
    };

    const isAllSelected = selectedSongs.length === songs.length && songs.length > 0;

    return (
        <>
        <div className="song-header">
            <h4>Song Manager</h4>
            <div className="box1">
                <Link to="add" className="btn-action"><FaPlus /> Add</Link>
                <Link className="btn-action"><FaTrash /> Delete</Link>
                <Link className="btn-action"><FaSearch /> Search</Link>
            </div>
        </div>

        <table className="song-table">
            <thead>
                <tr>
                    <th>
                        <input
                            type="checkbox"
                            onChange={handleSelectAll}
                            checked={isAllSelected}
                        />
                    </th>
                    <th>Name</th>
                    <th>Artist</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {songs.map((song) => (
                    <tr key={song.id}>
                        <td>
                        <input
                            type="checkbox"
                            checked={isSelected(song.id)}
                            onChange={() => handleSelectSong(song.id)}
                        />
                        </td>

                        <td>{song.name}</td>

                        <td>{song.artist}</td>

                        <td>
                            <button onClick={() => handleEdit(song.id)} className="btn-action">
                                <FaEdit /> Edit
                            </button>
                            <button onClick={() => handleDelete(song.id)} className="btn-action">
                                <FaTrash /> Delete
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
        </>
    );
}

SongList.propTypes = {
    songs: PropTypes.arrayOf(
        PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        artist: PropTypes.string.isRequired,
    })
    ).isRequired,

    onEdit: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
};

export default SongList;

import React from 'react';
import PropTypes from 'prop-types';
import { Button, FormGroup} from 'reactstrap';
import { Link } from "react-router-dom";
import { Formik, Form, FastField } from 'formik';
import InputField from 'custom-fields/InputField';
import FileUploadField from 'custom-fields/FileUploadField'
import './SongForm.scss'

import * as Yup from 'yup';

function SongForm(props) {

    const initialValues = {
        name:'',
        artist:'',
        filepath:'',
    };

    const validationSchema = Yup.object().shape({
        name: Yup.string().required(),
        artist: Yup.string().required(),
        filepath: Yup.string().required(),
    })

    return(
        <Formik
            initialValues = {initialValues}
            validationSchema={validationSchema}
            onSubmit={props.onSubmit}
        >
            {formikProps => {
                const { values, errors, touched } = formikProps;
                console.log({ values, errors, touched });

                return(
                    <Form className="song-form">
                        <FastField
                            name="name"
                            component={InputField}

                            label="Name"
                            placeholder="Eg: Hello"
                        />
                        <FastField
                            name="artist"
                            component={InputField}

                            label="Artist"
                            placeholder="Eg: Adele"
                        />

                        <FastField
                            name="filepath"
                            component={FileUploadField}

                            label="Filepath"
                        />

                        <FormGroup>
                            <Button type="submit" color="primary">
                                Apply
                            </Button>
                            <Link to="/music/songs">
                                <Button type="cancel" color="primary">
                                    Cancel
                                </Button>
                            </Link>
                        </FormGroup>
                    </Form>
                )
            }}
        </Formik>
    );
}

SongForm.propTypes = {
    initialValues: PropTypes.object,
    onSubmit: PropTypes.func.isRequired,
}

SongForm.defaultProps = {
    onSubmit: null,
}

export default SongForm;
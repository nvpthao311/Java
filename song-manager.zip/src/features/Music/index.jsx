import React from 'react';
import { Route, Routes, useMatch } from 'react-router-dom';

import NotFound from 'components/NotFound';
import MainPage from 'features/Music/pages/MainPage';
import MainLayout from 'Layouts/MusicLayout';
import Song from 'features/Song';
import Playlist from 'features/Playlist';

Music.propTypes = {};

function Music() {
    const match = useMatch('/music');
    console.log({ match });

    return(
        <Routes>
            <Route element={<MainLayout />}>
                <Route path="/" element={<MainPage />} />
                <Route path="/songs/*" element={<Song />} />
                <Route path="/playlists/*" element={<Playlist />} />
                <Route path="*" element={<NotFound />} />
            </Route>
        </Routes>
    );
}

export default Music;
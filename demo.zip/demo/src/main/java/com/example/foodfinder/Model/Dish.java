package com.example.foodfinder.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
// Annotation of Lombok
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Dish {

    @Id
    private Long id;

    private String name;

    @ManyToMany
    @JoinTable(
            name = "dish_address",
            joinColumns = @JoinColumn(name = "dish_id"),
            inverseJoinColumns = @JoinColumn(name = "address_id")
    )
    private List<Address> addresses = new ArrayList<>();
}

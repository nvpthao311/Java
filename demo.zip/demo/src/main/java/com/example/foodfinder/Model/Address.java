package com.example.foodfinder.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
//Annotation of Lombok
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Address {
    @Id
    private Long id;

    private String location;
    private String review;

    @ManyToMany (mappedBy = "addresses")
    private List<Dish> dishes = new ArrayList<>();

}

import { createSlice, createAsyncThunk  } from '@reduxjs/toolkit';
import PlaylistApi from 'api/playlistApi';

//
export const fetchPlaylists = createAsyncThunk(
    'playlists/findAll',
    async (params) => {
        try {
            const response = await PlaylistApi.findAll(params);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);

export const fetchPlaylistById  = createAsyncThunk(
    'playlists/findById',
    async (id) => {
        try {
            const response = await PlaylistApi.findById(id);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const fetchPlaylistsByName  = createAsyncThunk(
    'playlists/findByName',
    async ( name ) => {
        if(!name){
            return {response: '', searching: false};
        }
        try {
            const response = await PlaylistApi.findByName( name );
            console.log("RESPONSE:" , response);
            return { response, searching: true };
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);


export const createPlaylist  = createAsyncThunk(
    'playlists/create',
    async ( playlist ) => {
        try {
            const response = await PlaylistApi.create(playlist);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const updatePlaylist  = createAsyncThunk(
    'playlists/update',
    async ( playlist ) => {
        try {
            const response = await PlaylistApi.update( playlist.id, playlist);
            console.log("RESPONSE:" , response);
            return playlist;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const removePlaylist  = createAsyncThunk(
    'playlists/remove',
    async ( id ) => {
        try {
            const response = await PlaylistApi.remove(id);
            console.log("RESPONSE:" , response);
            return id;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);


//
const playlist = createSlice({
    name: 'playlists',
    initialState: {
        list: [],
        filtered:[],
        searching: false,
        loading: false,
    },
    reducers: {
    },

    //
    extraReducers: (builder) => {
        builder
            .addCase(fetchPlaylists.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchPlaylists.fulfilled, (state, action) => {
                state.list = action.payload.content;
                state.loading = false;
            })
            .addCase(fetchPlaylistById.fulfilled, (state, action) => {
                state.searching = false;
                state.filtered = action.payload;
            })
            .addCase(fetchPlaylistsByName.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchPlaylistsByName.fulfilled, (state, action) => {
                state.searching = action.payload.searching;
                state.filtered = action.payload.response;
                state.loading = false;
            })
            .addCase(createPlaylist.fulfilled, (state, action) => {
                state.list.push(action.payload);
            })
            .addCase(updatePlaylist.fulfilled, (state, action) => {
                const playlistIndex = state.list.findIndex(p => p.id === action.payload.id);
                state.list[playlistIndex] = action.payload;
            })
            .addCase(removePlaylist.fulfilled, (state, action) => {
                if(state.searching) state.filtered = state.filtered.filter(p => p.id !== action.payload);
                state.list = state.list.filter(p => p.id !== action.payload);
            })
    }

})

const { reducer, actions } = playlist;
export const { } = actions;
export default reducer;

import React, { useEffect } from "react";
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import {fetchPlaylistById } from 'features/Playlist/PlaylistSlice';


function PlaylistDetailPage () {
    const {id} = useParams();
    const filteredPlaylists = useSelector((state) => state.playlists.filtered);
    const playlist = filteredPlaylists;

    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(fetchPlaylistById(id));
    }, [dispatch]);

    return (
        <>
        <div>
            <h4>Playlist Details</h4>
        </div>
            <span>Name: <strong>{playlist.name}</strong></span>
            <span>Songs in this playlist:</span>
        </>
    );
}
export default PlaylistDetailPage;
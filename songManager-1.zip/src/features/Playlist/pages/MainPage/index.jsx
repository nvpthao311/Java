import React, { useEffect } from "react";
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate } from 'react-router-dom';

import PlaylistList from 'features/Playlist/components/PlaylistList';
import {fetchPlaylistsByName, fetchPlaylists, removePlaylist, updatePlaylist } from 'features/Playlist/PlaylistSlice';

function MainPage() {
    const playlists = useSelector(state => state.playlists.list);
    const filteredPlaylists = useSelector((state) => state.playlists.filtered);
    const searching = useSelector((state) => state.playlists.searching);

    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(fetchPlaylists());
    }, [dispatch]);

    const handleAdd = () => {
        navigate("/music/playlists/add");
    }

    const handleEdit = ( playlist ) => {
        dispatch(updatePlaylist(playlist))
            .unwrap()
            .then(() => {
                console.log("playlist playlist done!");
            })
            .catch((error) => {
                console.error("playlist playlist failed:", error);
            });
    }

    const handleDelete = (id) => {
        dispatch(removePlaylist(id))
            .unwrap()
            .then(() => {
                console.log("Remove playlist done!");
            })
            .catch((error) => {
                console.error("Remove playlist failed:", error);
            });
    }

    const handleSearch = (name) => {
        dispatch(fetchPlaylistsByName(name))
            .unwrap()
            .then(() => {
                console.log("Search playlist done!");
            })
            .catch((error) => {
                console.error("Search playlist failed:", error);
            });
    }

    const handleView = (id) => {
         navigate(`/music/playlists/view/${id}`);
    }

    return (
        <PlaylistList
            playlists ={searching ? filteredPlaylists : playlists}
            onAdd ={handleAdd}
            onEdit ={handleEdit}
            onDelete ={handleDelete}
            onSearch ={handleSearch}
            onView = {handleView}
        />
    );
}

export default MainPage;
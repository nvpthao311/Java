import React from 'react';
import { Route, Routes, useMatch } from 'react-router-dom';

import ContainerLayout from 'Layouts/ContainerLayout';
import NotFound from 'components/NotFound';
import MainPage from 'features/Playlist/pages/MainPage';
import AddPage from 'features/Playlist/pages/AddPage';
import PlaylistDetailPage from 'features/Playlist/pages/PlaylistDetailPage';

Playlist.propTypes = {};

function Playlist() {
    const match = useMatch('music/playlists');
    console.log({ match });

    return(
        <Routes>
            <Route element={<ContainerLayout title="Playlist" />}>
                <Route path="/" element={<MainPage />} />
                <Route path="/add" element={<AddPage />} />
                <Route path="/view/:id" element={<PlaylistDetailPage />} />
                <Route path="*" element={<NotFound />} />
            </Route>
        </Routes>
    );
}

export default Playlist;
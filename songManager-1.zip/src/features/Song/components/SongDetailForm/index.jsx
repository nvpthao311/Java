

function SongDetailForm(props) {

}
SongDetailForm.propTypes = {
    song: PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        artist: PropTypes.string.isRequired,
    }).isRequired;
    playlists: PropTypes.arrayOf(
        PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        artist: PropTypes.string.isRequired,
    })).isRequired,


};
export default SongDetailForm;
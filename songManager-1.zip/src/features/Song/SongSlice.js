import { createSlice, createAsyncThunk  } from '@reduxjs/toolkit';
import SongApi from 'api/songApi';

//
export const fetchSongs = createAsyncThunk(
    'songs/findAll',
    async (params) => {
        try {
            const response = await SongApi.findAll(params);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const fetchSongById = createAsyncThunk(
    'songs/findById',
    async (id) => {
        try {
            const response = await SongApi.findById(id);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const fetchSongsByName = createAsyncThunk(
    'songs/findByName',
    async (name) => {
        if(!name){
                return {response: '', searching: false};
            }
        try {
            const response = await SongApi.findByName(name);
            console.log("RESPONSE:" , response);
            return {response, searching: true};
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);

export const createSong  = createAsyncThunk(
    'songs/create',
    async ( song ) => {
        try {
            const response = await SongApi.create(song);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const updateSong  = createAsyncThunk(
    'songs/update',
    async ( song ) => {
        try {
            const response = await SongApi.update( song.id, song);
            console.log("RESPONSE:" , response);
            return song;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);
export const removeSong  = createAsyncThunk(
    'songs/remove',
    async ( id ) => {
        try {
            const response = await SongApi.remove(id);
            console.log("RESPONSE:" , response);
            return id;
        } catch (error) {
            console.log("ERROR:" , error);
        }
    }
);

//
const song = createSlice({
    name: 'songs',
    initialState: {
        list: [],
        filtered:[],
        searching: false,
        loading: false,
    },
    reducers: {
    },

    //
    extraReducers: (builder) => {
        builder
            .addCase(fetchSongs.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchSongs.fulfilled, (state, action) => {
                state.list = action.payload.content;
                state.loading = false;
            })
            .addCase(fetchSongById.fulfilled, (state, action) => {
                state.searching = false;
                state.filtered = action.payload;
            })
            .addCase(fetchSongsByName.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchSongsByName.fulfilled, (state, action) => {
                state.searching = action.payload.searching;
                state.filtered = action.payload.response;
                state.loading = false;
            })
            .addCase(createSong.fulfilled, (state, action) => {
                state.list.push(action.payload);
            })
            .addCase(updateSong.fulfilled, (state, action) => {
                const songIndex = state.list.findIndex(p => p.id === action.payload.id);
                state.list[songIndex] = action.payload;
            })
            .addCase(removeSong.fulfilled, (state, action) => {
                if(state.searching) state.filtered = state.filtered.filter(s => s.id !== action.payload);
                state.list = state.list.filter(s => s.id !== action.payload);
            })
    }
})

const { reducer, actions } = song;
export const { } = actions;
export default reducer;
import React, {useEffect} from 'react';
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate} from 'react-router-dom';

import SongList from 'features/Song/components/SongList';
import { removeSong, updateSong, fetchSongs, fetchSongsByName } from 'features/Song/SongSlice';

function MainPage() {
    const songs = useSelector(state => state.songs.list);
    const filteredSongs = useSelector((state) => state.songs.filtered);
    const searching = useSelector((state) => state.songs.searching);

    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    useEffect(() => {
        dispatch(fetchSongs());
    }, [dispatch]);

    const handleAdd = () => {
        navigate("/music/songs/add");
    }

    const handleEdit = ( song ) => {
        dispatch(updateSong(song))
            .unwrap()
            .then(() => {
                console.log("song song done!");
            })
            .catch((error) => {
                console.error("song song failed:", error);
            });
    }

    const handleDelete = (id) => {
        dispatch(removeSong(id))
            .unwrap()
            .then(() => {
                console.log("Remove song done!");
            })
            .catch((error) => {
                console.error("Remove song failed:", error);
            });
    }
    const handleSearch = (name) => {
        dispatch(fetchSongsByName(name))
            .unwrap()
            .then(() => {
                console.log("Search playlist done!");
            })
            .catch((error) => {
                console.error("Search playlist failed:", error);
            });
    }

    const handleView = (id) => {
        navigate(`/music/songs/view/${id}`);
    }

    return (
        <SongList
            songs={searching ? filteredSongs : songs}
            onAdd ={handleAdd}
            onEdit ={handleEdit}
            onDelete ={handleDelete}
            onSearch ={handleSearch}
            onView ={handleView}
        />
    );
}

export default MainPage;
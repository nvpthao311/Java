import React, { useEffect } from "react";
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router-dom';

import {fetchSongById } from 'features/Song/SongSlice';


function SongDetailPage () {
    const {id} = useParams();
    const filteredSongs = useSelector((state) => state.songs.filtered);
    const playlist = filteredSongs;

    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(fetchSongById(id));
    }, [dispatch]);

    return (
        <>
        <div>
            <h4>Song Details</h4>
        </div>
            <span> Name: <strong>{playlist.name}</strong></span>
            <span> Artist: <strong>{playlist.artist}</strong></span>
            <span>Playlists have this song:</span>
        </>
    );
}
export default SongDetailPage;
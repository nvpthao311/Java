import React from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate  } from 'react-router-dom';

import { createSong } from 'features/Song/SongSlice'
import SongForm from 'features/Song/components/SongForm';

function AddPage() {
    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    const handleSubmit = (song) => {
        dispatch(createSong(song))
            .unwrap()
            .then(() => {
                navigate("/music/songs");
            })
            .catch((error) => {
                console.error("Create song failed:", error);
            });
    }

    const handleCancel = () => {
        navigate("/music/songs");
    }

    return (
        <div className="add_page">
            <SongForm
                onSubmit={handleSubmit}
                onCancel={handleCancel}
            />
        </div>
    );
}

export default AddPage;
import React from 'react';
import { Route, Routes, useMatch } from 'react-router-dom';

import ContainerLayout from 'Layouts/ContainerLayout'
import NotFound from 'components/NotFound';
import MainPage from 'features/Song/pages/MainPage';
import AddPage from 'features/Song/pages/AddPage';
import SongDetailPage from 'features/Song/pages/SongDetailPage';

Song.propTypes = {};

function Song() {
    const match = useMatch('/music/songs');
    console.log({ match });

    return(

        <Routes>
            <Route element={<ContainerLayout title="Song" />}>
                <Route path="/" element={<MainPage />} />
                <Route path="/add" element={<AddPage />} />
                <Route path="/view/:id" element={<SongDetailPage />} />
                <Route path="*" element={<NotFound />} />
            </Route>
        </Routes>
    );
}

export default Song;
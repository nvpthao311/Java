import { Outlet } from 'react-router-dom';
import './ContainerLayout.scss'

export default function ContainerLayout ( {title} ) {
    return (
        <div className="container">
            <aside className="container__body">
                <h3>Home > {title}</h3>
                <div class="divider"></div>
                <Outlet />
            </aside>
        </div>
    )
}

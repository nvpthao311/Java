import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { FaSearch, FaTimes } from 'react-icons/fa';
import './SearchBox.scss'; // Hoặc .css tuỳ bạn

const SearchBox = (props) => {
    const {onSearch} = props;

    const [showInput, setShowInput] = useState(false);
    const [query, setQuery] = useState('');

    const handleSearchClick = () => {
        setShowInput(true);
    };

    useEffect(() => {
        onSearch(query);
    }, [query]);

    const handleClear = () => {
        setQuery('');
        setShowInput(false);
    };

    return (
        <div>
            {!showInput ? (
                <button onClick={handleSearchClick} className="btn-action">
                    <FaSearch /> Search
                </button>
            ) : (
                <div className="search-container">
                    <FaSearch className="search-icon" />
                    <input
                        type="text"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="search"
                        className="search-input"
                    />
                    <FaTimes className="clear-icon" onClick={handleClear} />
                </div>
            )}
        </div>
    );
};

SearchBox.propsTypes = {
    onSearch: PropTypes.func.isRequired,
};

SearchBox.defaultProps = {
    onSearch: '',
}
export default SearchBox;

import PropTypes from 'prop-types';
import Select from 'react-select';
import { ErrorMessage } from 'formik'
import './SelectBox.scss'

const SelectBox = (props) =>{
    const { options, name, selected, placeholder, disabled} = props;

    const handleSelectedOptionChange = (selectOption) => {

    }

    return(
        <>
             <Select
                  className="custom-transparent-select"
                  classNamePrefix="select"
                  id={name}
                  value={options.find(option => option.label === selected)}
                  onChange={handleSelectedOptionChange}

                  placeholder={placeholder}
                  options={options}
                  disabled={disabled}
             />
        </>
    );
}
SelectBox.propsTypes = {
    options: PropTypes.array.isRequired,
    name: PropTypes.string.isRequired,
    selected: PropTypes.string,
    placeholder: PropTypes.string,
    disabled: PropTypes.string,
};

SelectBox.defaultProps = {
    options: {},
    name: '',
    selected: '',
    placeholder: '',
    disabled: false,
}

export default SelectBox;
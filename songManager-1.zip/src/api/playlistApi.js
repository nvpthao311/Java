import axiosClient from "api/axiosClient";

const PlaylistApi = {
    findAll: (params) => {
        const url = '/playlists';
        return axiosClient.get(url, {params});
    },

    findById: (id) => {
        const url = `/playlists/${id}`;
        return axiosClient.get(url);
    },

    findByName: (name, params) => {
        const url = `/playlists/name/${name}`;
        return axiosClient.get(url, {params});
    },

    create: (data) => {
        const url = '/playlists';
        return axiosClient.post(url, data);
    },

    update: (id, data) => {
        const url = `/playlists/${id}`;
        return axiosClient.put(url, data);
    },

    remove: (id) => {
        const url = `/playlists/${id}`;
        return axiosClient.delete(url);
    },
}
export default PlaylistApi;
package com.example.demo.Service;

import com.example.demo.Model.User;
import com.example.demo.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    public User getUserById (Long id) {
        return userRepository.findById(id);
    }

    public User createUser (User user) {
        return userRepository.save(user);
    }

    public void deleteUser (Long id){
        userRepository.deleteById(id);
    }

    public User updateUser (Long id, User userDetails) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {

            User user = optionalUser.get();
            user.setUsername(userDetails.getUsername());
            user.setEmail(userDetails.getEmail());

            userRepository.save(user);
            return user;
        }
        return null;
    }
}
























package com.example.demo.Controller;

import com.example.demo.Service.UserService;
import com.example.demo.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    //lay toan bo danh sach cac users
    @GetMapping
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }

    //lay thong tin mot user thong qua id
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id){
        User user = userService.getUserById(id);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
        /*
        Nếu đúng trẻ về HTTP 200 OK + user
        Nếu sai trả về HTTP 404 Not Found
         */
    }

    //Tao moi user
    @PostMapping
    public User createUser (@RequestBody User user){
        return userService.createUser(user);
    }

    //Cap nhat user theo id
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser (@PathVariable long id, @RequestBody User userDetails ){
        User updateUser = userService.updateUser(id, userDetails);
        return updateUser != null ? ResponseEntity.ok(updateUser) : ResponseEntity.notFound().build();
    }

    //Xoa User theo id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> daleteUser (@PathVariable long id){
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
}

package com.example.demo.Repository;

import com.example.demo.Model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Transactional
public class UserRepository /*extends JpaRepository<User, long>*/{
    /*
    Bạn không cần viết code xử lý, Spring Boot tự động cung cấp các hàm như:
    save(user) → Lưu user mới vào database.
    findById(id) → Tìm user theo ID.
    findAll() → Lấy danh sách tất cả users.
    deleteById(id) → Xóa user theo ID.
    */

    @PersistenceContext
    private EntityManager entityManager;

    public List<User> findAll(){
        return entityManager.createNamedQuery("Select u form User u", User.class).getResultList();

    }

    public User findById (long id){
        User user = entityManager.find(User.class, id);
        return user;
    }

    public User save(User user) {
        entityManager.persist(user);
        return user;
    }

    public void deleteById (long id){
        User user = entityManager.find(User.class, id);
        if(user != null){
            entityManager.remove(user);
        }
    }

}

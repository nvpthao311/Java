package com.example.demo.Model;

import jakarta.persistence.*;

@Entity // Danh dau day la mot entity - bang trong database
@Table(name = "users") // dat ten cho bang la "users" trong database
public class User {

    @id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // tu dong tang
    private Long id;

    @Column(name = "username", nullable = false, unique = true)
    private String username;

    @Column(name = "email", nullable = false, unique = true)
    private String email;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}

package com.example.demo.Exception;

public class StudentHasATeacher extends RuntimeException{
    public StudentHasATeacher(Long id_student, Long id_teacher){
        super("Student ID- " + id_student + "has a teacher ID-" + id_teacher);
    }
}

import React from 'react';
import PropTypes from 'prop-types';
import { Button, FormGroup} from 'reactstrap';
import { Formik, Form, FastField } from 'formik';

import InputField from 'custom-fields/InputField';

import * as Yup from 'yup';

function PlaylistForm(props) {
    const { initialValues, onSubmit, onCancel} = props;

    const validationSchema = Yup.object().shape({
        name: Yup.string().required(),
    })

    return(
        <Formik
            initialValues = {initialValues}
            validationSchema = {validationSchema}
            onSubmit = {onSubmit}
            onCancel = {onCancel}
            enableReinitialize
        >
            {formikProps => {
                const { values, errors, touched } = formikProps;
                console.log({ values, errors, touched });

                return(
                    <Form className="song-playlist-form">
                        <FastField
                            name="name"
                            component={InputField}

                            label="Name"
                            placeholder="Eg: Hello"
                        />
                        <FormGroup className="submit-cancel">
                            <Button type="submit" color="primary">
                                Apply
                            </Button>
                            <Button onClick={onCancel} type="cancel" color="primary">
                                Cancel
                            </Button>
                        </FormGroup>
                    </Form>
                )
            }}
        </Formik>
    );
}

PlaylistForm.propTypes = {
    initialValues: PropTypes.object,
    onSubmit: PropTypes.func.isRequired,
    onCancel: PropTypes.func.isRequired,
}

PlaylistForm.defaultProps = {
    initialValues: { name: ''},
    onSubmit: null,
    onCancel: null,
}

export default PlaylistForm;
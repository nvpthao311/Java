import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { FaTrash, FaEdit, FaPlus, FaSearch  } from 'react-icons/fa';

import PlaylistForm from 'features/Playlist/components/PlaylistForm';

function PlaylistList(props) {
    const { playlists, onAdd, onEdit, onDelete, onSearch} = props;

    const [selected, setSelected] = useState([]);
    const [edited, setEdited] = useState(null);

    // Select
    const isSelected = (id) => selected.includes(id);
    const isAllSelected = selected.length === playlists.length && playlists.length > 0;

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allIds = playlists.map((playlist) => playlist.id);
            setSelected(allIds);
        } else {
            setSelected([]);
        }
    };

    const handleSelectPlaylist = (id) => {
        setSelected((prevSelected) =>
            prevSelected.includes(id)
            ? prevSelected.filter((playlistId) => playlistId !== id)
            : [...prevSelected, id]
        );
    };

    // Delete
    const handleDeletePlaylists = () => {
        const confirmDelete = window.confirm('Bạn có chắc chắn muốn xóa playlist này không?');
        if(selected && confirmDelete){
            selected.map((id) => {
                onDelete(id);
            });
            setSelected([]);
        }
    }

    return (
        <>
        <div className="song-playlist-header">
            <h4>Playlist Manager</h4>
            <div>
                <button onClick={onAdd} className="btn-action">
                    <FaPlus /> Add
                </button>
                <button onClick={handleDeletePlaylists} className="btn-action">
                    <FaTrash /> Delete
                </button>
                <button onClick={onSearch} className="btn-action">
                    <FaSearch /> Search
                </button>
            </div>
        </div>

        <table className="song-playlist-table">
            <thead>
                <tr>
                    <th>
                        <input
                            type="checkbox"
                            checked={isAllSelected}
                            onChange={handleSelectAll}
                        />
                    </th>
                    <th>Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody className="song-playlist-table__item">
                {playlists.map((playlist) => (
                    <React.Fragment key={playlist.id}>
                        <tr key={playlists.id}>
                            <td>
                            <input
                                type="checkbox"
                                checked={isSelected(playlist.id)}
                                onChange={() => handleSelectPlaylist(playlist.id)}
                            />
                            </td>

                            <td>{playlist.name}</td>

                            <td>
                                <button onClick={() => setEdited(playlist)} className="btn-action">
                                    <FaEdit /> Edit
                                </button>
                                <button onClick={() => onDelete(playlist.id)} className="btn-action">
                                    <FaTrash /> Delete
                                </button>
                            </td>
                        </tr>

                        {edited?.id === playlist.id && (
                            <tr>
                                <td colSpan="4">
                                    <PlaylistForm
                                        initialValues={edited}
                                        onSubmit={onEdit}
                                        onCancel={() => setEdited(null)}
                                    />
                                </td>
                            </tr>
                        )}
                    </React.Fragment>
                ))}
            </tbody>
        </table>
        </>
    );
}

PlaylistList.propTypes = {
    playlists: PropTypes.arrayOf(
        PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        artist: PropTypes.string.isRequired,
    })
    ).isRequired,

    onAdd: PropTypes.func.isRequired,
    onEdit: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    onSearch: PropTypes.func.isRequired,
};

export default PlaylistList;

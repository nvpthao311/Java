import React from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate  } from 'react-router-dom';

import { addPlaylist } from 'features/Playlist/PlaylistSlice'
import PlaylistForm from 'features/Playlist/components/PlaylistForm';

function AddPage() {
    const dispatch = useDispatch ();
    const navigate  = useNavigate ();

    const handleSubmit = (playlist) => {
        console.log('Form submit:', playlist);

        const action = addPlaylist(playlist);
        console.log({action});
        dispatch(action);

        navigate("/music/playlists");
    }

    const handleCancel = () => {
        navigate("/music/playlists");
    }

    return (
        <div className="add_page">
            <PlaylistForm
                onSubmit={handleSubmit}
                onCancel={handleCancel}
            />
        </div>
    );
}

export default AddPage;
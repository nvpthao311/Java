import React from "react";
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate } from 'react-router-dom';

import PlaylistList from 'features/Playlist/components/PlaylistList';
import {deletePlaylist, editPlaylist} from 'features/Playlist/PlaylistSlice';

function MainPage() {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const playlists = useSelector(state => state.playlists.list)

    const handleClickSongs = () => {
        navigate('/music/songs');
    };

    const handleEdit = (id) => {
        console.log('Edit playlist:', id);

        const action = editPlaylist(id);
        console.log({action});
        dispatch(action);
    }

    const handleDelete = (id) => {
        console.log('Deleted playlist:', id);

        const action = deletePlaylist(id);
        console.log({action});
        dispatch(action);
    }

    const handleAdd = () => {
        navigate("/music/playlists/add");
    }

    const handleSearch = () => {
        navigate("/music/search");
    }

    return (
        <div className="container">
            <div className="selections">
                <button onClick={handleClickSongs}>Songs</button>
                <button>Playlists</button>
            </div>

            <aside className="container__body_menu">
                <h3>Home > Playlists</h3>
                <div class="divider"></div>
                <PlaylistList
                    playlists ={playlists}
                    onAdd ={handleAdd}
                    onEdit ={handleEdit}
                    onDelete ={handleDelete}
                    onSearch ={handleSearch}
                />
            </aside>
        </div>

    );
}

export default MainPage;
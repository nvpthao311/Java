import { createSlice } from '@reduxjs/toolkit';

let nextId = 1;

const playlist = createSlice({
    name: 'playlists',
    initialState: {
        list: [],
        filtered: [],
    },
    reducers: {
        addPlaylist: (state, action) => {
            const newPlaylist = {
                id: nextId++,
                ...action.payload,
            };
            state.list.push(newPlaylist);
        },

        deletePlaylist: (state, action) => {
            const deletePlaylistId = action.payload;
            state.list = state.list.filter(playlist => playlist.id !== deletePlaylistId);
        },

        editPlaylist: (state, action) => {
            const newPlaylist =  action.payload;
            const playlistIndex = state.list.findIndex(playlist => playlist.id === newPlaylist.id);

            if(playlistIndex != null){
                state.list[playlistIndex] = newPlaylist;
            }
        },

        findByPlaylistName: (state, action) => {
            const keyword = action.payload.toLowerCase();
            state.filtered = state.list.filter((song) =>
                song.name.toLowerCase().includes(keyword)
            );
        }
    }
})

const { reducer, actions } = playlist;
export const {addPlaylist, deletePlaylist, editPlaylist, findByPlaylistName} = actions;
export default reducer;
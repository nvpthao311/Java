import React from 'react';
import { useNavigate } from "react-router-dom";

function MainPage() {
    const navigate = useNavigate();

    const handleClickSongs = () => {
        navigate('/music/songs');
    };

    const handleClickPlaylists = () => {
        navigate('/music/playlists');
    };

    const handleClickSearch = () => {
        navigate('/music/search');
    }

    return(
        <div className="selections">
            <button onClick={handleClickSongs}>Songs</button>
            <button onClick={handleClickPlaylists}>Playlists</button>
            <button onClick={handleClickSearch}>Search</button>
        </div>
    );
}

export default MainPage;
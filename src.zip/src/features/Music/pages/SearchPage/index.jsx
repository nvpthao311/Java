import React, { useState } from 'react';
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate  } from 'react-router-dom';

import { findByPlaylistName } from 'features/Playlist/PlaylistSlice';
import { findBySongName } from 'features/Song/SongSlice';
import './SearchPage.scss'

function SearchPage() {
    const [query, setQuery] = useState();

    const songs = useSelector((state) => state.songs.filtered);
    const playlists = useSelector(state => state.playlists.filtered)

    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    const filtered = (name) => {
        console.log('find by name:', name);

        const action = findByPlaylistName(name);
        console.log({action});
        dispatch(action);

        const action2 = findBySongName(name);
        console.log({action2});
        dispatch(action2);
    }

    const handleClickSong = (id) => {
        navigate("/music/songs");
    }
    const handleClickPlaylist = (id) => {
        navigate("/music/playlists");
    }


    return (
        <div className="search-page">
            <h2>Search</h2>
            <input
                type="text"
                placeholder="Search by song or playlist name..."
                value={query}
                onChange={(e) => filtered(e.target.value)}
                className="search-input"
            />

            <div className="list">
                {(songs.length > 0 || playlists.length > 0) ? (
                <>
                    {songs.length > 0 && songs.map((song) => (
                        <li key={song.id} onClick={() => handleClickSong(song.id)}>
                            Song:
                            <strong>{song.name}</strong>
                            <span>{song.artist}</span>
                        </li>
                    ))}

                    {playlists.length > 0 && playlists.map((playlist) => (
                        <li key={playlist.id} onClick={() => handleClickPlaylist(playlist.id)}>
                            Playlist:
                            <strong>{playlist.name}</strong>
                        </li>
                    ))}
                </>
                ) : (
                    <li>Không tìm thấy.</li>
                )}
            </div>
        </div>
    );
}

export default SearchPage;
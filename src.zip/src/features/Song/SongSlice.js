import { createSlice } from '@reduxjs/toolkit';

let nextId = 1;

const song = createSlice({
    name: 'songs',
    initialState: {
        list: [],
        filtered: [],
    },
    reducers: {
        addSong: (state, action) => {
            const newSong = {
                id: nextId++,
                ...action.payload,
            };
            state.list.push(newSong);
        },

        deleteSong: (state, action) => {
            const deleteSongId = action.payload;
            state.list = state.list.filter(song => song.id !== deleteSongId);
        },

        editSong: (state, action) => {
            const newSong =  action.payload;
            const songIndex = state.list.findIndex(song => song.id === newSong.id);

            if(songIndex != null){
                state.list[songIndex] = newSong;
            }
        },

        findBySongName: (state, action) => {
            const keyword = action.payload.toLowerCase();
            state.filtered = state.list.filter((song) =>
                song.name.toLowerCase().includes(keyword)
            );
        }
    }
})

const { reducer, actions } = song;
export const {addSong, deleteSong, editSong, findBySongName} = actions;
export default reducer;
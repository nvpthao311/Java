import React from 'react';
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate, Link} from 'react-router-dom';

import { deleteSong, editSong } from 'features/Song/SongSlice';
import SongList from 'features/Song/components/SongList';
import "./MainPage.scss";

function MainPage() {
    const songs = useSelector(state => state.songs.list)

    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    const handleEdit = (songId) => {
        console.log('Edit song:', songId);

        const action = editSong(songId);
        console.log({action});
        dispatch(action);
    }

    const handleDelete = (songId) => {
        console.log('Deleted song:', songId);

        const action = deleteSong(songId);
        console.log({action});
        dispatch(action);
    }

    const handleAdd = () => {
        navigate("/music/songs/add");
    }

    const handleSearch = () => {
        navigate("/music/search");
    }

    return (
        <div className="container">
            <div className="selections">
                <button>Songs</button>
                <Link to="/music/playlists"><button>Playlists</button></Link>
            </div>

            <aside className="container__body_menu">
                <h3>Home > Songs</h3>
                <div class="divider"></div>
                <SongList
                    songs ={songs}
                    onAdd ={handleAdd}
                    onEdit ={handleEdit}
                    onDelete ={handleDelete}
                    onSearch ={handleSearch}
                />
            </aside>
        </div>

    );
}

export default MainPage;
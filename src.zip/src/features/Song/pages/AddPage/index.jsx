import React from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate  } from 'react-router-dom';

import { addSong } from 'features/Song/SongSlice'
import SongForm from 'features/Song/components/SongForm';

function AddPage() {
    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    const handleSubmit = (song) => {
        console.log('Form submit:', song);

        const action = addSong(song);
        console.log({action});
        dispatch(action);

        navigate("/music/songs");
    }

    const handleCancel = () => {
        navigate("/music/songs");
    }

    return (
        <div className="add_page">
            <SongForm
                onSubmit={handleSubmit}
                onCancel={handleCancel}
            />
        </div>
    );
}

export default AddPage;
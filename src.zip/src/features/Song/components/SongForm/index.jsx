import React from 'react';
import PropTypes from 'prop-types';
import { Button, FormGroup} from 'reactstrap';
import { Formik, Form, FastField } from 'formik';

import InputField from 'custom-fields/InputField';
import FileUploadField from 'custom-fields/FileUploadField'
import './SongForm.scss'

import * as Yup from 'yup';

function SongForm(props) {
    const { initialValues, onSubmit, onCancel} = props;

    const validationSchema = Yup.object().shape({
        name: Yup.string().required(),
        artist: Yup.string().required(),
        filepath: Yup.string().required(),
    })

    return(
        <Formik
            initialValues = {initialValues}
            validationSchema = {validationSchema}
            onSubmit = {onSubmit}
            onCancel = {onCancel}
            enableReinitialize
        >
            {formikProps => {
                const { values, errors, touched } = formikProps;
                console.log({ values, errors, touched });

                return(
                    <Form className="song-playlist-form">
                        <FastField
                            name="name"
                            component={InputField}

                            label="Name"
                            placeholder="Eg: Hello"
                        />
                        <FastField
                            name="artist"
                            component={InputField}

                            label="Artist"
                            placeholder="Eg: Adele"
                        />

                        <FastField
                            name="filepath"
                            component={FileUploadField}

                            label="Filepath"
                        />

                        <FormGroup className="submit-cancel">
                            <Button type="submit" color="primary">
                                Apply
                            </Button>
                            <Button onClick={onCancel} type="cancel" color="primary">
                                Cancel
                            </Button>
                        </FormGroup>
                    </Form>
                )
            }}
        </Formik>
    );
}

SongForm.propTypes = {
    initialValues: PropTypes.object,
    onSubmit: PropTypes.func.isRequired,
    onCancel: PropTypes.func.isRequired,
}

SongForm.defaultProps = {
    initialValues: { name: '', artist: '', filepath: '' },
    onSubmit: null,
    onCancel: null,
}

export default SongForm;
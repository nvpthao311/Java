import React from 'react';
import { Route, Routes, useMatch, Navigate } from 'react-router-dom';

import NotFound from 'components/NotFound';
import Login from 'features/Auth/pages/Login'

Auth.propTypes = {};

function Auth() {
    const match = useMatch('/auth');
    console.log({ match });

    return(
        <Routes>
            <Route path="/" element={<Navigate to="login" />} />
            <Route path="/login" element={<Login />} />
            <Route path="*" element={<NotFound />} />
        </Routes>
    );
}

export default Auth;
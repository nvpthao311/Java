const fakeAuth = {
    isAuthenticated: false,

    login(callback) {
        this.isAuthenticated = true;
        setTimeout(callback, 100);
    },

    logout(callback) {
        this.isAuthenticated = false;
        setTimeout(callback, 100);
    },

    checkAuth() {
        return this.isAuthenticated;
    }
};

export default fakeAuth;

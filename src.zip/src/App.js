import React, { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

import NotFound from 'components/NotFound';
import PrivateRoute from 'components/PrivateRoute';
import Music from 'features/Music'
import './App.scss';

const Auth = lazy(() => import('features/Auth'));

function App() {
    return (
        <Suspense fallback={<div>Loading...</div>}>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Navigate to="/auth" />} />
                    <Route path="/auth/*" element={<Auth />} />

                    <Route path="/music/*" element={
                        <PrivateRoute>
                            <Music />
                        </PrivateRoute>
                    }/>

                    <Route path="*" element={<NotFound />} />
                </Routes>
            </BrowserRouter>
        </Suspense>
    );
}

export default App;


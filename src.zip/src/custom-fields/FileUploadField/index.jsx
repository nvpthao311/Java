import PropTypes from 'prop-types';
import React from 'react';
import { FormFeedback, FormGroup, Label } from 'reactstrap';
import { ErrorMessage } from 'formik';

FileUploadField.propTypes = {
    field: PropTypes.object.isRequired,
    form: PropTypes.object.isRequired,

    label: PropTypes.string,
    disabled: PropTypes.bool,
};

FileUploadField.defaultProps = {
    label: '',
    disabled: false,
};

function FileUploadField(props) {
    const {
        field, form,
        label, disabled,
    } = props;
    const { name } = field;
    const { errors, touched, setFieldValue } = form;

    const showError = errors[name] && touched[name];

    const handleChangeFile = (event) => {
        const file = event.target.files[0];
        if (file) {
            setFieldValue(name, file);
        }
    };

    return (
        <FormGroup>
            {label && <Label for={name}>{label}</Label>}
            <input
                id={name}
                name={name}
                type="file"
                accept="audio/mp3,audio/mpeg"
                disabled={disabled}
                onChange={handleChangeFile}
                className={`form-control ${showError ? 'is-invalid' : ''}`}
            />
            <ErrorMessage name={name} component={FormFeedback} />
        </FormGroup>
    );
}

export default FileUploadField;

import { configureStore } from '@reduxjs/toolkit';
import songReducer from 'features/Song/SongSlice';
import playlistReducer from 'features/Playlist/PlaylistSlice'

const rootReducer = {
    songs: songReducer,
    playlists: playlistReducer,
}

const store = configureStore({
    reducer: rootReducer,
});

export default store;
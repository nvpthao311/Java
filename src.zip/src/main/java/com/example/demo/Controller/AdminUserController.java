package com.example.demo.Controller;

import com.example.demo.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/users")
@PreAuthorize("hasRole('ADMIN')") // toàn bộ controller chỉ admin mới truy cập
public class AdminUserController {

    @Autowired
    private UserDetailsService userDetailsService;

//    @GetMapping
//    public List<User> getAllUsers() {
//        return userDetailsService.findAll();
//    }
//
//    @PostMapping
//    public User createUser(@RequestBody User user) {
//        return userDetailsService.create(user);
//    }
//
//    @PutMapping("/{id}")
//    public User updateUser(@PathVariable Long id, @RequestBody User user) {
//        return userDetailsService.update(id, user);
//    }
//
//    @DeleteMapping("/{id}")
//    public void deleteUser(@PathVariable Long id) {
//        userDetailsService.delete(id);
//    }
}


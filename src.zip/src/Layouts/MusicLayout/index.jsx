import { Outlet } from 'react-router-dom';
import { useNavigate } from "react-router-dom";

import backgroundVideo from "assets/images/background.mp4";
import logo from 'assets/images/logo.png';
import "./MusicLayout.scss";

export default function MainLayout() {
    const navigate = useNavigate();
    const handleClickLogo = () => {
        console.log("qua music")
        navigate('/music');
    };

    return (
    <>
        <video autoPlay loop muted>
            <source src={backgroundVideo} type="video/mp4" />
        </video>

        <div className="overlay">
            <header className="header_footer_home">
                <div className="logo" >
                    <img onClick={handleClickLogo} src={logo} alt="logo" />
                    <h2>
                        <span className="danger">MUSIC</span>-MANAGER
                    </h2>
                </div>

                <div className="user">
                    <h3>Admin</h3>
                    <h3> | </h3>
                    <h3>Language</h3>
                </div>
            </header>

            <main>
                <Outlet />
            </main>

            <footer className="header_footer_home">
                @2025 ThaoVo
            </footer>
        </div>
    </>
    );
}

import { Navigate } from 'react-router-dom';
import fakeAuth from 'services/authService';

function PrivateRoute({ children }) {
    const isLoggedIn = fakeAuth.checkAuth();

    if (!isLoggedIn) {
        return <Navigate to="/auth/login" />;
    }

    return children;
}

export default PrivateRoute;

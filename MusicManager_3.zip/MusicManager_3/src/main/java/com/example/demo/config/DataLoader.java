package com.example.demo.config;

import com.example.demo.Model.Playlist;
import com.example.demo.Model.PlaylistSong;
import com.example.demo.Model.Song;
import com.example.demo.Repository.PlaylistRepository;
import com.example.demo.Repository.PlaylistSongRepository;
import com.example.demo.Repository.SongRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.*;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner loadSongs(SongRepository songRepository) {
        return args -> {
            if (songRepository.count() == 0) {
                List<Song> songs = new ArrayList<>();
                for (int i = 1; i <= 100; i++) {
                    Song song = new Song();
                    song.setName("Song " + i);
                    song.setArtist("Artist " + ((i % 10) + 1));
                    song.setGenre(i % 2 == 0 ? "Pop" : "Rock");
                    song.setFilePath("/music/song" + i + ".mp3");
                    songs.add(song);
                }
                songRepository.saveAll(songs);
            }
        };
    }

    @Bean
    CommandLineRunner loadPlaylists(PlaylistRepository playlistRepository) {
        return args -> {
            if (playlistRepository.count() == 0) {
                List<Playlist> playlists = new ArrayList<>();
                for (int i = 1; i <= 100; i++) {
                    Playlist playlist = new Playlist();
                    playlist.setName("Playlist " + i);
                    playlists.add(playlist);
                }
                playlistRepository.saveAll(playlists);
            }
        };
    }

    @Bean
    CommandLineRunner loadPlaylistSongs(PlaylistRepository playlistRepository, SongRepository songRepository, PlaylistSongRepository playlistSongRepository) {
        return args -> {
            List<Playlist> playlists = playlistRepository.findAll();
            List<Song> songs = songRepository.findAll();

            List<PlaylistSong> playlistSongs = createRandomPlaylistSongs(playlists, songs);

            // Lưu vào database
            playlistSongRepository.saveAll(playlistSongs);
        };
    }

    public List<PlaylistSong> createRandomPlaylistSongs(List<Playlist> playlists, List<Song> songs) {
        List<PlaylistSong> playlistSongs = new ArrayList<>();
        Set<String> uniqueCombinations = new HashSet<>();

        Random random = new Random();
        for (int i = 0; i < 50; i++) {
            Playlist playlist = playlists.get(random.nextInt(100));
            Song song = songs.get(random.nextInt(100));

            // Đảm bảo không trùng lặp combination giữa Playlist và Song
            String combination = playlist.getId() + "_" + song.getId();
            if (uniqueCombinations.contains(combination)) {
                i--;
                continue;
            }

            uniqueCombinations.add(combination);
            PlaylistSong playlistSong = new PlaylistSong(playlist, song);
            playlistSongs.add(playlistSong);
        }
        return playlistSongs;
    }
}



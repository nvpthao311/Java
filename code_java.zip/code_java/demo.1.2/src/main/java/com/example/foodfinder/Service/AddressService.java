package com.example.foodfinder.Service;

import com.example.foodfinder.Model.Address;
import com.example.foodfinder.Model.Dish;
import com.example.foodfinder.Repository.AddressRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AddressService {
    private final AddressRepository addressRepository;

    //create
    public Address createAddress(Address address){
        addressRepository.save(address);
        return address;
    }

    //read
    public Address getAddressById(Long id){
        return addressRepository.findById(id).orElseThrow( () -> new RuntimeException("Address Not Found!!!"));
    }

    public List<Address> getALlAddresses(){
        return addressRepository.findAll();
    }

    //update
    public Address updateAddress(Long id, Address address){
        Address updatedAddress = getAddressById(id);

        updatedAddress.setName(address.getName());
        updatedAddress.setLocation(address.getLocation());
        updatedAddress.setReview(address.getReview());

        return addressRepository.save(updatedAddress);
    }

    //delete
    public void deleteAddress(Long id){
        addressRepository.deleteById(id);
    }


}


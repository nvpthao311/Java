package com.example.foodfinder.Service;

import com.example.foodfinder.Enum.Role;
import com.example.foodfinder.Model.User;
import com.example.foodfinder.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder; //Tại sao lại dùng passwordencoder

    public User registerUser(String username, String passwrod, Role role){
        if(userRepository.findByUsername(username).isPresent()){
            throw new RuntimeException("Username already exists!");
        }
        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(passwrod));
        user.setRole(role);
        return userRepository.save(user);
    }
}

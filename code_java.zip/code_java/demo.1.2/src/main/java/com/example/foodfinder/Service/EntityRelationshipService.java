package com.example.foodfinder.Service;

import com.example.foodfinder.Model.Address;
import com.example.foodfinder.Model.Dish;

import java.util.List;

public interface EntityRelationshipService {
    void updateDishAddresses(Long dishId, List<Address> addresses);
    void updateAddressDishes(Long addressId, List<Dish> dishes);
}

package com.example.foodfinder.Service;

import com.example.foodfinder.Model.Address;
import com.example.foodfinder.Model.Dish;
import com.example.foodfinder.Repository.AddressRepository;
import com.example.foodfinder.Repository.DishRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DishService implements EntityRelationshipService{
    private final DishRepository dishRepository;
    private final AddressRepository addressRepository;

    //Create
    public Dish createDish(Dish dish){
        return dishRepository.save(dish);
    }

    //read
    public Dish getDishById(Long id){
        return dishRepository.findById(id).orElseThrow(() -> new RuntimeException("Dish No Found!!!"));
    }

    public List<Dish> getAllDishes(){
        return dishRepository.findAll();
    }

    //update
    public Dish updateDish(Long id, Dish dish){
        Dish updatedDish = getDishById(id);

        updatedDish.setName(dish.getName());
        return dishRepository.save(updatedDish);
    }

    //delete
    public void deleteDish(Long id){
        dishRepository.deleteById(id);
    }

    //
    @Override
    public void updateDishAddresses(Long dishId, List<Address> addresses) {
        Dish dish = getDishById(dishId);
        dish.getAddresses().clear();
        dish.getAddresses().addAll(addresses);
        dishRepository.save(dish);
    }

    @Override
    public void updateAddressDishes(Long addressId, List<Dish> dishes) {
        Address address = addressRepository.findById(addressId)
                .orElseThrow(() -> new RuntimeException("Address Not Found!!!"));

        for (Dish dish : address.getDishes()){
            dish.getAddresses().remove(address);
            dishRepository.save(dish);
        }
        for (Dish dish : dishes){
            dish.getAddresses().add(address);
            dishRepository.save(dish);
        }
    }
}

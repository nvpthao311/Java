package com.example.foodfinder.Controller;

import com.example.foodfinder.Model.Address;
import com.example.foodfinder.Model.Dish;
import com.example.foodfinder.Service.AddressService;
import com.example.foodfinder.Service.EntityRelationshipService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/address")
@AllArgsConstructor
public class AddressController {
    private final AddressService addressService;
    private final EntityRelationshipService relationshipService;

    @GetMapping
    public List<Address> getAllAddresses(){
        return addressService.getALlAddresses();
    }

    @GetMapping("/{id}")
    public Address getAddressById(@PathVariable Long id){
        return addressService.getAddressById(id);
    }

    @PostMapping
    public Address createAddress(@RequestBody Address address){
        return addressService.createAddress(address);
    }

    @PutMapping("/{id}")
    public Address updateAddress(@PathVariable Long id,@RequestBody Address address){
        return addressService.updateAddress(id, address);
    }

    @DeleteMapping("/{id}")
    public void deleteAddress(@PathVariable Long id) {
        addressService.deleteAddress(id);
    }

    @PutMapping("/{id}/dishes")
    public ResponseEntity<?> updateAddressDishes (@PathVariable Long addressId, @RequestBody List<Dish> dishes){
        relationshipService.updateAddressDishes(addressId, dishes);
        return ResponseEntity.ok("Updated address dishes successfully!");
    }
}

package com.example.foodfinder.Controller;

import com.example.foodfinder.Model.Address;
import com.example.foodfinder.Model.Dish;
import com.example.foodfinder.Service.DishService;
import com.example.foodfinder.Service.EntityRelationshipService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/dish")
@RequiredArgsConstructor
public class DishController {
    private final DishService dishService;
    private final EntityRelationshipService relationshipService;

    @GetMapping
    public List<Dish> getAllDishes(){
        return dishService.getAllDishes();
    }

    @GetMapping("/{id}")
    public Dish getDishById(@PathVariable Long id){
        return dishService.getDishById(id);
    }

    @PostMapping
    public Dish createDish(@RequestBody Dish dish){
        return dishService.createDish(dish);
    }

    @PutMapping("/{id}")
    public Dish updateDish(@PathVariable Long id,@RequestBody Dish dish){
        return dishService.updateDish(id, dish);
    }

    @DeleteMapping("/{id}")
    public void deleteDish(@PathVariable Long id){
        dishService.deleteDish(id);
    }

    @PutMapping("/{dishId}/addresses")
    public ResponseEntity<?> updateDishAddresses(
            @PathVariable Long dishId,
            @RequestBody List<Address> addresses
    ) {
        relationshipService.updateDishAddresses(dishId, addresses);
        return ResponseEntity.ok("Updated dish addresses successfully!");
    }
}

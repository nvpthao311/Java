package com.example.foodfinder.Enum;

public enum Role {
    USER,
    ADMIN
}

package com.example.foodfinder.Service;

import com.example.foodfinder.Model.Address;
import com.example.foodfinder.Model.Dish;
import com.example.foodfinder.Repository.AddressRepository;
import com.example.foodfinder.Repository.DishRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@WebMvcTest(DishService.class)
public class DishServiceTest {

    @Mock
    private DishRepository dishRepository;

    @Mock
    private AddressRepository addressRepository;

    @InjectMocks
    private DishService dishService;

    private Dish dish1, dish2;
    private Address address1, address2;

    @BeforeEach
    void setUp(){
        //Tạo dữ liệu giả lập
        dish1 = new Dish();
        dish1.setId(1L);
        dish1.setName("Bún riêu");
        dish1.setAddresses(new ArrayList<>());
        dish1.getAddresses().add(address1);


        dish2 = new Dish();
        dish2.setId(2L);
        dish2.setName("Bún đỏ");
        dish2.setAddresses(new ArrayList<>());

        address1 = new Address();
        address1.setId(1L);
        address1.setName("Bún đỏ,bún riêu lề đường");
        address1.setLocation("đỗ xuân hợp");
        address1.setReview("hơi ít");

        address2 = new Address();
        address2.setId(2L);
        address2.setName("Bún đỏ,bún riêu");
        address2.setLocation("đầu đường nam hòa, đỗ xuân hợp");
        address1.setReview("ok á");
    }

    @Test
    void testUpdateDishAddresses(){
        when(dishRepository.findById(1L)).thenReturn(Optional.of(dish1));
        when(dishRepository.save(any(Dish.class))).thenReturn(dish1);

        List<Address> newAddresses = Arrays.asList(address2);

        dishService.updateDishAddresses(1L, newAddresses);

        assertEquals(1, dish1.getAddresses().size());
        assertTrue(dish1.getAddresses().contains(address1));
        assertTrue(dish1.getAddresses().contains(address2));

        verify(dishRepository, times(1)).save(dish1);
    }

    @Test
    void testUpdateAddressDishes(){
        when(addressRepository.findById(2L)).thenReturn(Optional.of(address2));
        when(addressRepository.save(any(Address.class))).thenReturn(address2);

        List<Dish> newDishes = Arrays.asList(dish2);

        dishService.updateAddressDishes(2L, newDishes);

        assertTrue(address2.getDishes().contains(dish2));
    }


}

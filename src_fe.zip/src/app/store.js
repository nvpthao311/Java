import { configureStore } from '@reduxjs/toolkit';
import songReducer from 'features/Song/SongSlice';
import playlistReducer from 'features/Playlist/PlaylistSlice';
import playlistSongReducer from 'features/PlaylistSong/PlaylistSongSlice';
import authReducer from 'features/Auth/AuthSlice';
import userReducer from 'features/User/UserSlice';

const rootReducer = {
    songs: songReducer,
    playlists: playlistReducer,
    playlistSong: playlistSongReducer,
    auth: authReducer,
    users: userReducer,
}

const store = configureStore({
    reducer: rootReducer,
});

export default store;
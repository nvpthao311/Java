export const LANGUAGE_OPTIONS = [
    { value: 1, label: 'English'},
    { value: 2, label: 'Vietnamese'},
];
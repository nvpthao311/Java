import axios from 'axios';
import queryString from 'query-string';
import authService from 'services/authService';


// Create a custom axios instance with default config
const axiosClient = axios.create({
    baseURL: process.env.REACT_APP_API_URL, // Base URL from environment variables
    headers: {
        'Content-Type': 'application/json', // Set default content type for requests
    },
    paramsSerializer: params => queryString.stringify(params), // Serialize query params
});

// Request interceptor: attach JWT token if available
axiosClient.interceptors.request.use(async (config) => {
    const token = authService.getToken();
    if (token) {
        config.headers.Authorization = `Bearer ${token}`; // attach token to header
    }
    return config;
}, (error) => {
    return Promise.reject(error);
});

// Response interceptor: return data or handle errors
axiosClient.interceptors.response.use((response) => {
    if (response && response.data) {
        return response.data;
    }
}, (error) => {
    return Promise.reject(error);
});

export default axiosClient;

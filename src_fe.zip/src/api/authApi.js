import axiosClient from "api/axiosClient";

const AuthApi = {
    register: (userData) => {
        const url = '/auth/register';
        return axiosClient.post(url, userData);
    },

    login: (credentials) => {
        const url = '/auth/login';
        return axiosClient.post(url, credentials);
    },
};

export default AuthApi;

import axiosClient from "api/axiosClient";

const PlaylistApi = {
    findAll: (params) => {
        const url = '/api/playlists';
        return axiosClient.get(url, {params});
    },

    findById: (id) => {
        const url = `/api/playlists/${id}`;
        return axiosClient.get(url);
    },

    findByName: (name, params) => {
        const url = `/api/playlists/name/${name}`;
        return axiosClient.get(url, {params});
    },

    create: (data) => {
        const url = '/api/playlists';
        return axiosClient.post(url, data);
    },

    update: (id, data) => {
        const url = `/api/playlists/${id}`;
        return axiosClient.put(url, data);
    },

    remove: (id) => {
        const url = `/api/playlists/${id}`;
        return axiosClient.delete(url);
    },

    removeMulti: ( ids ) => {
        const url = '/api/playlists/delete-multi';
        return axiosClient.post(url, ids);
    }
}
export default PlaylistApi;
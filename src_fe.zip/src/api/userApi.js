import axiosClient from "api/axiosClient";

const UserApi = {
    findAll: () => {
        const url = '/api/admin/users';
        return axiosClient.get(url);
    },

    remove: (id) => {
        const url = `/api/admin/users/${id}`;
        return axiosClient.delete(url);
    },
};

export default UserApi;
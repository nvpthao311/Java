import axiosClient from "api/axiosClient";

const PlaylistSongApi =  {
    addSongToPlaylist: (playlistId, songId) => {
       const url = `/api/playlistSong/playlist/${playlistId}/song/${songId}`;
       return axiosClient.post(url);
    },

    removeSongFromPlaylist: (playlistId, songId) => {
        const url = `/api/playlistSong/playlist/${playlistId}/song/${songId}`;
        return axiosClient.delete(url);
    },

    getSongsByPlaylist:(playlistId) => {
        const url = `/api/playlistSong/playlist/${playlistId}/songs`;
        return axiosClient.get(url);
    },

    getPlaylistsBySong: (songId) => {
        const url = `/api/playlistSong/song/${songId}/playlists`;
        return axiosClient.get(url);
    },

}
export default PlaylistSongApi;
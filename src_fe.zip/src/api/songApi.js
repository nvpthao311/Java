import axiosClient from "api/axiosClient";

const SongApi = {
    findAll: (params) => {
        const url = '/api/songs';
        return axiosClient.get(url, {params});
    },

    findById: (id) => {
        const url = `/api/songs/${id}`;
        return axiosClient.get(url)
    },

    findByName: (name, params) => {
        const url = `/api/songs/name/${name}`;
        return axiosClient.get(url, {params})
    },

    create: (data) => {
        const url = '/api/songs';
        return axiosClient.post(url, data);
    },

    update: (id, data) => {
        const url = `/api/songs/${id}`;
        return axiosClient.put(url, data);
    },

    remove: (id) => {
        const url = `/api/songs/${id}`;
        return axiosClient.delete(url);
    },

    removeMulti: ( ids ) => {
        const url = '/api/songs/delete-multi';
        return axiosClient.post(url, ids);
    }
}
export default SongApi;
import React, { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import NotFound from 'components/NotFound';
import PrivateRoute from 'components/PrivateRoute';
import AdminRoute from 'components/AdminRoute';
import Music from 'features/Music';
import 'assets/scss/main.scss';
import './App.scss';

const Auth = lazy(() => import('features/Auth'));
const User = lazy(() => import('features/User'));

function App() {
    return (
        <Suspense fallback={<div className="spinner"/>}>
            <BrowserRouter>
                <ToastContainer />
                <Routes>
                    <Route path="*" element={<NotFound />} />
                    <Route path="/" element={<Navigate to="/auth" />} />
                    <Route path="/auth/*" element={<Auth />} />

                    <Route path="/music/*" element={
                        <PrivateRoute>
                            <Music />
                        </PrivateRoute>
                    }/>

                    <Route path="/users/*" element={
                        <AdminRoute>
                            <User />
                        </AdminRoute>
                    }/>
                </Routes>
            </BrowserRouter>
        </Suspense>
    );
}

export default App;


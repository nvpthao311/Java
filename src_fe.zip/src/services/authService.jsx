const TOKEN_KEY = 'jwt';

const authService = {
    saveToken: (token) => localStorage.setItem(TOKEN_KEY, token),
    getToken: () => localStorage.getItem(TOKEN_KEY),
    removeToken: () => localStorage.removeItem(TOKEN_KEY),
};

export default authService;

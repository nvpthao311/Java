import { jwtDecode } from 'jwt-decode';

const TOKEN_KEY = 'jwt';
const ACCOUNT_KEY = 'ACCOUNT';

const authService = {
    saveToken: (token) => localStorage.setItem(TOKEN_KEY, token),
    getToken: () => localStorage.getItem(TOKEN_KEY),
    removeToken: () => localStorage.removeItem(TOKEN_KEY),

    saveAccount: () => {
        const token = localStorage.getItem(TOKEN_KEY);
        if (!token) return null;
        try {
            const decoded = jwtDecode(token);
            const account = {
                role: decoded?.role,
                username: decoded?.sub,
            }
            localStorage.setItem(ACCOUNT_KEY, JSON.stringify(account))
        } catch (error) {
            console.error('Error when decode token:', error);
        }
    },
    getAccount: () => {
        const data = localStorage.getItem(ACCOUNT_KEY);
        return data ? JSON.parse(data) : { role: '', username: '' };
    },
    removeAccount: () => localStorage.removeItem(ACCOUNT_KEY),
};

export default authService;

import React, { useState } from 'react';
import { useSelector} from 'react-redux';
import PropTypes from 'prop-types';
import { FaTrash, FaEye,FaEyeSlash } from 'react-icons/fa';

function UserList ({
        users = [],
        totalUsers = 0,
        onDelete = () => {},
    }) {
    const [showPassword, setShowPassword] = useState(0);
    const loading = useSelector(state => state.users.loading);

    const handleShowPassword = (userId) => {
        setShowPassword(userId);
    }

    const handleDeleteUser = (userId) =>{
        const confirmDelete = window.confirm('Are you sure you want to delete this account?');
        if(confirmDelete) onDelete(userId);
    }

    return (
        <>
            <div className="song-playlist-header">
                <h4>User Manager</h4>
            </div>
            <h5>You have total <strong>{totalUsers}</strong> users</h5>
            <div className="table-scroll-wrapper">
                {loading ? (
                    <div className="spinner"/>
                ) : (
                <table className="song-playlist-table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Role</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody className="song-playlist-table__item">
                        {users.length > 0 ? (
                            users.map((user) => (
                            <React.Fragment key={user.id}>
                                <tr key={user.id}>
                                    <td>{user.username}</td>
                                    {(showPassword && showPassword === user.id) ? (
                                        <td>{user.password}
                                            <button onClick={() => handleShowPassword('')} className="icon">
                                                <FaEye />
                                            </button>
                                        </td>
                                    ) : (
                                        <button onClick={() => handleShowPassword(user.id)} className="icon">
                                            <FaEyeSlash  />
                                        </button>
                                    )}
                                    <td>{user.role}</td>
                                    <td>
                                        <button className="btn-action" onClick={() => handleDeleteUser(user.id)}>
                                            <FaTrash /> Delete
                                        </button>
                                    </td>
                                </tr>
                            </React.Fragment>
                            ))) : (
                                <tr>
                                    <td colSpan="4">No users found.</td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
                )}
            </div>
        </>
    )
}

UserList.propTypes = {
    users: PropTypes.arrayOf(
        PropTypes.shape({
        id: PropTypes.number.isRequired,
        username: PropTypes.string.isRequired,
        password: PropTypes.string.isRequired,
        role: PropTypes.string.isRequired,
    })).isRequired,

    totalUsers: PropTypes.number.isRequired,
    onDelete: PropTypes.func.isRequired,
}

export default UserList;
import React, {useEffect} from 'react';
import { useSelector, useDispatch} from 'react-redux';

import UserList from 'features/User/components/UserList';
import { fetchUsers, removeUser } from 'features/User/UserSlice';

function MainPage () {
    const users =  useSelector((state) => state.users.users);
    const totalUsers = useSelector((state) => state.users.totalUsers);

    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(fetchUsers());
    }, [dispatch]);

    const handleRemoveUser = (userId) => {
        dispatch(removeUser(userId));
    };

    return (
        <UserList
            users = {users}
            totalUsers = {totalUsers}
            onDelete = {handleRemoveUser}
        />
    );
}
export default MainPage;
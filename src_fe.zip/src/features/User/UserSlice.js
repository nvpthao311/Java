import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import UserApi from 'api/userApi';
import authService from 'services/authService';

// Async actions
export const fetchUsers = createAsyncThunk(
    'users/findAll',
    async ( rejectWithValue ) => {
        try {
            const response = await UserApi.findAll();
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const removeUser  = createAsyncThunk(
    'users/remove',
    async ( id, { rejectWithValue }) => {
        try {
            await UserApi.remove(id);
            console.log("RESPONSE: Remove done!");
            return id;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);

// Slice
const userSlice = createSlice({
    name: 'users',
    initialState: {
        users: [],
        totalUsers: 0,
        loading: false,
    },

    reducers: {},

    extraReducers: (builder) => {
        builder
            //users
            .addCase(fetchUsers.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchUsers.fulfilled, (state, action) => {
                const myUsername = authService.getAccount().username;
                const list = (action.payload || []);

                state.users = list.filter((u) => u.username !== myUsername) ;
                state.totalUsers = (action.payload.length - 1 || 0);
                state.loading = false;
            })
            .addCase(fetchUsers.rejected, (state, action) => {
                state.loading = false;
            })

            //remove user
            .addCase(removeUser.fulfilled, (state, action) => {
                state.users = state.users.filter(u => u.id !== action.payload);
                state.totalUsers = state.totalUsers -1;
            })
    },
});

export default userSlice.reducer;

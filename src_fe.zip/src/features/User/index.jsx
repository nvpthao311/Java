import React from 'react';
import { Route, Routes, useMatch } from 'react-router-dom';

import MainLayout from 'Layouts/MusicLayout';
import ContainerLayout from 'Layouts/ContainerLayout'
import NotFound from 'components/NotFound';
import MainPage from 'features/User/pages/MainPage';

User.propTypes = {};

function User() {
    const match = useMatch('/users');
    console.log({ match });

    return(
        <Routes>
            <Route element={<MainLayout />}>
                <Route element={<ContainerLayout title="User" />}>
                    <Route path="/" element={<MainPage />} />
                    <Route path="*" element={<NotFound />} />
                </Route>
            </Route>
        </Routes>
    );
}

export default User;
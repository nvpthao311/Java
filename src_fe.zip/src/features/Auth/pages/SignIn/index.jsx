import React from 'react';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import { login } from 'features/Auth/AuthSlice';
import SignInForm from 'features/Auth/components/SignInForm';
import backgroundVideo from "assets/images/background.mp4";
import logo from "assets/images/logo.png";
import fakeAuth from 'services/authService';

function SignIn() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const authState = useSelector(state => state.auth);

    const handleSignIn = (values) => {
        dispatch(login(values))
            .unwrap()
            .then(() => {
                toast.success('Login successful!', { autoClose: 1000 });
                navigate('/music');
            })
            .catch((err) => {
                toast.error('Login failed: Incorrect username or password.', { autoClose: 1500 });
            });
    };


    const handleSignUp = () => {
        navigate("/auth/signUp");
    }

    return (
    <>
        <video autoPlay loop muted>
            <source src={backgroundVideo} type="video/mp4" />
        </video>

        <header>
            <div className="logo">
                <img src={logo} alt="logo" />
                <h2>
                    <span className="danger">MUSIC</span>-MANAGER
                </h2>
            </div>
            <div className="btn-signIn-signUp">
                <h3 style={{ color: "white" }}>Don't have an account?</h3>
                <button onClick={() => handleSignUp()}>
                    <h2>Sign up</h2>
                </button>
            </div>
        </header>

        <aside className="content_signIn_signUp">
            <SignInForm onSubmit={handleSignIn} />
        </aside>

        <footer>
            <span>
                This site is protected by <u>ThaoVo</u>.
            </span>
        </footer>
    </>
    );
};

export default SignIn;

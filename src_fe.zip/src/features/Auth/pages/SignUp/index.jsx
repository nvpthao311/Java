import React from 'react';
import { toast } from 'react-toastify';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import { register } from 'features/Auth/AuthSlice';
import SignUpForm from 'features/Auth/components/SignUpForm';
import backgroundVideo from "assets/images/background.mp4";
import logo from "assets/images/logo.png";

function SignUp() {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const authState = useSelector(state => state.auth);

    const handleSignUp = (values) => {
        dispatch(register(values))
            .unwrap()
            .then(() => {
                toast.success('Register successful!', { autoClose: 1000 });
                navigate('/auth/signIn');
            })
            .catch((err) => {
                toast.error('Register failed: Username might already be taken.', { autoClose: 1500 });
            });
    };


    const handleSignIn = () => {
        navigate("/auth/signIn");
    }

    return (
    <>
        <video autoPlay loop muted>
            <source src={backgroundVideo} type="video/mp4" />
        </video>

        <header>
            <div className="logo">
                <img src={logo} alt="logo" />
                <h2>
                    <span className="danger">MUSIC</span>-MANAGER
                </h2>
            </div>
            <div className="btn-signIn-signUp">
                <h3 style={{ color: "white" }}>Do you have an account?</h3>
                <button onClick={() => handleSignIn()}>
                    <h2>Sign in</h2>
                </button>
            </div>
        </header>

        <aside className="content_signIn_signUp">
            <SignUpForm onSubmit={handleSignUp} />
        </aside>

        <footer>
            <span>
                This site is protected by <u>ThaoVo</u>.
            </span>
        </footer>
    </>
    );
};

export default SignUp;

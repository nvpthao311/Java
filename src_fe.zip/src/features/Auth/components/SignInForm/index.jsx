import React from 'react';
import PropTypes from 'prop-types';
import { Formik, Form, FastField } from 'formik';
import { FormGroup, Button } from 'reactstrap';
import * as Yup from 'yup';

import InputField from 'custom-fields/InputField';

function SignInForm({ onSubmit = () => {}}) {
    const initialValues = {
        username: '',
        password: '',
    }

    const validationSchema = Yup.object().shape({
        username: Yup.string().required(),
        password: Yup.string().required(),
    })

    return(
        <Formik
            initialValues = {initialValues}
            validationSchema = {validationSchema}
            onSubmit = {onSubmit}
            enableReinitialize
        >
            {formikProps => {
                return(
                    <Form>
                        <h2>Sign In</h2>

                        <FastField
                            name="username"
                            component={InputField}

                            label="Username"
                            placeholder="Enter your username"
                        />
                        <FastField
                            name="password"
                            type="password"
                            component={InputField}

                            label="Password"
                            placeholder="Enter your password"
                        />

                        <FormGroup className="btn-signIn-signUp">
                            <Button type="submit" color="primary">
                                Sign In
                            </Button>
                        </FormGroup>
                    </Form>
                )
            }}
        </Formik>
    );
}

SignInForm.propTypes = {
    onSubmit: PropTypes.func.isRequired,
}

export default SignInForm;
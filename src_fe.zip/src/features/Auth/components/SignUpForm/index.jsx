import React from 'react';
import PropTypes from 'prop-types';
import { Formik, Form, FastField } from 'formik';
import { FormGroup, Button } from 'reactstrap';
import * as Yup from 'yup';

import InputField from 'custom-fields/InputField';

function SignUpForm({ onSubmit = () => {} }) {
    const initialValues = {
        username: '',
        password: '',
        confirmPassword: '',
    };

    const validationSchema = Yup.object({
        username: Yup.string()
            .required('Username is required'),
        password: Yup.string()
            .min(6, 'Password must be at least 6 characters')
            .required('Password is required'),
        confirmPassword: Yup.string()
            .oneOf([Yup.ref('password'), null], 'Passwords must match')
            .required('Confirm Password is required'),
    });

    return (
        <Formik
            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={onSubmit}
        >
        {formikProps => (
            <Form>
                <h2>Sign Up</h2>

                <FastField
                    name="username"
                    component={InputField}
                    label="Username"
                    placeholder="Enter your username"
                />
                <FastField
                    name="password"
                    type="password"
                    component={InputField}
                    label="Password"
                    placeholder="Enter your password"
                />
                <FastField
                    name="confirmPassword"
                    type="password"
                    component={InputField}
                    label="Confirm Password"
                    placeholder="Re-enter your password"
                />

                <FormGroup className="btn-signIn-signUp">
                    <Button type="submit" color="success">
                        Sign Up
                    </Button>
                </FormGroup>
            </Form>
        )}
        </Formik>
    );
}

SignUpForm.propTypes = {
    onSubmit: PropTypes.func.isRequired,
};

export default SignUpForm;

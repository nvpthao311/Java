import React from 'react';
import { Route, Routes, useMatch, Navigate } from 'react-router-dom';

import NotFound from 'components/NotFound';
import SignIn from 'features/Auth/pages/SignIn';
import SignUp from 'features/Auth/pages/SignUp'

Auth.propTypes = {};

function Auth() {
    const match = useMatch('/auth');
    console.log({ match });

    return(
        <Routes>
            <Route path="/" element={<Navigate to="signIn" />} />
            <Route path="/signIn" element={<SignIn />} />
            <Route path="/signUp" element={<SignUp />} />
            <Route path="*" element={<NotFound />} />
        </Routes>
    );
}

export default Auth;
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import AuthApi from 'api/authApi';
import authService from 'services/authService';

// Async actions
export const login = createAsyncThunk(
    'auth/login',
    async ( credentials, { rejectWithValue }) => {
        try {
            const response = await AuthApi.login(credentials);
            if (!response.token) {
                return rejectWithValue('Login failed: Incorrect username or password.');
            }
            authService.saveToken(response.token);
            authService.saveAccount();
        } catch (error) {
            console.log('ERROR: ' , error);
            return rejectWithValue( error.response?.data?.message || "Login failed");
        }
    }
);

export const register = createAsyncThunk(
    'auth/register',
    async ( userData, { rejectWithValue }) => {
        try{
            await AuthApi.register(userData);
        } catch (error) {
            console.log('ERROR: ' , error);
            return rejectWithValue( error.response?.data?.message || "Registration failed");
        }
    }
);


export const logout = createAsyncThunk(
    'auth/logout',
    async () => {
        authService.removeToken();
        authService.removeAccount();
    }
);

// Slice
const authSlice = createSlice({
    name: 'auth',
    initialState: {
        isAuthenticated: !!authService.getToken(),
        account: authService.getAccount(),
        loading: false,
    },

    reducers: {},

    extraReducers: (builder) => {
        builder
            // Login
            .addCase(login.pending, (state) => {
                state.loading = true;
            })
            .addCase(login.fulfilled, (state) => {
                state.loading = false;
                state.isAuthenticated = true;
                state.account = authService.getAccount();
            })
            .addCase(login.rejected, (state, action) => {
                state.loading = false;
            })

            // Register
            .addCase(register.pending, (state) => {
                state.loading = true;
            })
            .addCase(register.fulfilled, (state) => {
                state.loading = false;
            })
            .addCase(register.rejected, (state) => {
                state.loading = false;
            })

            // Logout
            .addCase(logout.fulfilled, (state) => {
                state.isAuthenticated = false;
                state.account = { role: '', username: '' };
            });
    },
});

export default authSlice.reducer;

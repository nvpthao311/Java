import React from 'react';
import { Route, Routes, useMatch } from 'react-router-dom';

import Song from 'features/Song';
import Playlist from 'features/Playlist';
import NotFound from 'components/NotFound';
import MainLayout from 'Layouts/MusicLayout';
import MainPage from 'features/Music/pages/MainPage';
import SearchPage from 'features/Music/pages/SearchPage';
import PlaylistSong from 'features/PlaylistSong'

Music.propTypes = {};

function Music() {
    const match = useMatch('/music');
    console.log({ match });

    return(
        <Routes>
            <Route element={<MainLayout />}>
                <Route path="/" element={<MainPage />} />
                <Route path="/songs/*" element={<Song />} />
                <Route path="/playlists/*" element={<Playlist />} />
                <Route path="/view/*" element={<PlaylistSong />} />
                <Route path="/search/*" element={<SearchPage />} />
                <Route path="*" element={<NotFound />} />
            </Route>
        </Routes>
    );
}

export default Music;
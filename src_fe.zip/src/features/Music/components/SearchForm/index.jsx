import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

import './SearchForm.scss';

function SearchForm ({
        filteredSongs = [],
        filteredPlaylists = [],
        onSearch = () => {},
        onClickSong = () => {},
        onClickPlaylist = () => {},
    }) {
    const [query, setQuery] = useState('');

    useEffect(() => {
        onSearch(query);
    }, [query]);

    return (
        <div className="search-form">
            <h2>Search</h2>
            <input
                type="text"
                placeholder="Search name..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="search-input"
            />

            <div className="list">
                {(filteredSongs.length > 0 || filteredPlaylists.length > 0) ? (
                <div className="table-scroll-wrapper">
                    {filteredSongs.length > 0 && filteredSongs.map((song) => (
                        <li key={song.id} onClick={() => onClickSong(song)}>
                            Song: <strong>{song.name} </strong>
                            - <strong>{song.artist}</strong>
                        </li>
                    ))}

                    {filteredPlaylists.length > 0 && filteredPlaylists.map((playlist) => (
                        <li key={playlist.id} onClick={() =>onClickPlaylist(playlist)}>
                            Playlist: <strong>{playlist.name} </strong>
                        </li>
                    ))}
                </div>
                ) : (
                    <li>Not found!</li>
                )}
            </div>
        </div>
    )
}

SearchForm.propTypes = {
    filteredSongs: PropTypes.arrayOf(
       PropTypes.shape({
       id: PropTypes.number.isRequired,
       name: PropTypes.string.isRequired,
       artist: PropTypes.string.isRequired,
    })),
    filteredPlaylists: PropTypes.arrayOf(
       PropTypes.shape({
       id: PropTypes.number.isRequired,
       name: PropTypes.string.isRequired,
    })),
    onSearch: PropTypes.func.isRequired,
    onClickSong: PropTypes.func,
    onClickPlaylist: PropTypes.func,
}

export default SearchForm;
import React from 'react';
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate  } from 'react-router-dom';

import { fetchPlaylistsByName } from 'features/Playlist/PlaylistSlice';
import { fetchSongsByName } from 'features/Song/SongSlice';
import SearchForm from 'features/Music/components/SearchForm';

function SearchPage() {
    const filteredSongs = useSelector((state) => state.songs.dataPageFilter.filtered);
    const filteredPlaylists = useSelector(state => state.playlists.dataPageFilter.filtered)

    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    const handleSearch = (name) => {
        const params = { size: 100000 };
        dispatch(fetchSongsByName({name, params}));
        dispatch(fetchPlaylistsByName({name, params}));
    }

    const handleClickSong = (id) => {
        navigate(`/music/view/song/${id}`);
    }
    const handleClickPlaylist = (id) => {
        navigate(`/music/view/playlist/${id}`);
    }

    return (
        <SearchForm
            filteredSongs = {filteredSongs}
            filteredPlaylists = {filteredPlaylists}
            onSearch = {handleSearch}
            onClickSong = {handleClickSong}
            onClickPlaylist = {handleClickPlaylist}
        />
    );
}

export default SearchPage;
import React, { useState,useEffect } from 'react';
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate  } from 'react-router-dom';

import { fetchPlaylistsByName } from 'features/Playlist/PlaylistSlice';
import { fetchSongsByName } from 'features/Song/SongSlice';
import './SearchPage.scss'

function SearchPage() {
    const [query, setQuery] = useState('');

    const filteredSongs = useSelector((state) => state.songs.dataPageFilter.filtered);
    const filteredPlaylists = useSelector(state => state.playlists.dataPageFilter.filtered)

    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    useEffect(() => {
        const params = { page: 0, limit: 10};
        const name = query;
        dispatch(fetchSongsByName({name, params}));
        dispatch(fetchPlaylistsByName({name, params}));
    }, [query]);


    const handleClickSong = (id) => {
        navigate(`/music/view/song/${id}`);
    }
    const handleClickPlaylist = (id) => {
        navigate(`/music/view/playlist/${id}`);
    }


    return (
        <div className="search-page">
            <h2>Search</h2>
            <input
                type="text"
                placeholder="Search by song or playlist name..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="search-input"
            />

            <div className="list">
                {(filteredSongs.length > 0 || filteredPlaylists.length > 0) ? (
                <div className="table-scroll-wrapper">
                    {filteredSongs.length > 0 && filteredSongs.map((song) => (
                        <li key={song.id} onClick={() => handleClickSong(song.id)}>
                            Song: <strong>{song.name} </strong>
                            - <strong>{song.artist}</strong>
                        </li>
                    ))}

                    {filteredPlaylists.length > 0 && filteredPlaylists.map((playlist) => (
                        <li key={playlist.id} onClick={() => handleClickPlaylist(playlist.id)}>
                            Playlist: <strong>{playlist.name} </strong>
                        </li>
                    ))}
                </div>
                ) : (
                    <li>Not found!</li>
                )}
            </div>
        </div>
    );
}

export default SearchPage;
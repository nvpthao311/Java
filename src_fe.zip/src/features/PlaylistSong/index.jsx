import React from 'react';
import { Route, Routes, useMatch } from 'react-router-dom';

import ContainerLayout from 'Layouts/ContainerLayout';
import NotFound from 'components/NotFound';
import SongDetailPage from 'features/PlaylistSong/pages/SongDetailPage';
import PlaylistDetailPage from 'features/PlaylistSong/pages/PlaylistDetailPage';

Playlist.propTypes = {};

function Playlist() {
    const match = useMatch('music/view');
    console.log({ match });

    return(
        <Routes>
            <Route element={<ContainerLayout title="Playlist" />}>
                <Route path="/song/:songId" element={<SongDetailPage />} />
                <Route path="/playlist/:playlistId" element={<PlaylistDetailPage />} />
                <Route path="*" element={<NotFound />} />
            </Route>
        </Routes>
    );
}

export default Playlist;
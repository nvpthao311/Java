import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import PlaylistSongApi from 'api/playlistSongApi';

// Async actions
export const addSongToPlaylist = createAsyncThunk(
    'playlistSong/addSongToPlaylist',
    async ({ playlistId, songId }, { rejectWithValue }) => {
        try {
            const response = await PlaylistSongApi.addSongToPlaylist(playlistId, songId);
            console.log("RESPONSE:", response);
            return response;
        } catch (error) {
            console.log("ERROR:", error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);

export const removeSongFromPlaylist = createAsyncThunk(
    'playlistSong/removeSongFromPlaylist',
    async ({ playlistId, songId }, { rejectWithValue }) => {
        try {
            console.log("removeSongFromPlaylist",playlistId, songId);
            await PlaylistSongApi.removeSongFromPlaylist(playlistId, songId);
            return { playlistId, songId };
        } catch (error) {
            console.log("ERROR:", error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const getSongsByPlaylist = createAsyncThunk(
    'playlistSong/getSongsByPlaylist',
    async ( playlistId, { rejectWithValue }) => {
        try {
            const response = await PlaylistSongApi.getSongsByPlaylist( playlistId );
            console.log("RESPONSE:", response);
            return response;
        } catch (error) {
            console.log("ERROR:", error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);

export const getPlaylistsBySong = createAsyncThunk(
    'playlistSong/getPlaylistsBySong',
    async ( songId, { rejectWithValue }) => {
        try {
            const response = await PlaylistSongApi.getPlaylistsBySong( songId );
            console.log("RESPONSE:", response);
            return response;
        } catch (error) {
            console.log("ERROR:", error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);

// Slice
const playlistSongSlice = createSlice({
    name: 'playlistSong',
    initialState: {
        songsByPlaylist: [],
        playlistsBySong: [],
        loading: false,
    },

    reducers: {},

    extraReducers: (builder) => {
        builder
            //addSongToPlaylist
            .addCase(addSongToPlaylist.pending, (state) => {
                state.loading = true;
            })
            .addCase(addSongToPlaylist.fulfilled, (state, action) => {
                state.loading = false;
            })
            .addCase(addSongToPlaylist.rejected, (state, action) => {
                state.loading = false;
            })

            //removeSongFromPlaylist
            .addCase(removeSongFromPlaylist.fulfilled, (state, action) => {
                state.playlistsBySong = state.playlistsBySong.filter(p => p.id !== action.payload.playlistId)
                state.songsByPlaylist = state.songsByPlaylist.filter(s => s.id !== action.payload.songId)
            })

            //getSongsByPlaylist
            .addCase(getSongsByPlaylist.pending, (state) => {
                state.loading = true;
            })
            .addCase(getSongsByPlaylist.fulfilled, (state, action) => {
                state.loading = false;
                state.songsByPlaylist = action.payload;
            })
            .addCase(getSongsByPlaylist.rejected, (state, action) => {
                state.loading = false;
            })

            //getPlaylistsBySong
            .addCase(getPlaylistsBySong.pending, (state) => {
                state.loading = true;
            })
            .addCase(getPlaylistsBySong.fulfilled, (state, action) => {
                state.loading = false;
                state.playlistsBySong = action.payload;
            })
            .addCase(getPlaylistsBySong.rejected, (state, action) => {
                state.loading = false;
            })

    },
});

export default playlistSongSlice.reducer;

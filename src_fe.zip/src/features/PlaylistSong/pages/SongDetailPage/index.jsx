import React, { useEffect } from 'react';
import { toast } from 'react-toastify';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import SongDetailForm from 'features/PlaylistSong/components/SongDetailForm'
import { fetchSongById, updateSong } from 'features/Song/SongSlice';
import { fetchPlaylistsByName } from 'features/Playlist/PlaylistSlice';
import { getPlaylistsBySong, addSongToPlaylist, removeSongFromPlaylist } from 'features/PlaylistSong/PlaylistSongSlice'
import { removeSong } from 'features/Song/SongSlice';


const SongDetailPage = () => {
    const { songId } = useParams();

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const filteredPlaylists = useSelector((state) => state.playlists.dataPageFilter.filtered);
    const song = useSelector((state) => state.songs.dataPageFilter.filtered[0]);
    const playlists = useSelector((state) => state.playlistSong.playlistsBySong);

    useEffect(() => {
        dispatch(fetchSongById(songId));
        dispatch(getPlaylistsBySong(songId));
    }, [dispatch]);

    const handleViewPlaylist = (playlistId) => {
        navigate(`/music/view/playlist/${playlistId}`);
    };

    const handleRemovePlaylistFromSong = (playlistId) => {
        const confirmDelete = window.confirm('Are you sure you want to remove this playlist form song');
        if(confirmDelete){
            console.log(playlistId, song.id);
            dispatch(removeSongFromPlaylist({ playlistId, songId: song.id }))
                .unwrap()
                .then(() => {
                    toast.success('Remove playlist successful!', { autoClose: 1000 });
                })
                .catch((err) => {
                    toast.error('Remove playlist false!', { autoClose: 1000 });
                });
        };
    };

    const handleSearchToAdd = (name) => {
        const params = { size: 100000 };
        dispatch(fetchPlaylistsByName({name, params}));
    }

    const handleAddPlaylistToSong = (playlist) => {
        dispatch(addSongToPlaylist({ playlistId: playlist.id, songId: song.id }))
            .unwrap()
            .then(() => {
                toast.success('Add playlist successful!', { autoClose: 1000 });
            })
            .catch((err) => {
                toast.error('Add playlist false!', { autoClose: 1000 });
            });
    };

    const handleEditSong = (song) => {
        dispatch(updateSong(song));
    };

    const handleDeleteSong = () => {
        const confirmDelete = window.confirm('Are you sure you want to delete this song?');
        if(confirmDelete){
            dispatch(removeSong(song.id))
                .unwrap()
                .then(() => {
                    toast.success('Delete song successful!', { autoClose: 1000 });
                })
                .catch((err) => {
                    toast.error('Delete song false!', { autoClose: 1000 });
                });
        } ;
    };

    if (!song) return <div>Loading song details...</div>;

    return (
        <div className="detail-page">
            <SongDetailForm
                song={song}
                playlists={playlists}
                filteredPlaylists={filteredPlaylists}
                onViewPlaylist={handleViewPlaylist}
                onDeletePlaylist={handleRemovePlaylistFromSong}
                onSearch={handleSearchToAdd}
                onAddPlaylist={handleAddPlaylistToSong}
                onEditSong={handleEditSong}
                onDeleteSong={handleDeleteSong}
            />
        </div>
    );
};

export default SongDetailPage;

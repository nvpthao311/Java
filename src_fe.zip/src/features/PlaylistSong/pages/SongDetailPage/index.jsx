import React, { useEffect } from 'react';
import { toast } from 'react-toastify';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import SongDetailForm from 'features/PlaylistSong/components/SongDetailForm'
import { fetchSongById, updateSong } from 'features/Song/SongSlice';
import { getPlaylistsBySong, addSongToPlaylist, removeSongFromPlaylist } from 'features/PlaylistSong/PlaylistSongSlice'
import { removeSong } from 'features/Song/SongSlice';


const SongDetailPage = () => {
    const { songId } = useParams();

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const song = useSelector((state) => state.songs.dataPageFilter.filtered);
    const playlists = useSelector((state) => state.playlistSong.playlistsBySong);

    useEffect(() => {
        dispatch(fetchSongById(songId));
        dispatch(getPlaylistsBySong(songId));
    }, [dispatch]);

    const handleViewPlaylist = (playlistId) => {
        navigate(`/music/view/playlist/${playlistId}`);
    };

    const handleRemovePlaylistFromSong = (playlistId) => {
        const confirmDelete = window.confirm('Are you sure you want to remove this playlist form song');
        if(confirmDelete){
            console.log(playlistId, song.id);
            dispatch(removeSongFromPlaylist({ playlistId, songId: song.id }))
                .unwrap()
                .then(() => {
                    toast.success('Remove playlist successful!', { autoClose: 1000 });
                })
                .catch((err) => {
                    toast.error('Remove playlist false!', { autoClose: 1000 });
                });
        };
    };

    const handleAddPlaylistToSong = () => {
//         dispatch(addSongToPlaylist({ playlistId, songId: song.id }))
//             .unwrap()
//             .then(() => {
//                 toast.success('Add playlist successful!', { autoClose: 1000 });
//                 navigate('/music/playlists');
//             })
//             .catch((err) => {
//                 toast.error('Add playlist false!', { autoClose: 1000 });
//             });
        toast.error("Improve the add feature logic later — it's a bit messy now.", { autoClose: 3000 });
    };

    const handleEditSong = () => {
//         dispatch(updateSong(song));
        toast.error("Improve the add feature logic later — it's a bit messy now.", { autoClose: 3000 });
    };

    const handleDeleteSong = () => {
        const confirmDelete = window.confirm('Are you sure you want to delete this song?');
        if(confirmDelete){
            dispatch(removeSong(song.id))
                .unwrap()
                .then(() => {
                    toast.success('Delete song successful!', { autoClose: 1000 });
                    navigate('/music/songs');
                })
                .catch((err) => {
                    toast.error('Delete song false!', { autoClose: 1000 });
                });
        } ;
    };

    if (!song) return <div>Loading song details...</div>;

    return (
        <div className="detail-page">
            <SongDetailForm
                song={song}
                playlists={playlists}
                onViewPlaylist={handleViewPlaylist}
                onDeletePlaylist={handleRemovePlaylistFromSong}
                onAddPlaylist={handleAddPlaylistToSong}
                onEditSong={handleEditSong}
                onDeleteSong={handleDeleteSong}
            />
        </div>
    );
};

export default SongDetailPage;

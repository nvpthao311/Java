import React, { useEffect } from 'react';
import { toast } from 'react-toastify';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import PlaylistDetailForm from 'features/PlaylistSong/components/PlaylistDetailForm';
import { fetchSongsByName } from 'features/Song/SongSlice';
import { fetchPlaylistById, updatePlaylist } from 'features/Playlist/PlaylistSlice';
import { getSongsByPlaylist, addSongToPlaylist, removeSongFromPlaylist } from 'features/PlaylistSong/PlaylistSongSlice'
import { removePlaylist } from 'features/Playlist/PlaylistSlice';

const PlaylistDetailPage = () => {
    const { playlistId } = useParams();

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const filteredSongs = useSelector((state) => state.songs.dataPageFilter.filtered);
    const playlist = useSelector((state) => state.playlists.dataPageFilter.filtered[0]);
    const songs = useSelector((state) => state.playlistSong.songsByPlaylist);

    useEffect(() => {
        dispatch(fetchPlaylistById(playlistId));
        dispatch(getSongsByPlaylist(playlistId));
    }, [dispatch]);

    const handleViewSong = (songId) => {
        navigate(`/music/view/song/${songId}`);
    };

    const handleRemoveSongFromPlaylist = (songId) => {
        const confirmDelete = window.confirm('Are you sure you want to remove this song form playlist?');
        if(confirmDelete){
            dispatch(removeSongFromPlaylist({ playlistId: playlist.id, songId }))
                .unwrap()
                .then(() => {
                    toast.success('Remove song successful!', { autoClose: 1000 });
                })
                .catch((err) => {
                    toast.error('Remove song false!', { autoClose: 1500 });
                });
        }
    };

    const handleSearchToAdd = (name) => {
        const params = { size: 100000 };
        dispatch(fetchSongsByName({name, params}));
    }

    const handleAddSongToPlaylist = (song) => {
        dispatch(addSongToPlaylist({ playlistId: playlist.id, songId: song.id }))
            .unwrap()
            .then(() => {
                toast.success('Add playlist successful!', { autoClose: 1000 });
            })
            .catch((err) => {
                toast.error('Add song false!', { autoClose: 1500 });
            });
    };

    const handleEditPlaylist = (playlist) => {
        dispatch(updatePlaylist(playlist));
    };

    const handleDeletePlaylist = () => {
        const confirmDelete = window.confirm('Are you sure you want to delete this playlist?');
        if(confirmDelete) {
            dispatch(removePlaylist(playlist.id))
                .unwrap()
                .then(() => {
                    toast.success('Delete playlist successful!', { autoClose: 1000 });
                })
                .catch((err) => {
                    toast.error('Delete playlist false!', { autoClose: 1500 });
                });
        };
    };

    if (!playlist) return <div>Loading playlist details...</div>;

    return (
        <div className="detail-page">
            <PlaylistDetailForm
                playlist={playlist}
                songs={songs}
                filteredSongs={filteredSongs}
                onViewSong={handleViewSong}
                onDeleteSong={handleRemoveSongFromPlaylist}
                onSearch={handleSearchToAdd}
                onAddSong={handleAddSongToPlaylist}
                onEditPlaylist={handleEditPlaylist}
                onDeletePlaylist={handleDeletePlaylist}
            />
        </div>
    );
};

export default PlaylistDetailPage;

import React, { useEffect } from 'react';
import { toast } from 'react-toastify';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';

import PlaylistDetailForm from 'features/PlaylistSong/components/PlaylistDetailForm';
import { fetchPlaylistById, updatePlaylist } from 'features/Playlist/PlaylistSlice';
import { getSongsByPlaylist, addSongToPlaylist, removeSongFromPlaylist } from 'features/PlaylistSong/PlaylistSongSlice'
import { removePlaylist } from 'features/Playlist/PlaylistSlice';

const PlaylistDetailPage = () => {
    const { playlistId } = useParams();

    const navigate = useNavigate();
    const dispatch = useDispatch();

    const playlist = useSelector((state) => state.playlists.dataPageFilter.filtered);
    const songs = useSelector((state) => state.playlistSong.songsByPlaylist);

    useEffect(() => {
        dispatch(fetchPlaylistById(playlistId));
        dispatch(getSongsByPlaylist(playlistId));
    }, [dispatch]);

    const handleViewSong = (songId) => {
        navigate(`/music/view/song/${songId}`);
    };

    const handleRemoveSongFromPlaylist = (songId) => {
        const confirmDelete = window.confirm('Are you sure you want to remove this song form playlist?');
        if(confirmDelete){
            dispatch(removeSongFromPlaylist({ playlistId: playlist.id, songId }))
                .unwrap()
                .then(() => {
                    toast.success('Remove song successful!', { autoClose: 1000 });
                })
                .catch((err) => {
                    toast.error('Remove song false!', { autoClose: 1000 });
                });
        }
    };

    const handleAddSongToPlaylist = () => {
//         dispatch(addSongToPlaylist({ playlistId: playlist.id, songId }))
//             .unwrap()
//             .then(() => {
//                 toast.success('Add playlist successful!', { autoClose: 1000 });
//                 navigate('/music/playlists');
//             })
//             .catch((err) => {
//                 toast.error('Add playlist false!', { autoClose: 1000 });
//             });
        toast.error("Improve the add feature logic later — it's a bit messy now.", { autoClose: 3000 });
    };

    const handleEditPlaylist = () => {
//         dispatch(updatePlaylist(playlist));
        toast.error("Improve the add feature logic later — it's a bit messy now.", { autoClose: 3000 });
    };

    const handleDeletePlaylist = () => {
        const confirmDelete = window.confirm('Are you sure you want to delete this playlist?');
        if(confirmDelete) {
            dispatch(removePlaylist(playlist.id))
                .unwrap()
                .then(() => {
                    toast.success('Delete playlist successful!', { autoClose: 1000 });
                    navigate('/music/playlists');
                })
                .catch((err) => {
                    toast.error('Delete playlist false!', { autoClose: 1000 });
                });
        };
    };

    if (!playlist) return <div>Loading playlist details...</div>;

    return (
        <div className="detail-page">
            <PlaylistDetailForm
                playlist={playlist}
                songs={songs}
                onViewSong={handleViewSong}
                onDeleteSong={handleRemoveSongFromPlaylist}
                onAddSong={handleAddSongToPlaylist}
                onEditPlaylist={handleEditPlaylist}
                onDeletePlaylist={handleDeletePlaylist}
            />
        </div>
    );
};

export default PlaylistDetailPage;

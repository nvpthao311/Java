import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
import { FaPlus } from 'react-icons/fa';

import PlaylistForm from 'features/Playlist/components/PlaylistForm';
import SearchForm from 'features/Music/components/SearchForm';

const PlaylistDetailForm = ({
        playlist = '',
        songs = [],
        filteredSongs = [],
        onViewSong = () => {},
        onDeleteSong = () => {},
        onSearch = () => {},
        onAddSong = () => {},
        onEditPlaylist = () => {},
        onDeletePlaylist = () => {}
    }) => {

    const loading = useSelector(state => state.playlistSong.loading);

    const [editedPlaylist, setEditedPlaylist] = useState(null);
    const [addSong, setAddSong] = useState(false);

    return (
        <>
        <div className="detail-form">
            <h4>Playlist Details</h4>
            <h6>
                <strong>Name:</strong> {playlist.name}
            </h6>
            <div className="detail-form__add">
                <h5>Songs in this Playlist:</h5>
                <button onClick={() => setAddSong(true)} className="btn-action">
                    <FaPlus /> Add
                </button>
            </div>

            <div className="table-scroll-wrapper">
                {loading ? (
                    <div className="spinner"/>
                ) : (
                <table className="song-playlist-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Artist</th>
                            <th style={{ textAlign: 'right' }}>delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(songs && songs.length > 0) ? (
                            songs.map((song, index) => (
                                <tr key={song.id}>
                                    <td>{index + 1}</td>
                                    <td onClick={() => onViewSong(song.id)}>{song.name}</td>
                                    <td>{song.artist}</td>
                                    <td style={{ textAlign: 'right' }}>
                                        <button
                                            onClick={() => onDeleteSong(song.id)}
                                            className="icon"
                                        >
                                            x
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="4">No songs in this playlist.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
                )}
            </div>
            <div className="footer-buttons">
                <button onClick={() => setEditedPlaylist(playlist)}>
                    Edit
                </button>
                <button onClick={() => onDeletePlaylist(playlist.id)}>
                    Delete
                </button>
            </div>
        </div>

        {editedPlaylist && (
            <div className="edit_form">
                <div className="edit_form_playlist">
                    <PlaylistForm
                        initialValues={editedPlaylist}
                        onSubmit={(value) =>{onEditPlaylist(value); setEditedPlaylist(null)}}
                        onCancel={() => setEditedPlaylist(null)}
                    />
                </div>
            </div>
        )}

        {addSong && (
            <div className="edit_form">
                <div className="edit_form_list">
                    <SearchForm
                        filteredSongs = {filteredSongs}
                        onSearch = {onSearch}
                        onClickSong = {onAddSong}
                    />
                    <div style={{ textAlign: 'top' }}>
                        <button onClick={() => setAddSong(false)} className="icon">
                            x
                        </button>
                    </div>
                </div>
            </div>
        )}
        </>
    );
};

PlaylistDetailForm.propTypes = {
    playlist: PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
    }).isRequired,
    songs: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.number.isRequired,
            name: PropTypes.string.isRequired,
            artist: PropTypes.string.isRequired,
        })
    ).isRequired,
    filteredSongs: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.number.isRequired,
            name: PropTypes.string.isRequired,
            artist: PropTypes.string.isRequired,
        })
    ).isRequired,
    onViewSong: PropTypes.func.isRequired,
    onDeleteSong: PropTypes.func.isRequired,
    onSearch: PropTypes.func.isRequired,
    onAddSong: PropTypes.func.isRequired,
    onEditPlaylist: PropTypes.func.isRequired,
    onDeletePlaylist: PropTypes.func.isRequired,
};

export default PlaylistDetailForm;

import React from 'react';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
import { FaTrash, FaEdit, FaPlus, FaSearch, FaAngleDoubleLeft, FaAngleDoubleRight } from 'react-icons/fa';

const SongDetailForm = ({
        song = '',
        playlists = [],
        onViewPlaylist = () => {},
        onDeletePlaylist = () => {},
        onAddPlaylist = () => {},
        onEditSong = () => {},
        onDeleteSong = () => {}
    }) => {

    const loading = useSelector(state => state.playlistSong.loading);

    return (
        <div className="detail-form">
            <h4>Song Details</h4>
            <h6>
                <strong>Name:</strong> {song.name}
            </h6>
            <h6>
                <strong>Artist:</strong> {song.artist}
            </h6>
            <h6>
                <strong>filePath:</strong> {song.filePath}
            </h6>
            <div className="detail-form__add">
                <h5>Songs in this Playlist:</h5>
                <button onClick={() => onAddPlaylist()} className="btn-action">
                    <FaPlus /> Add
                </button>
            </div>
            <div className="table-scroll-wrapper">
                {loading ? (
                    <div className="spinner"/>
                ) : (
                <table className="song-playlist-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Playlist Name</th>
                            <th style={{ textAlign: 'right' }}>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {playlists.length > 0 ? (
                            playlists.map((playlist, index) => (
                                <tr key={playlist.id}>
                                    <td>{index + 1}</td>
                                    <td onClick={() => onViewPlaylist(playlist.id)}>{playlist.name}</td>
                                    <td style={{ textAlign: 'right' }}>
                                        <button
                                            onClick={() => onDeletePlaylist(playlist.id)}
                                            className="icon"
                                        >
                                            x
                                        </button>
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="4">This song is not included in any playlists.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
                )}
                <div className="footer-buttons">
                    <button onClick={() => onEditSong(song)}>
                        Edit
                    </button>
                    <button onClick={() => onDeleteSong(song.id)}>
                        Delete
                    </button>
                </div>
            </div>
        </div>
    );
};

SongDetailForm.propTypes = {
    song: PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        artist: PropTypes.string.isRequired,
        filePath: PropTypes.string.isRequired,
    }).isRequired,
    playlists: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.number.isRequired,
            name: PropTypes.string.isRequired,
            artist: PropTypes.string.isRequired,
        })
    ).isRequired,
    onViewPlaylist: PropTypes.func.isRequired,
    onDeletePlaylist: PropTypes.func.isRequired,
    onAddPlaylist: PropTypes.func.isRequired,
    onEditSong: PropTypes.func.isRequired,
    onDeleteSong: PropTypes.func.isRequired,
};

export default SongDetailForm;

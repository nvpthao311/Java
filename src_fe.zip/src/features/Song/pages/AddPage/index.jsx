import React from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate  } from 'react-router-dom';

import { createSong } from 'features/Song/SongSlice'
import SongForm from 'features/Song/components/SongForm';

function AddPage() {
    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    const handleSubmit = (song) => {
        dispatch(createSong(song))
            .unwrap()
            .then((response) => {
                navigate(`/music/view/song/${response.id}`);
            })
    }

    const handleCancel = () => {
        navigate("/music/songs");
    }

    return (
        <div className="add_page">
            <SongForm
                onSubmit={handleSubmit}
                onCancel={handleCancel}
            />
        </div>
    );
}

export default AddPage;
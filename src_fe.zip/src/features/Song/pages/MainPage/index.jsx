import React, {useEffect} from 'react';
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate} from 'react-router-dom';

import SongList from 'features/Song/components/SongList';
import { removeSong, removeSongs, updateSong, fetchSongs, fetchSongsByName } from 'features/Song/SongSlice';
import { changePage } from 'features/Song/SongSlice';

function MainPage() {
    const dataPageList = useSelector((state) => state.songs.dataPageList);
    const dataPageFilter = useSelector((state) => state.songs.dataPageFilter);
    const searching = useSelector((state) => state.songs.searching);

    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    useEffect(() => {
        const params = { page: dataPageList.page.current };
        dispatch(fetchSongs(params));
    }, [dataPageList.page.current, dataPageList.totalSongs]);

    useEffect(() => {
        const params = { page: dataPageFilter.page.current };
        const name = dataPageFilter.searchText;
        console.log("In MainPage: " , dataPageFilter.searchText)
        dispatch(fetchSongsByName({ name, params }));
    }, [dataPageFilter.page.current, dataPageList.totalSongs]);

    const handleAdd = () => {
        navigate("/music/songs/add");
    }

    const handleEdit = ( song ) => {
        dispatch(updateSong(song));
    }

    const handleDelete = (id) => {
        dispatch(removeSong(id))
    }

    const handleDeleteMulti = (ids) => {
        dispatch(removeSongs(ids))
    }

    const handleSearch = (name) => {
        const params = { page: 0 };
        dispatch(fetchSongsByName({name, params}))
    }

    const handleView = (id) => {
        navigate(`/music/view/song/${id}`);
    }

    const handleChangePageList = ( direction ) => {
        if(direction === "next" && (dataPageList.page.current < dataPageList.page.max)){
            dispatch(changePage(dataPageList.page.current + 1));
        } else if(direction === "pre" && (dataPageList.page.current > 0)){
            dispatch(changePage(dataPageList.page.current - 1));
        } else{
            console.log("Change page " ,direction, " failed!");
        }
    }
    const handleChangePageFilter = ( direction ) => {
        if(direction === "next" && (dataPageFilter.page.current < dataPageFilter.page.max)){
            dispatch(changePage(dataPageFilter.page.current + 1));
        } else if(direction === "pre" && (dataPageFilter.page.current > 0)){
            dispatch(changePage(dataPageFilter.page.current - 1));
        } else{
            console.log("Change page " ,direction, " failed!");
        }
    }

    return (
        (!searching) ? (
        <SongList
            songs={dataPageList.list}
            totalSongs = {dataPageList.totalSongs}
            page ={dataPageList.page.current}
            onAdd ={handleAdd}
            onEdit ={handleEdit}
            onDelete ={handleDelete}
            onDeleteMulti ={handleDeleteMulti}
            onSearch ={handleSearch}
            onView = {handleView}
            onChangePage = {handleChangePageList}
        />
        ):(
        <SongList
            songs={dataPageFilter.filtered}
            totalSongs = {dataPageFilter.totalSongs}
            page ={dataPageFilter.page.current}
            onAdd ={handleAdd}
            onEdit ={handleEdit}
            onDelete ={handleDelete}
            onDeleteMulti ={handleDeleteMulti}
            onSearch ={handleSearch}
            onView = {handleView}
            onChangePage = {handleChangePageFilter}
        />
        )
    );
}

export default MainPage;
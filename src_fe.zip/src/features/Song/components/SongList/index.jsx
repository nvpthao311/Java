import React, { useState } from 'react';
import { useSelector} from 'react-redux';
import PropTypes from 'prop-types';
import { FaTrash, FaEdit, FaPlus, FaSearch, FaAngleDoubleLeft, FaAngleDoubleRight } from 'react-icons/fa';

import SearchBox from 'components/SearchBox';
import SongForm from 'features/Song/components/SongForm';

function SongList({
        songs = [],
        totalSongs = 0,
        page = 0,
        onAdd = () => {},
        onEdit = () => {},
        onDelete = () => {},
        onDeleteMulti = () => {},
        onSearch = () => {},
        onView = () => {},
        onChangePage = () => {}
    }) {
    const loading = useSelector(state => state.songs.loading);

    const [selectedSongs, setSelectedSongs] = useState([]);
    const [editedSong, setEditedSong] = useState(null);

    // Select
    const isSelected = (id) => selectedSongs.includes(id);
    const isAllSelected = selectedSongs.length === songs.length && songs.length > 0;

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allIds = songs.map((song) => song.id);
            setSelectedSongs(allIds);
        } else {
            setSelectedSongs([]);
        }
    };

    const handleSelectSong = (id) => {
        setSelectedSongs((prevSelected) =>
            prevSelected.includes(id)
            ? prevSelected.filter((songId) => songId !== id)
            : [...prevSelected, id]
        );
    };

    // Delete
    const handleDeleteSong = (id) => {
        const confirmDelete = window.confirm('Are you sure you want to delete this song?');
        if(confirmDelete) onDelete(id);
    }

    const handleDeleteSongs = () => {
        const confirmDelete = window.confirm('Are you sure you want to delete selected songs?');
        if(selectedSongs && confirmDelete){
            onDeleteMulti(selectedSongs);
            setSelectedSongs([]);
        }
    }

    return (
        <>
        <div className="song-playlist-header">
            <h4>Song Manager</h4>
            <div className="song-playlist-header__action">
                <button onClick={onAdd} className="btn-action">
                    <FaPlus /> Add
                </button>
                <button onClick={handleDeleteSongs} className="btn-action">
                    <FaTrash /> Delete
                </button>
                <SearchBox onSearch={onSearch}>
                    <FaSearch /> Search
                </SearchBox>
            </div>
        </div>

        <h5>You have total <strong>{totalSongs}</strong> songs</h5>

        <div className="table-scroll-wrapper">
            {loading ? (
                <div className="spinner"/>
            ) : (
            <table className="song-playlist-table">
                <thead>
                    <tr>
                        <th>
                            <input
                                type="checkbox"
                                checked={isAllSelected}
                                onChange={handleSelectAll}
                            />
                        </th>
                        <th>Name</th>
                        <th>Artist</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody className="song-playlist-table__item">
                    {songs.length > 0 ? (
                        songs.map((song) => (
                        <React.Fragment key={song.id}>
                            <tr key={song.id}>
                                <td>
                                <input
                                    type="checkbox"
                                    checked={isSelected(song.id)}
                                    onChange={() => handleSelectSong(song.id)}
                                />
                                </td>

                                <td onClick={() => onView(song.id)}>{song.name}</td>

                                <td>{song.artist}</td>

                                <td>
                                    <button onClick={() => setEditedSong(song)} className="btn-action">
                                        <FaEdit /> Edit
                                    </button>
                                    <button onClick={() => handleDeleteSong(song.id)} className="btn-action">
                                        <FaTrash /> Delete
                                    </button>
                                </td>
                            </tr>
                        </React.Fragment>
                        ))) : (
                            <tr>
                                <td colSpan="4">No playlists found.</td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
            )}
        </div>

        <div className="page-controls">
            <button className="icon" onClick={() => onChangePage("pre")}><FaAngleDoubleLeft /></button>
            <span>{page}</span>
            <button className="icon" onClick={() => onChangePage("next")}><FaAngleDoubleRight /></button>
        </div>

        {editedSong && (
            <div className="edit_form">
                <div className="edit_form_song">
                    <SongForm
                        initialValues={editedSong}
                        onSubmit={(value) =>{onEdit(value); setEditedSong(null)}}
                        onCancel={() => setEditedSong(null)}
                    />
                </div>
            </div>
        )}
        </>
    );
}

SongList.propTypes = {
    songs: PropTypes.arrayOf(
        PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        artist: PropTypes.string.isRequired,
    })).isRequired,

    totalSongs: PropTypes.number.isRequired,
    page: PropTypes.number.isRequired,
    onAdd: PropTypes.func.isRequired,
    onEdit: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    onDeleteMulti: PropTypes.func.isRequired,
    onSearch: PropTypes.func.isRequired,
    onView: PropTypes.func.isRequired,
    onChangePage: PropTypes.func.isRequired,
};

export default SongList;

import React from 'react';
import PropTypes from 'prop-types';
import { Button, FormGroup} from 'reactstrap';
import { Formik, Form, FastField } from 'formik';

import InputField from 'custom-fields/InputField';
import FileUploadField from 'custom-fields/FileUploadField'

import * as Yup from 'yup';

function SongForm({
        initialValues = '',
        onSubmit = () => {},
        onCancel = () => {}
    }) {

    const validationSchema = Yup.object().shape({
        name: Yup.string().required(),
        artist: Yup.string().required(),
        filePath: Yup.string().required(),
    })

    return(
        <Formik
            initialValues = {initialValues || { name: '', artist: '', filePath: '' }}
            validationSchema = {validationSchema}
            onSubmit = {onSubmit}
            onCancel = {onCancel}
            enableReinitialize
        >
            {formikProps => {
                const { values, errors, touched } = formikProps;

                return(
                    <Form className="song-playlist-form">
                        <FastField
                            name="name"
                            component={InputField}

                            label="Name"
                            placeholder="Eg: Hello"
                        />
                        <FastField
                            name="artist"
                            component={InputField}

                            label="Artist"
                            placeholder="Eg: Adele"
                        />
                        <FastField
                            name="filePath"
                            component={FileUploadField}

                            label="FilePath"
                        />

                        <FormGroup className="footer-buttons">
                            <Button type="submit" color="primary">
                                Apply
                            </Button>
                            <Button onClick={onCancel} type="cancel" color="primary">
                                Cancel
                            </Button>
                        </FormGroup>
                    </Form>
                )
            }}
        </Formik>
    );
}

SongForm.propTypes = {
    initialValues: PropTypes.object,
    onSubmit: PropTypes.func.isRequired,
    onCancel: PropTypes.func.isRequired,
}

export default SongForm;
import { createSlice, createAsyncThunk  } from '@reduxjs/toolkit';
import SongApi from 'api/songApi';

// Async actions
export const fetchSongs = createAsyncThunk(
    'songs/findAll',
    async ( params, { rejectWithValue }) => {
        try {
            const response = await SongApi.findAll(params);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const fetchSongById = createAsyncThunk(
    'songs/findById',
    async ( id, { rejectWithValue }) => {
        try {
            const response = await SongApi.findById(id);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const fetchSongsByName = createAsyncThunk(
    'songs/findByName',
    async ({name, params}, { rejectWithValue }) => {
        if(!name){
            return {response: [], search: []};
        }
        try {
            const response = await SongApi.findByName( name, params );
            console.log("RESPONSE:" , response);
            return {response, search: {searching: true, text: name}};
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);

export const createSong  = createAsyncThunk(
    'songs/create',
    async ( song, { rejectWithValue }) => {
        try {
            const response = await SongApi.create(song);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const updateSong  = createAsyncThunk(
    'songs/update',
    async ( song, { rejectWithValue }) => {
        try {
            const response = await SongApi.update( song.id, song);
            console.log("RESPONSE:" , response);
            return song;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const removeSong  = createAsyncThunk(
    'songs/remove',
    async ( id, { rejectWithValue }) => {
        try {
            await SongApi.remove(id);
            console.log("RESPONSE: Remove done!");
            return id;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const removeSongs  = createAsyncThunk(
    'songs/removeMulti',
    async ( ids, { rejectWithValue }) => {
        try {
            const response = await SongApi.removeMulti(ids);
            console.log("RESPONSE:" , response);
            return ids;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);

// Slice
const song = createSlice({
    name: 'songs',
    initialState: {
        dataPageList: {
            list: [],
            page: {
                current: 0,
                max: 0
            },
            totalSongs: 0,
        },
        dataPageFilter: {
            filtered:[],
            page: {
                current: 0,
                max: 0
            },
            totalSongs: 0,
            searchText: '',
        },
        searching: false,
        loading: false,
    },

    reducers: {
        changePage: (state, action) => {
            if(!state.searching) {
                state.dataPageList.page.current = action.payload;
                console.log("Current page:" ,state.dataPageList.page.current);
            }else{
                state.dataPageFilter.page.current = action.payload;
                console.log("Current page:" ,state.dataPageFilter.page.current);
            }
        },
        setSearching: (state, action) => {
            state.searching = action.payload;
            console.log(state.searching);
        },
    },

    extraReducers: (builder) => {
        builder
            //Songs
            .addCase(fetchSongs.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchSongs.fulfilled, (state, action) => {
                state.dataPageList = {
                    list: (action.payload.content || []),
                    page: {
                        current: (action.payload.number || 0),
                        max: ((action.payload.totalPages - 1) || 0),
                    },
                    totalSongs: (action.payload.totalElements || 0),
                }
                state.loading = false;
                console.log("List:", state.dataPageList.list);
                console.log("page:" ,state.dataPageList.page.current);
                console.log("Max page:" ,state.dataPageList.page.max);
                console.log("Total Songs:" ,state.dataPageList.totalSongs);
            })
            .addCase(fetchSongs.rejected, (state, action) => {
                state.loading = false;
            })

            //SongById
            .addCase(fetchSongById.fulfilled, (state, action) => {
                state.searching = true;
                state.dataPageFilter.filtered = [action.payload];
            })

            //SongsByName
            .addCase(fetchSongsByName.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchSongsByName.fulfilled, (state, action) => {
                state.searching = (action.payload.search.searching || false);
                state.dataPageFilter = {
                    searchText: (action.payload.search.text || ''),
                    filtered: (action.payload.response.content || []),
                    page: {
                        current: (action.payload.response.number || 0),
                        max: ((action.payload.response.totalPages -1) || 0),
                    },
                    totalSongs: (action.payload.response.totalElements || 0),
                }
                state.loading = false;
                console.log("filtered:", state.dataPageFilter.filtered);
                console.log("page:" ,state.dataPageFilter.page.current);
                console.log("Max page:" ,state.dataPageFilter.page.max);
                console.log("Total Songs:" ,state.dataPageFilter.totalSongs);
                console.log("search text:" ,state.dataPageFilter.searchText);
                console.log("searching:" ,state.searching);
            })
            .addCase(fetchSongsByName.rejected, (state, action) => {
                state.loading = false;
            })

            //create
            .addCase(createSong.fulfilled, (state, action) => {
                state.dataPageList.totalSongs = state.dataPageList.totalSongs + 1;
            })

            //update
            .addCase(updateSong.fulfilled, (state, action) => {
                if(state.searching){
                    const playlistIndex = state.dataPageFilter.filtered.findIndex(p => p.id === action.payload.id);
                    state.dataPageFilter.filtered[playlistIndex] = action.payload;
                }else{
                    const playlistIndex = state.dataPageList.list.findIndex(p => p.id === action.payload.id);
                    state.dataPageList.list[playlistIndex] = action.payload;
                }
            })

            //remove
            .addCase(removeSong.fulfilled, (state, action) => {
                if(state.searching) state.dataPageFilter.totalSongs = state.dataPageFilter.totalSongs -1;
                state.dataPageList.totalSongs = state.dataPageList.totalSongs -1;
            })
            .addCase(removeSongs.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(removeSongs.fulfilled, (state, action) => {
                if(state.searching) state.dataPageFilter.totalSongs = state.dataPageFilter.totalSongs - action.payload.length;
                state.dataPageList.totalSongs = state.dataPageList.totalSongs - action.payload.length;
                state.loading = false;
            })
            .addCase(removeSongs.rejected, (state, action) => {
                state.loading = false;
            })

    }
})

const { reducer, actions } = song;
export const { changePage,setSearching } = actions;
export default reducer;
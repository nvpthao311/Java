import React from 'react';
import { Route, Routes, useMatch } from 'react-router-dom';

import ContainerLayout from 'Layouts/ContainerLayout'
import NotFound from 'components/NotFound';
import MainPage from 'features/Song/pages/MainPage';
import AddPage from 'features/Song/pages/AddPage';

Song.propTypes = {};

function Song() {
    const match = useMatch('/music/songs');
    console.log({ match });

    return(

        <Routes>
            <Route element={<ContainerLayout title="Song" />}>
                <Route path="/" element={<MainPage />} />
                <Route path="/add" element={<AddPage />} />
                <Route path="*" element={<NotFound />} />
            </Route>
        </Routes>
    );
}

export default Song;
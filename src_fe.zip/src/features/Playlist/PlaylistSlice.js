import { createSlice, createAsyncThunk  } from '@reduxjs/toolkit';
import PlaylistApi from 'api/playlistApi';

// Async actions
export const fetchPlaylists = createAsyncThunk(
    'playlists/findAll',
    async (params, { rejectWithValue }) => {
        try {
            const response = await PlaylistApi.findAll(params);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);

export const fetchPlaylistById  = createAsyncThunk(
    'playlists/findById',
    async (id, { rejectWithValue }) => {
        try {
            const response = await PlaylistApi.findById(id);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const fetchPlaylistsByName  = createAsyncThunk(
    'playlists/findByName',
    async ( {name , params}, { rejectWithValue }) => {
        if(!name){
            return {response: [], search: []};
        }
        try {
            const response = await PlaylistApi.findByName( name, params );
            console.log("RESPONSE:" , response);
            return {response, search: {searching: true, text: name}};
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);


export const createPlaylist  = createAsyncThunk(
    'playlists/create',
    async ( playlist,{ rejectWithValue }) => {
        try {
            const response = await PlaylistApi.create(playlist);
            console.log("RESPONSE:" , response);
            return response;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const updatePlaylist  = createAsyncThunk(
    'playlists/update',
    async ( playlist, { rejectWithValue }) => {
        try {
            const response = await PlaylistApi.update( playlist.id, playlist);
            console.log("RESPONSE:" , response);
            return playlist;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);
export const removePlaylist  = createAsyncThunk(
    'playlists/remove',
    async ( id, { rejectWithValue }) => {
        try {
            await PlaylistApi.remove(id);
            console.log("RESPONSE: Remove done!");
            return id;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);

export const removePlaylists  = createAsyncThunk(
    'playlists/removeMulti',
    async ( ids, { rejectWithValue }) => {
        try {
            const response = await PlaylistApi.removeMulti(ids);
            console.log("RESPONSE:" , response);
            return ids;
        } catch (error) {
            console.log("ERROR:" , error);
            return rejectWithValue( error.response?.data?.message);
        }
    }
);


// Slice
const playlist = createSlice({
    name: 'playlists',
    initialState: {
        dataPageList: {
            list: [],
            page: {
                current: 0,
                max: 0
            },
            totalPlaylists: 0,
        },
        dataPageFilter: {
            filtered:[],
            page: {
                current: 0,
                max: 0
            },
            totalPlaylists: 0,
            searchText: '',
        },
        searching: false,
        loading: false,
    },

    reducers: {
        changePage: (state, action) => {
            if(!state.searching) {
                state.dataPageList.page.current = action.payload;
            }else{
                state.dataPageFilter.page.current = action.payload;
            }
            console.log("Current page:" ,state.dataPageList.page.current);
        },
    },

    extraReducers: (builder) => {
        builder
            //Playlists
            .addCase(fetchPlaylists.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchPlaylists.fulfilled, (state, action) => {
                state.dataPageList = {
                    list: (action.payload.content || []),
                    page: {
                        current: (action.payload.number || 0),
                        max: ((action.payload.totalPages - 1) || 0),
                    },
                    totalPlaylists: (action.payload.totalElements || 0),
                }
                state.loading = false;
                console.log("List:", state.dataPageList.list);
                console.log("page:" ,state.dataPageList.page.current);
                console.log("Max page:" ,state.dataPageList.page.max);
                console.log("Total playlists:" ,state.dataPageList.totalPlaylists);

            })
            .addCase(fetchPlaylists.rejected, (state, action) => {
                state.loading = false;
            })

            //PlaylistById
            .addCase(fetchPlaylistById.fulfilled, (state, action) => {
                state.searching = true;
                state.dataPageFilter.filtered = [action.payload];
            })

            //PlaylistsByName
            .addCase(fetchPlaylistsByName.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchPlaylistsByName.fulfilled, (state, action) => {
                state.searching = (action.payload.search.searching || false);
                state.dataPageFilter = {
                    searchText: (action.payload.search.text || ''),
                    filtered: (action.payload.response.content || []),
                    page: {
                        current: (action.payload.response.number || 0),
                        max: ((action.payload.response.totalPages -1) || 0),
                    },
                    totalPlaylists: (action.payload.response.totalElements || 0),
                }
                state.loading = false;
                console.log("filtered:", state.dataPageFilter.filtered);
                console.log("page:" ,state.dataPageFilter.page.current);
                console.log("Max page:" ,state.dataPageFilter.page.max);
                console.log("Total Playlists:" ,state.dataPageFilter.totalPlaylists);
                console.log("search text:" ,state.dataPageFilter.searchText);
                console.log("searching:" ,state.searching);
            })
            .addCase(fetchPlaylistsByName.rejected, (state, action) => {
                state.loading = false;
            })

            //create
            .addCase(createPlaylist.fulfilled, (state, action) => {
                state.dataPageList.totalPlaylists = state.dataPageList.totalPlaylists + 1;
            })

            //update
            .addCase(updatePlaylist.fulfilled, (state, action) => {
                if(state.searching){
                    const playlistIndex = state.dataPageFilter.filtered.findIndex(p => p.id === action.payload.id);
                    state.dataPageFilter.filtered[playlistIndex] = action.payload;
                }else{
                    const playlistIndex = state.dataPageList.list.findIndex(p => p.id === action.payload.id);
                    state.dataPageList.list[playlistIndex] = action.payload;
                }
            })

            //remove
            .addCase(removePlaylist.fulfilled, (state, action) => {
                if(state.searching) state.dataPageFilter.totalPlaylists = state.dataPageFilter.totalPlaylists -1;
                state.dataPageList.totalPlaylists = state.dataPageList.totalPlaylists -1;
            })
            .addCase(removePlaylists.pending, (state, action) => {
                state.loading = true;
            })
            .addCase(removePlaylists.fulfilled, (state, action) => {
                if(state.searching) state.dataPageFilter.totalPlaylists = state.dataPageFilter.totalPlaylists - action.payload.length;
                state.dataPageList.totalPlaylists = state.dataPageList.totalPlaylists - action.payload.length;
                state.loading = false;
            })
            .addCase(removePlaylists.rejected, (state, action) => {
                state.loading = false;
            })
    }
})

const { reducer, actions } = playlist;
export const { changePage } = actions;
export default reducer;

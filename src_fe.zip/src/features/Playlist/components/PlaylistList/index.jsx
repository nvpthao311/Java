import React, { useState } from 'react';
import { useSelector} from 'react-redux';
import { FaTrash, FaEdit, FaPlus, FaSearch,  FaAngleDoubleLeft, FaAngleDoubleRight } from 'react-icons/fa';
import PropTypes from 'prop-types';

import SearchBox from 'components/SearchBox';
import PlaylistForm from 'features/Playlist/components/PlaylistForm';

function PlaylistList({
        playlists = [],
        totalPlaylists = 0,
        page = 0,
        onAdd = () => {},
        onEdit = () => {},
        onDelete = () => {},
        onSearch = () => {},
        onView = () => {},
        onChangePage = () => {},
        onDeleteMulti = () => {}
    }) {

    const loading = useSelector(state => state.playlists.loading);

    const [selectedPlaylists, setSelectedPlaylists] = useState([]);
    const [editedPlaylist, setEditedPlaylist] = useState(null);

    // Select
    const isSelected = (id) => selectedPlaylists.includes(id);
    const isAllSelected = selectedPlaylists.length === playlists.length && playlists.length > 0;

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allIds = playlists.map((playlist) => playlist.id);
            setSelectedPlaylists(allIds);
        } else {
            setSelectedPlaylists([]);
        }
    };

    const handleSelectPlaylist = (id) => {
        setSelectedPlaylists((prevSelected) =>
            prevSelected.includes(id)
            ? prevSelected.filter((playlistId) => playlistId !== id)
            : [...prevSelected, id]
        );
    };

    // Delete
    const handleDeletePlaylist = (id) => {
        const confirmDelete = window.confirm('Are you sure you want to delete this song?');
        if(confirmDelete) onDelete(id);
    }

    const handleDeletePlaylists = () => {
        const confirmDelete = window.confirm('Are you sure you want to delete selected songs?');
        if(selectedPlaylists && confirmDelete){
            onDeleteMulti(selectedPlaylists);
            setSelectedPlaylists([]);
        }
    }

    return (
        <>
        <div className="song-playlist-header">
            <h4>Playlist Manager </h4>
            <div className="song-playlist-header__action">
                <button onClick={onAdd} className="btn-action">
                    <FaPlus /> Add
                </button>
                <button onClick={handleDeletePlaylists} className="btn-action">
                    <FaTrash /> Delete
                </button>
                <SearchBox onSearch={onSearch}>
                    <FaSearch /> Search
                </SearchBox>
            </div>
        </div>

        <h5>You have total <strong>{totalPlaylists}</strong> playlists</h5>

        <div className="table-scroll-wrapper">
            {loading ? (
                <div className="spinner"/>
            ) : (
            <>
            <table className="song-playlist-table">
                <thead>
                    <tr>
                        <th className="checkbox">
                            <input
                                type="checkbox"
                                checked={isAllSelected}
                                onChange={handleSelectAll}
                            />
                        </th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody className="song-playlist-table__item">
                    {playlists.length > 0 ? (
                        playlists.map((playlist) => (
                        <React.Fragment key={playlist.id}>
                            <tr key={playlists.id}>
                                <td className="checkbox">
                                <input
                                    type="checkbox"
                                    checked={isSelected(playlist.id)}
                                    onChange={() => handleSelectPlaylist(playlist.id)}
                                />
                                </td>

                                <td onClick={() => onView(playlist.id)}>{playlist.name}</td>

                                <td>
                                    <button onClick={() => setEditedPlaylist(playlist)} className="btn-action">
                                        <FaEdit /> Edit
                                    </button>
                                    <button onClick={() => handleDeletePlaylist(playlist.id)} className="btn-action">
                                        <FaTrash /> Delete
                                    </button>
                                </td>
                            </tr>
                        </React.Fragment>
                        ))) : (
                            <tr>
                                <td colSpan="4">No playlists found.</td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
            </>
            )}
        </div>

        <div className="page-controls">
            <button className="icon" onClick={() => onChangePage("pre")}><FaAngleDoubleLeft /></button>
            <span>{page}</span>
            <button className="icon" onClick={() => onChangePage("next")}><FaAngleDoubleRight /></button>
        </div>

        {editedPlaylist && (
            <div className="edit_form">
                <div className="edit_form_playlist">
                    <PlaylistForm
                        initialValues={editedPlaylist}
                        onSubmit={(value) =>{onEdit(value); setEditedPlaylist(null)}}
                        onCancel={() => setEditedPlaylist(null)}
                    />
                </div>
            </div>
        )}
        </>
    );
}

PlaylistList.propTypes = {
    playlists: PropTypes.arrayOf(
        PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
    })).isRequired,

    totalPlaylists: PropTypes.number.isRequired,
    page: PropTypes.number.isRequired,
    onAdd: PropTypes.func.isRequired,
    onEdit: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    onDeleteMulti: PropTypes.func.isRequired,
    onSearch: PropTypes.func.isRequired,
    onView: PropTypes.func.isRequired,
    onChangePage: PropTypes.func.isRequired,
};

export default PlaylistList;

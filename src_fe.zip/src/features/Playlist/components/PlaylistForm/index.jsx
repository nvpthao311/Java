import React from 'react';
import PropTypes from 'prop-types';
import { Button, FormGroup} from 'reactstrap';
import { Formik, Form, FastField } from 'formik';

import InputField from 'custom-fields/InputField';

import * as Yup from 'yup';

function PlaylistForm({
        initialValues = '',
        onSubmit = () => {},
        onCancel = () => {},
    }) {

    const validationSchema = Yup.object().shape({
        name: Yup.string().required(),
    })

    return(
        <Formik
            initialValues = {initialValues || { name: ''}}
            validationSchema = {validationSchema}
            onSubmit = {onSubmit}
            onCancel = {onCancel}
            enableReinitialize
        >
            {formikProps => {
                const { values, errors, touched } = formikProps;

                return(
                    <Form className="song-playlist-form">
                        <FastField
                            name="name"
                            component={InputField}

                            label="Name"
                            placeholder="Eg: Hello"
                        />
                        <FormGroup className="footer-buttons">
                            <Button type="submit" color="primary">
                                Apply
                            </Button>
                            <Button onClick={onCancel} type="cancel" color="primary">
                                Cancel
                            </Button>
                        </FormGroup>
                    </Form>
                )
            }}
        </Formik>
    );
}

PlaylistForm.propTypes = {
    initialValues: PropTypes.object,
    onSubmit: PropTypes.func.isRequired,
    onCancel: PropTypes.func.isRequired,
}

export default PlaylistForm;
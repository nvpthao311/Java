import React, { useEffect } from "react";
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate } from 'react-router-dom';

import PlaylistList from 'features/Playlist/components/PlaylistList';
import {fetchPlaylistsByName, fetchPlaylists, removePlaylist,removePlaylists, updatePlaylist, changePage } from 'features/Playlist/PlaylistSlice';

function MainPage() {
    const dataPageList = useSelector((state) => state.playlists.dataPageList);
    const dataPageFilter = useSelector((state) => state.playlists.dataPageFilter);
    const searching = useSelector((state) => state.playlists.searching);

    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
        const params = { page: dataPageList.page.current };
        dispatch(fetchPlaylists(params));
    }, [dataPageList.page.current, dataPageList.totalPlaylists]);

    useEffect(() => {
        if(searching){
            const params = { page: dataPageFilter.page.current };
            const name = dataPageFilter.searchText;
            dispatch(fetchPlaylistsByName({ name, params }));
        }
    }, [dataPageFilter.page.current, dataPageFilter.totalPlaylists]);

    const handleAdd = () => {
        navigate("/music/playlists/add");
    }

    const handleEdit = ( playlist ) => {
        dispatch(updatePlaylist(playlist))
    }

    const handleDelete = (id) => {
        dispatch(removePlaylist(id))
    }
    const handleDeleteMulti = (ids) => {
        dispatch(removePlaylists(ids))
    }

    const handleSearch = (name) => {
        const params = { page: 0 };
        dispatch(fetchPlaylistsByName({name, params}))
    }

    const handleView = (id) => {
         navigate(`/music/view/playlist/${id}`);
    }

    const handleChangePageList = ( direction ) => {
        if(direction === "next" && (dataPageList.page.current < dataPageList.page.max)){
            dispatch(changePage(dataPageList.page.current + 1));
        } else if(direction === "pre" && (dataPageList.page.current > 0)){
            dispatch(changePage(dataPageList.page.current - 1));
        } else{
            console.log("Change page " ,direction, " failed!");
        }
    }
    const handleChangePageFilter = ( direction ) => {
        if(direction === "next" && (dataPageFilter.page.current < dataPageFilter.page.max)){
            dispatch(changePage(dataPageFilter.page.current + 1));
        } else if(direction === "pre" && (dataPageFilter.page.current > 0)){
            dispatch(changePage(dataPageFilter.page.current - 1));
        } else{
            console.log("Change page " ,direction, " failed!");
        }
    }

    return (
        (!searching) ? (
        <PlaylistList
            playlists={dataPageList.list}
            totalPlaylists = {dataPageList.totalPlaylists}
            page ={dataPageList.page.current}
            onAdd ={handleAdd}
            onEdit ={handleEdit}
            onDelete ={handleDelete}
            onDeleteMulti ={handleDeleteMulti}
            onSearch ={handleSearch}
            onView = {handleView}
            onChangePage = {handleChangePageList}
        />
        ):(
        <PlaylistList
            playlists={dataPageFilter.filtered}
            totalPlaylists = {dataPageFilter.totalPlaylists}
            page ={dataPageFilter.page.current}
            onAdd ={handleAdd}
            onEdit ={handleEdit}
            onDelete ={handleDelete}
            onDeleteMulti ={handleDeleteMulti}
            onSearch ={handleSearch}
            onView = {handleView}
            onChangePage = {handleChangePageFilter}
        />
        )
    );
}

export default MainPage;
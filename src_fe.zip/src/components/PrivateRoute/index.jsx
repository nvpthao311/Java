import React from 'react';
import { Navigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

function PrivateRoute({ children }) {
    const isLoggedIn = useSelector(state => state.auth.isAuthenticated);
    if (!isLoggedIn) {
        return <Navigate to="/auth/signIn" />;
    }
    return children;
}

export default PrivateRoute;

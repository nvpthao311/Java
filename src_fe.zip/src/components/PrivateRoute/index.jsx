import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

function PrivateRoute({ children }) {
    const navigate = useNavigate();
    const isLoggedIn = useSelector(state => state.auth.isAuthenticated);

    useEffect(() => {
        if (!isLoggedIn) navigate('/auth/signIn');
    }, [isLoggedIn]);

    return children;
}

export default PrivateRoute;

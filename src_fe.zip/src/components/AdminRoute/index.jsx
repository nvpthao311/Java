import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';

const AdminRoute = ({ children }) => {
    const role = useSelector(state => state.auth.account.role);
    const navigate = useNavigate();

    useEffect(() => {
        if (role !== "ROLE_ADMIN") navigate('/music');
    }, [role]);

    return children;
};

export default AdminRoute;

import PropTypes from 'prop-types';
import Select from 'react-select';
import { ErrorMessage } from 'formik'
import './SelectBox.scss'

const SelectBox = ({
        options = {},
        onChange = () => {},
        name = '',
        selected = '',
        placeholder = '',
        disabled = false
    }) => {

    return(
        <>
             <Select
                  className="custom-transparent-select"
                  classNamePrefix="select"
                  id={name}
                  value={options.find(option => option.label === selected)}
                  onChange={onChange}

                  placeholder={placeholder}
                  options={options}
                  disabled={disabled}
             />
        </>
    );
}
SelectBox.propsTypes = {
    options: PropTypes.array.isRequired,
    onChange: PropTypes.func,
    name: PropTypes.string.isRequired,
    selected: PropTypes.string,
    placeholder: PropTypes.string,
    disabled: PropTypes.string,
};

export default SelectBox;
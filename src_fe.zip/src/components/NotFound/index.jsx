import React from 'react';
import './NotFound.scss';

function NotFound() {
    return (
        <div className="not-found">
            Oopss ... Not Found
        </div>
    );
}

export default NotFound;

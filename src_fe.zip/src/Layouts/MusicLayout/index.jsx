import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import { FaBars } from 'react-icons/fa';

import backgroundVideo from "assets/images/background.mp4";
import logo from 'assets/images/logo.png';
import {LANGUAGE_OPTIONS} from 'constants/global.js';
import SelectBox from 'components/SelectBox';
import { logout } from 'features/Auth/AuthSlice';
import "./MusicLayout.scss";

export default function MainLayout() {
    const navigate = useNavigate();
    const dispatch = useDispatch();

    const [showMenu, setShowMenu] = useState(false);
    const [activeButton, setActiveButton] = useState('');

    const account = useSelector(state => state.auth.account);
    const isAdmin = account.role === "ROLE_ADMIN";

    const handleClickUser = () => {
        navigate('/users');
        setActiveButton('users');
    }

    const handleClickLogo = () => {
        navigate('/music');
        setActiveButton('');
    };

    const handleMenuClick = () => {
        setShowMenu(!showMenu);
    };

    const handleClickSongs = () => {
        navigate('/music/songs');
        setActiveButton('songs');
    };

    const handleClickPlaylists = () => {
        navigate('/music/playlists');
        setActiveButton('playlists');
    };

    const handleClickSearch = () => {
        navigate('/music/search');
        setActiveButton('search');
    }

    const handleLogOut = () => {
        const confirmDelete = window.confirm('Are you sure you want to log out?');
        if(confirmDelete) {
            dispatch(logout());
        }
    }

    return (
    <>
        <video autoPlay loop muted>
            <source src={backgroundVideo} type="video/mp4" />
        </video>

        <div className="overlay">
            <header className="header_footer_home">
                <div className="logo" >
                    <img onClick={handleClickLogo} src={logo} alt="logo" />
                    <h2>
                        <span className="danger">MUSIC</span>-MANAGER
                    </h2>
                </div>

                <div className="user">
                    {isAdmin ? (<h3>Admin:</h3>):(<h3>User:</h3>)}
                    {account.username && (<h3>{account.username}</h3>)}
                    <h3> | </h3>
                    <h3>Language</h3>
                    <h3>
                        <SelectBox
                            options={LANGUAGE_OPTIONS}
                            selected="English"
                        />
                    </h3>
                </div>
            </header>

            <main>
                <div className="menu-container">
                    {!showMenu ? (
                        <button onClick={handleMenuClick} className="btn-menu">
                            <FaBars />
                        </button>
                    ) : (
                        <div>
                            <button onClick={handleMenuClick} className="btn-menu">
                                <FaBars />
                            </button>
                            <div className="selections">
                                {isAdmin && (
                                    <button onClick={handleClickUser} className={activeButton === 'users' ? 'active' : ''}>Users</button>
                                )}
                                <button onClick={handleClickSongs} className={activeButton === 'songs' ? 'active' : ''}>Songs</button>
                                <button onClick={handleClickPlaylists} className={activeButton === 'playlists' ? 'active' : ''}>Playlists</button>
                                <button onClick={handleClickSearch} className={activeButton === 'search' ? 'active' : ''}>Search</button>
                                <button onClick={handleLogOut}>Log out</button>
                            </div>
                        </div>
                    )}
                </div>

                <Outlet />
            </main>

            <footer className="header_footer_home">
                @2025 ThaoVo
            </footer>
        </div>
    </>
    );
}

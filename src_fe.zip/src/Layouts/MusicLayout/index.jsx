import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { useNavigate } from "react-router-dom";
import { useDispatch } from 'react-redux';
import { FaBars } from 'react-icons/fa';

import backgroundVideo from "assets/images/background.mp4";
import logo from 'assets/images/logo.png';
import {LANGUAGE_OPTIONS} from 'constants/global.js';
import SelectBox from 'components/SelectBox';
import { logout } from 'features/Auth/AuthSlice';
import "./MusicLayout.scss";

export default function MainLayout() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [showMenu, setShowMenu] = useState(false);

    const handleClickLogo = () => {
        console.log("qua music")
        navigate('/music');
    };

    const handleMenuClick = () => {
        setShowMenu(!showMenu);
    };

    const handleClickSongs = () => {
        navigate('/music/songs');
    };

    const handleClickPlaylists = () => {
        navigate('/music/playlists');
    };

    const handleClickSearch = () => {
        navigate('/music/search');
    }

    const handleLogOut = () => {
        const confirmDelete = window.confirm('Are you sure you want to log out?');
        if(confirmDelete) {
            dispatch(logout());
        }
    }

    return (
    <>
        <video autoPlay loop muted>
            <source src={backgroundVideo} type="video/mp4" />
        </video>

        <div className="overlay">
            <header className="header_footer_home">
                <div className="logo" >
                    <img onClick={handleClickLogo} src={logo} alt="logo" />
                    <h2>
                        <span className="danger">MUSIC</span>-MANAGER
                    </h2>
                </div>

                <div className="user">
                    <h3>Admin</h3>
                    <h3> | </h3>
                    <h3>Language</h3>
                    <h3>
                        <SelectBox
                            options={LANGUAGE_OPTIONS}
                            selected="English"
                        />
                    </h3>
                </div>
            </header>

            <main>
                <div className="menu-container">
                    {!showMenu ? (
                        <button onClick={handleMenuClick} className="btn-menu">
                            <FaBars />
                        </button>
                    ) : (
                        <div>
                            <button onClick={handleMenuClick} className="btn-menu">
                                <FaBars />
                            </button>
                            <div className="selections">
                                <button onClick={handleClickSongs}>Songs</button>
                                <button onClick={handleClickPlaylists}>Playlists</button>
                                <button onClick={handleClickSearch}>Search</button>
                                <button onClick={handleLogOut}>Log out</button>
                            </div>
                        </div>
                    )}
                </div>

                <Outlet />
            </main>

            <footer className="header_footer_home">
                @2025 ThaoVo
            </footer>
        </div>
    </>
    );
}

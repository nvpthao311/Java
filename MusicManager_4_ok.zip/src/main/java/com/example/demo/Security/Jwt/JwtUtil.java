package com.example.demo.Security.Jwt;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String SECRET;

    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username) // The main information in the token (here is the username)
                .setIssuedAt(new Date(System.currentTimeMillis())) // token generation time
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // 1 hour after expiration
                .signWith(Keys.hmacShaKeyFor(SECRET.getBytes()), SignatureAlgorithm.HS256) // Token signing using HS256 algorithm
                .compact(); // generate token as String
    }

    //Get information from token
    public String extractUsername(String token) {
        return Jwts.parser() //Create a JWT parser — an object used to parse and authenticate tokens
                .setSigningKey(SECRET.getBytes()) // Assign a secret key so that the parser can verify the token's signature.
                .build() //Create a real parser from the builder.
                .parseClaimsJws(token) // Parse the token (JWS = signed JWT) and return the payload if the token is valid.
                .getBody()
                .getSubject(); // get username from "subject" section
    }

    //Kiểm tra token hợp lệ
    public boolean validateToken(String token, UserDetails userDetails) {
        final String username = extractUsername(token); // get username from token
        return username.equals(userDetails.getUsername()) && !isTokenExpired(token); // compare username and check token expiration
    }

    //Check expired token
    private boolean isTokenExpired(String token) {
        Date expiration = Jwts.parser()
                .setSigningKey(SECRET.getBytes())
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getExpiration();
        return expiration.before(new Date()); // if expiration time < current time → expired
    }



}

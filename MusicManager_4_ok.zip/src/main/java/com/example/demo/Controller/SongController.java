package com.example.demo.Controller;

import com.example.demo.Model.Song;
import com.example.demo.Service.SongService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/songs")
@Tag(name = "Song Controller", description = "Operations related to songs")
public class SongController {

    @Autowired
    private SongService songService;

    @Operation(summary = "Get song by ID", description = "Retrieve a song by its ID")
    @GetMapping("/{id}")
    public Song findById(
            @Parameter(description = "ID of the song to be fetched")
            @PathVariable Long id) {
        return songService.findById(id);
    }

    @Operation(summary = "Get songs by name", description = "Retrieve a list of songs that match the given name")
    @GetMapping("name/{name}")
    public Page<Song> findByNameContainingIgnoreCase(
            @Parameter(description = "Name of the song to search for")
            @PathVariable String name,
            Pageable pageable) {
        return songService.findByNameContainingIgnoreCase(name, pageable);
    }

    @Operation(summary = "Get all songs", description = "Retrieve a list of all songs")
    @GetMapping
    public Page<Song> findAll(Pageable pageable ) {
        return songService.findAll(pageable);
    }

    @Operation(summary = "Create a new song", description = "Create a new song with the provided information")
    @PostMapping
    public Song createSong(
            @RequestBody Song song) {
        return songService.createSong(song);
    }

    @Operation(summary = "Update song by ID", description = "Update an existing song by its ID")
    @PutMapping("/{id}")
    public Song updateSong(
            @Parameter(description = "ID of the song to be updated")
            @PathVariable Long id,
            @RequestBody Song song) {
        return songService.updateSong(id, song);
    }

    @Operation(summary = "Delete song by ID", description = "Delete a song by its ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSongById(
            @Parameter(description = "ID of the song to be deleted")
            @PathVariable Long id) {
        songService.deleteSongById(id);
        return ResponseEntity.ok().build();
    }

    @Operation(summary = "Delete multiple songs by Id", description = "This endpoint allows you to delete multiple songs by Id")
    @PostMapping("/delete-multi")
    public ResponseEntity<String> deletePlaylistAllById(
            @Parameter(description = "List of song Ids to be deleted", required = true)
            @RequestBody List<Long> ids){
        songService.deleteSongAllById(ids);
        return ResponseEntity.ok("Songs deleted successfully.");
    }
}



import axios from 'axios';
import queryString from 'query-string';

// Tạo instance của axios với cấu hình sẵn query-string
const apiClient = axios.create({
  baseURL: process.env.REACT_APP_API_URL,
  header: {
    'content-type' : 'application/json'
  },
  paramsSerializer: params => queryString.stringify(params),
});

axiosClient.interceptors.request.use(async (config) => {
    return config;
})

axiosClient.interceptors.response.use((response) => {
    if (response && response.data) {
        return response.data;
    }

    return response;
}, (error) => {
    throw error;
});

export default axiosClient;



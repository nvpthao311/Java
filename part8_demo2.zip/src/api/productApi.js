const productApi = {
    getAll: (params) => {
        const url = '/products';
        return axiosClient.get(url, {params});
    },

    get: (id) => {
        const url = `/product/${id}`;
        return axiosClient.get(url, {params});
    },
}

export default productApi;

import PropTypes from 'prop-types';
import React from 'react';
import {Button} from 'reactstrap';
import './RandomPhoto.scss';

RandomPhoto.propsTypes = {
    name: PropTypes.string,
    imageUrl: PropTypes.string,
    onImageUrlChange: PropTypes.func,
    onRandomButtonBlur: PropTypes.func,
};

RandomPhoto.defaultProps = {
    name: '',
    imageUrl: '',
    onImageUrlChange: null,
    onRandomButtonBlur: null,
}

const getRandomImageUrl = () => {
  const randomId = Math.trunc(Math.random() * 1000);
  return `https://picsum.photos/id/${randomId}/300/300`;
}

function RandomPhoto(props) {
    const { name, imageUrl, onRandomButtonBlur, onImageUrlChange } = props;

    const handleRandomPhotoClick = async () => {
        if (onImageUrlChange) {
            const randomImageUrl = getRandomImageUrl();
            onImageUrlChange(randomImageUrl)
        }
    }

    return (
        <div className="random-photo">
            <div className="random-photo_button">
                <Button
                    outline
                    name={name}
                    color="primary"
                    onBlur={onRandomButtonBlur}
                    onClick={handleRandomPhotoClick}
                >
                    Random a photo
                </Button>
            </div>
            <div className="random-photo_photo">
                {imageUrl && <img src={imageUrl} alt="Ooops .. not found, please click random again!"/>}
            </div>
        </div>
    );
}

export default RandomPhoto;
import { createSlice } from '@reduxjs/toolkit';

let nextId = 1;

const photo = createSlice({
    name: 'photos',
    initialState: [],
    reducers: {
        addPhoto: (state, action) => {
            const newPhoto = {
                id: nextId++,
                ...action.payload,
            };
            state.push(newPhoto);
        },

        removePhoto: (state, action) => {
            const removePhotoId = action.payload;
            return state = state.filter(photo => photo.id !== removePhotoId);
        },

        editPhoto: (state, action) => {
            const newPhoto =  action.payload;
            const photoIndex = state.findIndex(photo => photo.id === newPhoto.id);

            if(photoIndex != null){
                state[photoIndex] = newPhoto;
            }
        }

    }
})

const { reducer, actions } = photo;
export const {addPhoto, removePhoto, editPhoto} = actions;
export default reducer;
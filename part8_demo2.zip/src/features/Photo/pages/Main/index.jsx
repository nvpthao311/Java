import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { Container } from 'reactstrap';

import { removePhoto, editPhoto } from 'features/Photo/PhotoSlice';
import Banner from 'components/Banner';
import Images from 'constants/images';
import PhotoList from 'features/Photo/components/PhotoList';
import './Main.scss';

function MainPage(props) {
    const photos = useSelector(state => state.photos)
    const dispatch = useDispatch();

    const handleEdit = (photo) => {
      console.log('Edit', photo);

      const action = editPhoto(photo);
      dispatch(action);
    };

    const handleRemove = (photoId) => {
      console.log('Remove', photoId);

      const action = removePhoto(photoId);
      dispatch(action);
    };

    return (
        <div className="photo-main">
            <Banner title="Your awesome photos" backgroundUrl={Images.BG_02}/>

            <Container>
                <Link to="/photos/add" className="photo-main__add-btn">
                    Add new photo
                </Link>

                <PhotoList
                    photos={photos}
                    onEdit={handleEdit}
                    onRemove={handleRemove}
                />
            </Container>
        </div>


  );
}

export default MainPage;
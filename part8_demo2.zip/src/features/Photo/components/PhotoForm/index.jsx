import React from 'react';
import PropTypes from 'prop-types';
import { Button, FormGroup} from 'reactstrap';
import { PHOTO_CATEGORY_OPTIONS } from 'constants/global';
import { Formik, Form, FastField } from 'formik';
import InputField from 'custom-fields/InputField';
import SelectField from 'custom-fields/SelectField';
import RandomPhotoField from 'custom-fields/RandomPhotoField'
import './PhotoForm.scss';

import * as Yup from 'yup';

function PhotoForm(props) {
    const initialValues = {
        title:'',
        category:'',
        photo:'',
    };

    const validationSchema = Yup.object().shape({
        title: Yup.string().required(),
        category: Yup.string().required(),
        photo: Yup.string().required(),
    })

    return(
        <Formik
            initialValues = {initialValues}
            validationSchema={validationSchema}
            onSubmit={props.onSubmit}
        >
            {formikProps => {
                const { values, errors, touched } = formikProps;
                console.log({ values, errors, touched });

                return(
                    <Form className="photo-form">
                        <FastField
                            name="title"
                            component={InputField}

                            label="Title"
                            placeholder="Eg: Wow ..."
                        />
                        <FastField
                            name="category"
                            component={SelectField}

                            label="Category"
                            placeholder="what's your photo category?"
                            options={PHOTO_CATEGORY_OPTIONS}
                        />

                        <FastField
                            name="photo"
                            component={RandomPhotoField}

                            label="Photo"
                        />

                        <FormGroup>
                            <Button type="submit" color="primary">Add to album</Button>
                        </FormGroup>
                    </Form>
                )
            }}
        </Formik>
    );
}

PhotoForm.propTypes = {
    onSubmit: PropTypes.func,
}

PhotoForm.defaultProps = {
    onSubmit: null,
}

export default PhotoForm;
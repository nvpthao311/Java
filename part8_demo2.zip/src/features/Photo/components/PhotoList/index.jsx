import React, { useState }  from 'react';
import PropTypes from 'prop-types';
import './PhotoList.scss';
import PhotoEditForm from 'features/Photo/components/PhotoEditForm'


function PhotoList(props) {
  const { photos, onEdit, onRemove } = props;
  const [selectedPhoto, setSelectedPhoto] = useState(null);


  if (!photos || photos.length === 0) {
    return <p className="photo-list__empty">No photos found.</p>;
  }

  return (
    <div className="photo-list">
      {photos.map((photo) => (
        <div key={photo.title} className="photo-card">

          <div className="photo-card__img-wrapper">
            <img
              src={photo.photo}
              alt={photo.title}
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = 'img.png';
              }}
            />
          </div>

          <div className="photo-card__overlay">
            <div className="photo-card__info">
              <h3>{photo.title}</h3>
              <p>{photo.category}</p>
            </div>
            <div className="photo-card__actions">
              <button
                onClick={() => setSelectedPhoto(photo)}
                className="btn btn-sm btn-outline-light"
              >
                Edit
              </button>
              <button
                onClick={() => onRemove(photo.id)}
                className="btn btn-sm btn-outline-light"
              >
                Remove
              </button>
            </div>
          </div>

        </div>
      ))},

        {selectedPhoto && (
          <div className="edit-overlay">
            <PhotoEditForm
              initialValues={selectedPhoto}
              onSubmit={onEdit}
              onCancel={() => setSelectedPhoto(null)} // nếu người dùng cancel
            />
          </div>
        )}

    </div>
  );
}

PhotoList.propTypes = {
  photos: PropTypes.arrayOf(
    PropTypes.shape({
      title: PropTypes.string,
      category: PropTypes.string,
      photo: PropTypes.string,
    })
  ).isRequired,
  onEdit: PropTypes.func.isRequired,
  onRemove: PropTypes.func.isRequired,
};

export default PhotoList;


import React from 'react';
import PropTypes from 'prop-types';
import { Formik, Form, FastField } from 'formik';
import { Button, FormGroup } from 'reactstrap';
import * as Yup from 'yup';

import InputField from 'custom-fields/InputField';
import SelectField from 'custom-fields/SelectField';
import RandomPhotoField from 'custom-fields/RandomPhotoField';
import { PHOTO_CATEGORY_OPTIONS } from 'constants/global';
import './PhotoEditForm.scss'

function PhotoEditForm(props) {
  const { initialValues, onSubmit, onCancel } = props;

  const validationSchema = Yup.object().shape({
    title: Yup.string().required('This field is required.'),
    category: Yup.string().required('This field is required.'),
    photo: Yup.string().required('This field is required.'),
  });

  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validationSchema}
      onSubmit={onSubmit}
      onCancel={onCancel}
      enableReinitialize //Mỗi khi initialValues thay đổi, Formik reset form và đồng bộ giá trị mới vào form.
    >
      {(formikProps) => {
        return (
          <Form className="photo-form">
            <FastField
              name="title"
              component={InputField}
              label="Title"
            />
            <FastField
              name="category"
              component={SelectField}
              label="Category"
              options={PHOTO_CATEGORY_OPTIONS}
            />
            <FastField
              name="photo"
              component={RandomPhotoField}
              label="Photo"
            />

            <FormGroup className="btn_PhotoEditForm">
              <Button type="submit" color="primary">
                Save Changes
              </Button>
              <Button type="button" color="secondary" onClick={onCancel}>
                Cancel
              </Button>
            </FormGroup>
          </Form>
        );
      }}
    </Formik>
  );
}

PhotoEditForm.propTypes = {
  initialValues: PropTypes.object.isRequired,
  onSubmit: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
};

export default PhotoEditForm;

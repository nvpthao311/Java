package com.example.demo.Service;

import com.example.demo.Model.Student;
import com.example.demo.Model.Teacher;
import com.example.demo.Repository.StudentRepository;
import com.example.demo.Repository.TeacherRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TeacherStudentService {

    private final StudentRepository studentRepository;
    private final TeacherRepository teacherRepository;

    public Student addStudentToList(Student student){

    }

    public Teacher addTeacher(Teacher teacher){

    }


}

package com.example.demo.Service;

import org.springframework.stereotype.Service;

@Service
public class TeacherService {

    private TeacherService teacherService;
}

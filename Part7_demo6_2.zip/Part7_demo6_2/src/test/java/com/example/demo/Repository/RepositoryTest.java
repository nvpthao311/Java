package com.example.demo.Repository;

import com.example.demo.Model.Student;
import com.example.demo.Model.Teacher;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest
public class RepositoryTest {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    private Student s1,s2,s3,s4;
    private Teacher t1, t2;

    @BeforeEach
    void setUp(){
        s1 = new Student("my", 7878712);
        s2 = new Student( "bich", 654454);
        s3 = new Student( "my", 878798);
        s4 = new Student( "ngoc", 1187623);

        t1 = new Teacher( "lily", 123);
        t2 = new Teacher("Alex", 456);
    }
}

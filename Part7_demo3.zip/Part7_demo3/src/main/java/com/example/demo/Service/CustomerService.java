package com.example.demo.Service;

import com.example.demo.Model.Order;
import com.example.demo.Repository.OrderReposity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    
    @Autowired
    private OrderReposity orderReposity;

    //them
    public Order createCustomer (Order order) {
        return orderReposity.save(order);
    }

    //sua
    public Order updateById (long id, Order order){
        Optional<Order> optionalCustomer = orderReposity.findById(id);

        if (optionalCustomer.isPresent()){
            Order ord = optionalCustomer.get();

            ord.setOrder_date(order.getOrder_date());
            ord.setTotal_price(order.getTotal_price());
            ord.setCustomer_id(order.getCustomer_id());

            orderReposity.save(ord);
            return ord;
        }
        return null;
    }

    //xoa
    public void deleteOrder(long id){
        orderReposity.deleteAllById(id);
    }

    //tim kiem
    public Order findById (long id){
        Optional<Order> optionalOrder = orderReposity.findById(id);
        if (optionalOrder.isPresent()){
            Order order = optionalOrder.get();
            return  order;
        }
        return null;
    }

    public List<Order> findAll (){
        return orderReposity.findAll();
    }









}

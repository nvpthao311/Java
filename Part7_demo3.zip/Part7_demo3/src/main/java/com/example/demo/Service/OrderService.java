package com.example.demo.Service;

import com.example.demo.Repository.OrderReposity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @Autowired
    private OrderReposity orderReposity;




}

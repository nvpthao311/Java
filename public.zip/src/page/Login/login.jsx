import React from "react";
import "./login.css";
import backgroundVideo from "./images/background.mp4";
import logo from "./images/logo.png";
import "material-icons/iconfont/material-icons.css";


function Login() {
  return (
    <>
      <video autoPlay muted loop playsInline id="bg-video">
        <source src={backgroundVideo} type="video/mp4" />
      </video>

      <header>
        <div className="logo">
          <img src={logo} alt="logo" />
          <h2>
            MUSIC-<span className="danger">MANAGER</span>
          </h2>
        </div>
        <div className="sign-up">
          <h3 style={{ color: "white" }}>Don't have an account?</h3>
          <button onClick={() => alert('Sign up')}>
              <h2>Sign up</h2>
          </button>
        </div>
      </header>

      <aside>
        <div className="login">
          <h2 style={{ display: "flex", justifyContent: "center" }}>Sign In</h2>

          <h3>Email:</h3>
          <div className="box-input">
            <input type="text" id="name" placeholder="Enter your email" />
            <span className="material-icons-sharp">mail_outline</span>
          </div>

          <h3>Password:</h3>
          <div className="box-input">
            <input type="password" id="pass" placeholder="Enter password" />
            <span className="material-icons-sharp" id="lock">lock_outline</span>
          </div>

          <div className="forget">
            <label>
              <input type="checkbox" /> Remember Me
            </label>
            <button onClick={() => alert('Forget Password')}>
              Forget Password
            </button>
          </div>

          <button id="button-login">
            <h2>Log In</h2>
          </button>

        </div>
      </aside>

      <footer>
        <span>
          This site is protected by <u>ThaoVo</u>, and the Google Privacy Policy
          and Terms of Service apply.
        </span>
      </footer>
    </>
  );
};

export default Login;

import background01 from "assets/images/background01.png";
import background02 from "assets/images/background02.png"

const Images = {
    BG_01: background01,
    BG_02: background02,
}
export default Images;
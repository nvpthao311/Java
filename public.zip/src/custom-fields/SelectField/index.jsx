import PropTypes from 'prop-types';
import React from 'react';
import Select from 'react-select';
import { FormFeedback, FormGroup, Label} from 'reactstrap';
import { ErrorMessage } from 'formik'


InputField.propsTypes = {
    field: PropTypes.object.isRequired,
    from: PropTypes.object.isRequired,

    options: PropTypes.array,
    label: PropTypes.string,
    placeholder: PropTypes.string,
    disabled: PropTypes.string,
};

InputField.defaultProps = {
    options: '',
    label: '',
    placeholder: '',
    disabled: false,
}

function InputField(props) {
    const {
        field, form,
        options, label, placeholder, disabled,
    } = props
    const { name } = field;
    const { errors, touched } = form;

    const showError = errors[name] && touched[name];

    const handleSelectedOptionChange = (selectOption) => {
        const selectedValue = selectOption ? selectOption.label : selectOption;

        const changeEvent = {
            target: {
                name: name,
                value: selectedValue,
            }
        }
        field.onChange(changeEvent);
    }

    return (
        <FormGroup>
             {label && <Label for={name}>{label}</Label>}
             <Select
                  id={name}
                  {...field}
                  onChange={handleSelectedOptionChange}
                  value={options.find(option => option.value === field.value)}

                  placeholder={placeholder}
                  options={options}
                  disabled={disabled}

                  className={showError ? 'is-invalid' : ''}
             />

            <ErrorMessage name={name} component={FormFeedback}/>
        </FormGroup>
    );
}

export default InputField;
import PropTypes from 'prop-types';
import React from 'react';
import {FormFeedback, FormGroup, Input, Label} from 'reactstrap';
import { ErrorMessage } from 'formik'

InputField.propsTypes = {
    field: PropTypes.object.isRequired,
    from: PropTypes.object.isRequired,

    type: PropTypes.string,
    label: PropTypes.string,
    placeholder: PropTypes.string,
    disabled: PropTypes.string,
};

InputField.defaultProps = {
    type: 'text',
    label: '',
    placeholder: '',
    disabled: false,
}

function InputField(props) {
    const {
        field, form,
        type, label, placeholder, disabled,
    } = props
    const { name } = field;
    const { errors, touched } = form;

    const showError = errors[name] && touched[name];

    return (
        <FormGroup>
             {label && <Label for={name}>{label}</Label>}
             <Input
                id={name}
                {...field}

                type={type}
                disabled={disabled}
                placeholder={placeholder}

                invalid={showError}
                //Reactstrap sẽ thêm class .is-invalid: Viền input chuyển sang màu đỏ; Hiển thị biểu tượng hoặc style lỗi (tùy theme)
             />

             <ErrorMessage name={name} component={FormFeedback}/>
        </FormGroup>
    );
}

export default InputField;
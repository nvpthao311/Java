//import { Routes, Route } from 'react-router-dom';
import Login from './page/Login/login';
//import Home from './page/Home/home';
//import MainLayout from './layout/MainLayout';

function App() {
//  return (
//    <Routes>
//      <Route path="" element={<Home />} />
//
//    </Routes>
//  );

    return <Login />;
}

export default App;


import React from 'react';
import PropTypes from 'prop-types';
import './banner.scss';

Banner.propTypes ={
    title: PropTypes.string,
    backgroundUrl: PropTypes.string,
};

Banner.defaultProps = {

}
import React from 'react';

function NotFound() {
    return (
        <div>
            Oopss ... Not Found
        </div>
    );
}

NotFound.propTypes = {};

export default NotFound;
import React from 'react';
import { NavLink } from 'react-router-dom';
import { Col, Container, Row } from 'reactstrap';

import './header.scss';

function Header(){
    return(
        <header className="header">
            <Container>
                <Row className="justify-content-between">
                    <Col xs="auto" className="header_link">
                        Easy Frontend
                    </Col>

                    <Col xs="auto">
                        <NavLink
                            className="header_link"
                            to="/photos"
                            end
                            className={({ isActive }) =>
                                 isActive ? 'header_link header_link--active' : 'header_link'
                            }
                        >
                        Redux Project
                        </NavLink>
                    </Col>
                </Row>
            </Container>
        </header>
    );
}
export default Header;
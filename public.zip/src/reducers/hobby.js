
const initialState = {
    list: [],
    activeI: null,
}

const hobbyReducer = (state = initialStat e, action) => {
    switch(action.type) {
        case 'ADD_HOBBY':{
            return state;
        }

        case 'SET_ACTIVE_HOBBY': {
            return state;
        }

        default:
            return state;
    }
}

export default hobbyReducer;
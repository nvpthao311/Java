
import React from 'react';

HomePage.propTypes = {

};

function HomePage(props) {
    return(
        <div className="home-page">
            <h1> Xin chào nha </h1>
        </div>
    );
}

export default HomePage;
import React from 'react';

function AddEditPage() {
  return (
    <div style={{ padding: '40px', textAlign: 'center' }}>
      <h1>Add Edit Page</h1>
      <p> You're now on the Add Edit Page!</p>
    </div>
  );
}

export default AddEditPage;
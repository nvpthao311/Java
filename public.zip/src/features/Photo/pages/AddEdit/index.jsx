import React from 'react';
import Banner from 'components/Banner';
import PhotoForm from 'features/Photo/components/PhotoForm';
import { useDispatch } from 'react-redux';
import { addPhoto } from 'features/Photo/PhotoSlice';
import { useNavigate  } from 'react-router-dom';

function AddEditPage() {
    const dispatch = useDispatch();
    const navigate  = useNavigate ();

    const handleSubmit = (values) => {
        console.log('Form submit:', values);

        const action = addPhoto(values);
        console.log({action});
        dispatch(action);

        navigate('/photos');
    }

    return (
        <div className="add_edit">
            <Banner title="Pick your amazing photo" backgroundUrl=""/>

            <div>
                <PhotoForm onSubmit={handleSubmit}/>
            </div>
        </div>
    );
}

export default AddEditPage;
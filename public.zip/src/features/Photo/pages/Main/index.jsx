import React from 'react';
import { useSelector, } from 'react-redux';
import { Link } from 'react-router-dom';
import { Container } from 'reactstrap';

import Banner from 'components/Banner';
import Images from 'constants/images';
import PhotoList from 'features/Photo/components/PhotoList';
import './Main.scss';

function MainPage(props) {
    const photos = useSelector(state => state.photos)

    const handleEdit = (photo) => {
      console.log('Edit', photo);
    };

    const handleRemove = (photo) => {
      console.log('Remove', photo);
    };

    return (
        <div className="photo-main">
            <Banner title="Your awesome photos" backgroundUrl={Images.BG_02}/>

            <Container>
                <Link to="/photos/add" className="photo-main__add-btn">
                    Add new photo
                </Link>

                <PhotoList
                    photos={photos}
                    onEdit={handleEdit}
                    onRemove={handleRemove}
                />
            </Container>
        </div>


  );
}

export default MainPage;
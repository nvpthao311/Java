import React from 'react';

function MainPage() {
  return (
    <div style={{ padding: '40px', textAlign: 'center' }}>
      <h1>Main Page</h1>
      <p> You're now on the Main Page!</p>
    </div>
  );
}

export default MainPage;
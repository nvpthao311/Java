package com.example.demo.Service;

import com.example.demo.Exception.NotFoundException;
import com.example.demo.Model.Playlist;
import com.example.demo.Model.Song;
import com.example.demo.Repository.PlaylistRepository;
import com.example.demo.Repository.SongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class PlaylistSongService {

    @Autowired
    private SongRepository songRepository;

    @Autowired
    private PlaylistRepository playlistRepository;

    public Set<Song> createSongsForPlaylist(Long id_playlist, List<Long> id_songs){
        Playlist playlist = playlistRepository.findById(id_playlist)
                .orElseThrow(() -> new NotFoundException(id_playlist, "Playlist"));

        Set<Song> validSongs = new HashSet<>();
        Set<Long> invalidIds = new HashSet<>();

        for ( Long id : id_songs){
            songRepository.findById(id).ifPresentOrElse(
                    song -> {
                        song.getPlaylists().add(playlist);
                        songRepository.save(song);
                        validSongs.add(song);
                    },
                    () -> invalidIds.add(id));
        }

        playlist.setSongs(validSongs);


        if (!invalidIds.isEmpty()){
            System.out.println("Ids is invalid: " + invalidIds);
        }

        return validSongs;
    }

    public Set<Playlist> createPlaylistsForSong(Long id_song, List<Long> id_playlists){
        Song song = songRepository.findById(id_song)
                .orElseThrow(() -> new NotFoundException(id_song, "Song"));

        Set<Playlist> validPlaylists = new HashSet<>();
        Set<Long> invalidIds = new HashSet<>();

        for (long id : id_playlists){
            playlistRepository.findById(id).ifPresentOrElse(
                    playlist -> {
                        playlist.getSongs().add(song);
                        playlistRepository.save(playlist);
                        validPlaylists.add(playlist);
                    },
                    () -> invalidIds.add(id)
            );
        }

        song.setPlaylists(validPlaylists);

        if (!invalidIds.isEmpty()){
            System.out.println("Ids is invalid: " + invalidIds);
        }

        return validPlaylists;
    }

}

package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @GetMapping("/mymusic/home")
    public String home() {
        messagingTemplate.convertAndSend("topic/notifications", "Chào mừng bạn đã đến với MyMusic");
        System.out.println(">>> Đã gửi message WebSocket");

        return "redirect:/home.html";
    }
}

package com.example.demo.websocket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NotificationController {

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

//    @PostMapping("/notify")
//    public ResponseEntity<String> sendNotification(@RequestParam String message){
//        messagingTemplate.convertAndSend("/topic/notifications", message);
//        return ResponseEntity.ok("Notification sent!" + message);
//    }


}

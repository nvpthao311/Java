package com.example.demo.Exception;

public class NotFoundException extends RuntimeException{

    public NotFoundException(Long id, String ojt){
        super ( ojt + " with ID: " + id + " not found!");
    }
}

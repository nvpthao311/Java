package com.example.demo.Service;

import com.example.demo.Exception.NotFoundException;
import com.example.demo.Model.Playlist;
import com.example.demo.Model.Song;
import com.example.demo.Repository.PlaylistRepository;
import com.example.demo.Repository.SongRepository;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.beans.Transient;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class PlaylistSongServiceTest {

    @Autowired
    PlaylistRepository playlistRepository;

    @Autowired
    SongRepository songRepository;

    @Autowired
    PlaylistSongService playlistSongService;

    private Playlist p1, p2;
    private Song s1, s2, s3, s4, s5, s6;

    @BeforeEach
    void setup(){
        p1 = new Playlist("list1");
        p2 = new Playlist("list2");
        playlistRepository.saveAll(Set.of(p1, p2));

        s1 = new Song("what do you mean", "Justin", "pop", "uploads/song1.mp3");
        s2 = new Song("Timber","PitBull",null,"uploads/song2.mp3");
        s3 = new Song("Hello","Adel", null, "uploads/song3.mp3");
        s4 = new Song("lock what you made me do","Taylor", null, "uploads/song4.mp3");
        s5 = new Song("Hot N Cold", "Katty",null, "uploads/song5.mp3");
        s6 = new Song("Hello", "SHINee", null, "uploads/song6.mp3");
        songRepository.saveAll(Set.of(s1, s2, s3, s4));

    }

    @Test
    @Transactional
    void createSongsForPlaylist() {
        playlistSongService.createSongsForPlaylist(1L, List.of(1L, 4L));

        Playlist playlist = playlistRepository.findById(1L).orElse(null);
        assertEquals(2, playlist.getSongs().size());

        Song song = songRepository.findById(1L).orElse(null);
        assertEquals(1, song.getPlaylists().size());

        //so sanh them dung doi tuong s1, s4
    }

    @Test
    @Transactional
    void createPlaylistsForSong() {
        Set<Playlist> valid = playlistSongService.createPlaylistsForSong(3L, List.of(1L, 2L));
        assertEquals(2, valid.size());

        Song song = songRepository.findById(3L).orElse(null);
        assertEquals(2, song.getPlaylists().size());

        Playlist playlist = playlistRepository.findById(1L).orElse(null);
        assertEquals(1, playlist.getSongs().size());

    }
}
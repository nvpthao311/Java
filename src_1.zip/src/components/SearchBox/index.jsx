import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { FaSearch, FaTimes } from 'react-icons/fa';
import './SearchBox.scss'; // Hoặc .css tuỳ bạn

const SearchBox = (props) => {
    const {onSearch} = props;

    const [showInput, setShowInput] = useState(false);
    const [searchText, setSearchText] = useState('');

    const handleSearchClick = () => {
        setShowInput(true);
    };

    const handleSearchText = (text) => {
        setSearchText(text);
        onSearch(text);
    }

    const handleClear = () => {
        onSearch('');
        setSearchText('');
        setShowInput(false);
    };

    return (
        <div>
            {!showInput ? (
                <button onClick={handleSearchClick} className="btn-action">
                    <FaSearch /> Search
                </button>
            ) : (
                <div className="search-container">
                    <FaSearch className="search-icon" />
                    <input
                        type="text"
                        value={searchText}
                        onChange={(e) => handleSearchText(e.target.value)}
                        placeholder="search"
                        className="search-input"
                    />
                    <FaTimes className="clear-icon" onClick={handleClear} />
                </div>
            )}
        </div>
    );
};

SearchBox.propsTypes = {
    onSearch: PropTypes.func.isRequired,
};

SearchBox.defaultProps = {
    onSearch: '',
}
export default SearchBox;

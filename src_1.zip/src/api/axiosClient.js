import axios from 'axios';
import queryString from 'query-string';

// Set up default config for http request here
const axiosClient = axios.create ({
    baseUrl: process.env.REACT_APP_API_URL,
    header: {
        'content-type': 'application/json',
    },
    paramsSerializer: params => queryString.stringify(params),
});

axiosClient.interceptors.request.use(async (config) => {
    //handle token here ...
    return config
});

axiosClient.interceptors.response.use((response) => {
    if (response && response.data) {
        return response.data;
    }
    return response;
}, (error) => {
    //handle errors
    throw error;
});

export default axiosClient;
import React from 'react';
import { useNavigate } from "react-router-dom";

function MainPage() {
    const navigate = useNavigate();

    return(null)
}

export default MainPage;
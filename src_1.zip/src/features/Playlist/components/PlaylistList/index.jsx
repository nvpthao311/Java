import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { FaTrash, FaEdit, FaPlus, FaSearch  } from 'react-icons/fa';

import SearchBox from 'components/SearchBox';
import PlaylistForm from 'features/Playlist/components/PlaylistForm';

function PlaylistList(props) {
    const { playlists, onAdd, onEdit, onDelete, onSearch} = props;

    const [selectedPlaylists, setSelectedPlaylists] = useState([]);
    const [editedPlaylist, setEditedPlaylist] = useState(null);

    // Select
    const isSelected = (id) => selectedPlaylists.includes(id);
    const isAllSelected = selectedPlaylists.length === playlists.length && playlists.length > 0;

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allIds = playlists.map((playlist) => playlist.id);
            setSelectedPlaylists(allIds);
        } else {
            setSelectedPlaylists([]);
        }
    };

    const handleSelectPlaylist = (id) => {
        setSelectedPlaylists((prevSelected) =>
            prevSelected.includes(id)
            ? prevSelected.filter((playlistId) => playlistId !== id)
            : [...prevSelected, id]
        );
    };

    // Delete
    const handleDeletePlaylist = (id) => {
        const confirmDelete = window.confirm('Are you sure you want to delete this song?');
        onDelete(id);
    }

    const handleDeletePlaylists = () => {
        const confirmDelete = window.confirm('Are you sure you want to delete selected songs?');
        if(selectedPlaylists && confirmDelete){
            selectedPlaylists.map((id) => {
                onDelete(id);
            });
            setSelectedPlaylists([]);
        }
    }

    return (
        <>
        <div className="song-playlist-header">
            <h4>Playlist Manager</h4>
            <div className="song-playlist-header__action">
                <button onClick={onAdd} className="btn-action">
                    <FaPlus /> Add
                </button>
                <button onClick={handleDeletePlaylists} className="btn-action">
                    <FaTrash /> Delete
                </button>
                <SearchBox onSearch={onSearch}>
                    <FaSearch /> Search
                </SearchBox>
            </div>
        </div>

        <table className="song-playlist-table">
            <thead>
                <tr>
                    <th>
                        <input
                            type="checkbox"
                            checked={isAllSelected}
                            onChange={handleSelectAll}
                        />
                    </th>
                    <th>Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody className="song-playlist-table__item">
                {playlists.map((playlist) => (
                    <React.Fragment key={playlist.id}>
                        <tr key={playlists.id}>
                            <td>
                            <input
                                type="checkbox"
                                checked={isSelected(playlist.id)}
                                onChange={() => handleSelectPlaylist(playlist.id)}
                            />
                            </td>

                            <td>{playlist.name}</td>

                            <td>
                                <button onClick={() => setEditedPlaylist(playlist)} className="btn-action">
                                    <FaEdit /> Edit
                                </button>
                                <button onClick={() => handleDeletePlaylist(playlist.id)} className="btn-action">
                                    <FaTrash /> Delete
                                </button>
                            </td>
                        </tr>

                        {editedPlaylist?.id === playlist.id && (
                            <tr>
                                <td colSpan="4">
                                    <PlaylistForm
                                        initialValues={editedPlaylist}
                                        onSubmit={onEdit}
                                        onCancel={() => setEditedPlaylist(null)}
                                    />
                                </td>
                            </tr>
                        )}
                    </React.Fragment>
                ))}
            </tbody>
        </table>
        </>
    );
}

PlaylistList.propTypes = {
    playlists: PropTypes.arrayOf(
        PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        artist: PropTypes.string.isRequired,
    })
    ).isRequired,

    onAdd: PropTypes.func.isRequired,
    onEdit: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    onSearch: PropTypes.func.isRequired,
};

export default PlaylistList;

import { createSlice, createAsyncThunk  } from '@reduxjs/toolkit';
import PlaylistApi from 'api/playlistApi';


export const fetchPlaylists = createAsyncThunk(
    'playlists/fetchAll',
    async (params) => {
        const response = await PlaylistApi.getAll(params);
        return response;
    }
);

let nextId = 1;

const playlist = createSlice({
    name: 'playlists',
    initialState: {
        list: [],
        filtered: [],
        searchText: '',
        loading: false,
    },
    reducers: {
        addPlaylist: (state, action) => {
            const newPlaylist = {
                id: nextId++,
                ...action.payload,
            };
            state.list.push(newPlaylist);
        },

        deletePlaylist: (state, action) => {
            const deletePlaylistId = action.payload;
            state.list = state.list.filter(playlist => playlist.id !== deletePlaylistId);
        },

        editPlaylist: (state, action) => {
            const newPlaylist =  action.payload;
            const playlistIndex = state.list.findIndex(playlist => playlist.id === newPlaylist.id);

            if(playlistIndex != null){
                state.list[playlistIndex] = newPlaylist;
            }
        },

        findByPlaylistName: (state, action) => {
            state.searchText = action.payload.toLowerCase()
            state.filtered = state.list.filter((song) =>
                song.name.toLowerCase().includes(state.searchText)
            );
        }
    },

    extraReducers: (builder) => {
        builder
            .addCase(fetchPlaylists.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchPlaylists.fulfilled, (state, action) => {
                state.list = action.payload;
                state.loading = false;
            });
    }
})

const { reducer, actions } = playlist;
export const {addPlaylist, deletePlaylist, editPlaylist, findByPlaylistName} = actions;
export default reducer;

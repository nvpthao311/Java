import React, { useEffect } from "react";
import { useSelector, useDispatch} from 'react-redux';
import { useNavigate } from 'react-router-dom';

import PlaylistApi from 'api/playlistApi'
import PlaylistList from 'features/Playlist/components/PlaylistList';
import {deletePlaylist, editPlaylist, findByPlaylistName, fetchPlaylists } from 'features/Playlist/PlaylistSlice';

function MainPage() {
    const playlists = useSelector(state => state.playlists.list);
    const filteredPlaylists = useSelector((state) => state.playlists.filtered);
    const searchText = useSelector((state) => state.playlists.searchText);

    const navigate = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
        const fetchPlaylists =   async () => {
            try {
                const params = {};
                const response = await PlaylistApi.getAll(params);
                console.log("RESPONSE:" , response);
            } catch (error) {
                console.log("ERROR" , error);
            }
        }
        fetchPlaylists();
    }, []);


    const handleClickPlaylist = () => {
        navigate('/music/songs');
    };

    const handleEdit = (id) => {
        console.log('Edit playlist:', id);

        const action = editPlaylist(id);
        console.log({action});
        dispatch(action);
    }

    const handleDelete = (id) => {
        console.log('Deleted playlist:', id);

        const action = deletePlaylist(id);
        console.log({action});
        dispatch(action);
    }

    const handleAdd = () => {
        navigate("/music/playlists/add");
    }

    const handleSearch = (name) => {
        console.log('Search playlist:', name);

        const action = findByPlaylistName(name);
        console.log({action});
        dispatch(action);
    }

    return (
        <div className="container">
            <aside className="container__body_menu">
                <h3>Home > Playlists</h3>
                <div class="divider"></div>
                <PlaylistList
                    playlists ={searchText.length > 0 ? filteredPlaylists : playlists}
                    onAdd ={handleAdd}
                    onEdit ={handleEdit}
                    onDelete ={handleDelete}
                    onSearch ={handleSearch}
                />
            </aside>
        </div>

    );
}

export default MainPage;
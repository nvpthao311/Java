import { createSlice } from '@reduxjs/toolkit';

let nextId = 1;

const song = createSlice({
    name: 'songs',
    initialState: {
        list: [],
        filtered: [],
        searchText: '',
    },
    reducers: {
        addSong: (state, action) => {
            const newSong = {
                id: nextId++,
                ...action.payload,
            };
            state.list.push(newSong);
        },

        deleteSong: (state, action) => {
            const deleteSongId = action.payload;
            state.list = state.list.filter(song => song.id !== deleteSongId);
        },

        editSong: (state, action) => {
            const newSong =  action.payload;
            const songIndex = state.list.findIndex(song => song.id === newSong.id);

            if(songIndex != null){
                state.list[songIndex] = newSong;
            }
        },

        findBySongName: (state, action) => {
            state.searchText = action.payload.toLowerCase()
            state.filtered = state.list.filter((song) =>
                song.name.toLowerCase().includes(state.searchText)
            );
        },
    }
})

const { reducer, actions } = song;
export const {addSong, deleteSong, editSong, findBySongName, clearFiltered} = actions;
export default reducer;
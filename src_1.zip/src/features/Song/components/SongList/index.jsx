import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { FaTrash, FaEdit, FaPlus, FaSearch  } from 'react-icons/fa';

import SearchBox from 'components/SearchBox';
import SongForm from 'features/Song/components/SongForm';
import './SongList.scss';

function SongList(props) {
    const { songs, onAdd, onEdit, onDelete, onSearch} = props;

    const [selectedSongs, setSelectedSongs] = useState([]);
    const [editedSong, setEditedSong] = useState(null);

    // Select
    const isSelected = (id) => selectedSongs.includes(id);
    const isAllSelected = selectedSongs.length === songs.length && songs.length > 0;

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allIds = songs.map((song) => song.id);
            setSelectedSongs(allIds);
        } else {
            setSelectedSongs([]);
        }
    };

    const handleSelectSong = (id) => {
        setSelectedSongs((prevSelected) =>
            prevSelected.includes(id)
            ? prevSelected.filter((songId) => songId !== id)
            : [...prevSelected, id]
        );
    };

    // Delete
    const handleDeleteSong = (id) => {
        const confirmDelete = window.confirm('Are you sure you want to delete this song?');
        onDelete(id);
    }

    const handleDeleteSongs = () => {
        const confirmDelete = window.confirm('Are you sure you want to delete selected songs?');
        if(selectedSongs && confirmDelete){
            selectedSongs.map((id) => {
                onDelete(id);
            });
            setSelectedSongs([]);
        }
    }

    return (
        <>
        <div className="song-playlist-header">
            <h4>Song Manager</h4>
            <div className="song-playlist-header__action">
                <button onClick={onAdd} className="btn-action">
                    <FaPlus /> Add
                </button>
                <button onClick={handleDeleteSongs} className="btn-action">
                    <FaTrash /> Delete
                </button>
                <SearchBox onSearch={onSearch}>
                    <FaSearch /> Search
                </SearchBox>
            </div>
        </div>

        <table className="song-playlist-table">
            <thead>
                <tr>
                    <th>
                        <input
                            type="checkbox"
                            checked={isAllSelected}
                            onChange={handleSelectAll}
                        />
                    </th>
                    <th>Name</th>
                    <th>Artist</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody className="song-playlist-table__item">
                {songs.map((song) => (
                    <React.Fragment key={song.id}>
                        <tr key={song.id}>
                            <td>
                            <input
                                type="checkbox"
                                checked={isSelected(song.id)}
                                onChange={() => handleSelectSong(song.id)}
                            />
                            </td>

                            <td>{song.name}</td>

                            <td>{song.artist}</td>

                            <td>
                                <button onClick={() => setEditedSong(song)} className="btn-action">
                                    <FaEdit /> Edit
                                </button>
                                <button onClick={() => handleDeleteSong(song.id)} className="btn-action">
                                    <FaTrash /> Delete
                                </button>
                            </td>
                        </tr>

                        {editedSong?.id === song.id && (
                            <tr>
                                <td colSpan="4">
                                    <SongForm
                                        initialValues={editedSong}
                                        onSubmit={onEdit}
                                        onCancel={() => setEditedSong(null)}
                                    />
                                </td>
                            </tr>
                        )}
                    </React.Fragment>
                ))}
            </tbody>
        </table>
        </>
    );
}

SongList.propTypes = {
    songs: PropTypes.arrayOf(
        PropTypes.shape({
        id: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        artist: PropTypes.string.isRequired,
    })
    ).isRequired,

    onAdd: PropTypes.func.isRequired,
    onEdit: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    onSearch: PropTypes.func.isRequired,
};

export default SongList;
